---
name: synthesis
description: "Analyse un matériau de recherche déjà recueilli et en tire constats, thèmes et recommandations de conception, méthode La Bonne Agence : transcriptions ou notes d'entretiens, comptes rendus d'ateliers, résultats de tri de cartes ou de test d'arborescence, notes de tests d'utilisabilité, réponses à un questionnaire, statistiques d'audience, retours du support. Produit aussi le « constat et diagnostic » d'une refonte et les implications pour l'arborescence et les parcours. Déclencher dès que l'utilisateur colle ou joint ce type de matériau et veut en dégager des tendances, des profils, des priorités ou des personas, même sans le mot « synthèse ». Ne pas utiliser pour préparer une étude (`lba-design:research`)."
---

# Synthèse de recherche

**Préséance** : invariants de `lba-design:principles` (ne rien inventer, niveaux de preuve, données personnelles) > demande > matériau recueilli (faits) > décisions du plan de recherche > interprétation (toujours séparée des faits).

Charger `lba-design:principles` avant de commencer.

Une synthèse engage des choix de conception qui seront défendus devant le client. Elle doit pouvoir être relue par quelqu'un qui n'était pas là et remonter de chaque recommandation jusqu'aux faits.

## Règles, non négociables

1. **Observation, interprétation, recommandation** : trois niveaux toujours séparés et nommés. « 6 participants sur 8 ont cherché les horaires dans le menu Agenda » est une observation. « Le mot Agenda porte l'attente des horaires » est une interprétation. « Renommer ou dupliquer l'entrée » est une recommandation.
2. **Compter, ne pas qualifier** (`lba-design:principles` §2) : 3 sur 5 n'est pas 60 %.
3. **Par profil** : quand l'étude couvre plusieurs publics, chaque thème indique quels profils il concerne. Aucune moyenne entre publics.
4. **Ne rien inventer** (`lba-design:principles` §1), en particulier aucune citation ni profil. Une citation reprise est exacte et attribuée à un code participant (P3). Une paraphrase est présentée comme telle. Un matériau lacunaire donne une synthèse courte, pas une synthèse comblée.
5. **Données personnelles** : matériau identifiant signalé et pseudonymisé avant analyse (`lba-design:principles` §7).
6. **Niveau de preuve** affiché pour chaque constat : solide, à confirmer ou hypothèse (`lba-design:principles` §2).

## Méthode

1. **Inventorier le matériau** : méthode, nombre et profils des participants, dates, qui a mené les séances. Signaler tout de suite ce qui manque pour répondre aux décisions du plan de recherche, s'il existe.
2. **Extraire les observations** une par une, avec leur source (P3, atelier du 12/09, statistiques de juin).
3. **Regrouper par affinité**, puis nommer chaque groupe par une phrase qui dit quelque chose (« les familles ne distinguent pas les deux cohortes »), pas par une étiquette (« navigation »).
4. **Confronter les sources** : ce que dit le client en atelier, ce que font les usagers et ce que montrent les statistiques. Les écarts sont souvent le constat le plus utile ; les présenter tels quels, sans arbitrer à la place du client.
5. **Relier aux décisions** de conception : chaque thème débouche sur une implication ou est marqué « sans conséquence directe ».
6. **Prioriser** les recommandations selon l'impact pour les usagers et le coût de correction à ce stade du projet, avec pour chacune les constats qui la fondent.

## Cas particuliers

**Tri de cartes** : restituer les regroupements récurrents, les cartes instables (placées dans des groupes différents), les libellés proposés par les participants. En déduire une proposition d'arborescence, qui reste une proposition à tester par un test d'arborescence.

**Test d'arborescence ou d'utilisabilité** : taux de réussite par tâche, chemins empruntés, premiers clics, points d'abandon. Une tâche échouée par tous est un problème d'arborescence ou de libellé avant d'être un problème d'interface.

**Statistiques d'audience** : elles disent ce qui se passe, jamais pourquoi. Donner la période, la source et les limites (consentement aux cookies, trafic des robots, pages mal nommées). Ne jamais extrapoler un chiffre absent.

**Vocabulaire** : relever les mots employés par les usagers pour nommer les contenus, quand ils diffèrent de ceux du client. Cette liste alimente le lexique du DESIGN.md (§2.2, colonnes « Dire » et « Ne pas dire », avec la récurrence en « Pourquoi ») et `lba-design:microcopy`.

**Personas** : seulement si le matériau les fonde. Sinon, proposer des profils provisoires explicitement marqués « hypothèses, non validées par la recherche ». Un persona inventé devient un argument de réunion impossible à contester, donc un risque.

## Format de restitution

```markdown
## Synthèse : [étude], [date]
Matériau : [méthodes, n participants par profil, période, conduite par]
Limites : [biais de recrutement, taille, ce que l'étude ne dit pas]

### En bref
[3 à 5 constats, chacun en une phrase, avec son niveau de preuve]

### Thèmes
#### [Phrase qui dit quelque chose]
Profils concernés : … | Récurrence : n sur N | Preuve : solide / à confirmer / hypothèse
Observations : …
Verbatims : « … » (P2) ; « … » (P5)
Implication pour la conception : …

### Écarts entre sources
| Sujet | Client (atelier) | Usagers | Statistiques |
|---|---|---|---|

### Recommandations
| Priorité | Recommandation | Fondée sur | Coût de correction maintenant |
|---|---|---|---|

### Vocabulaire des usagers
| Mot du client | Mot des usagers | Source |
|---|---|---|

### Questions ouvertes
[Ce qu'il faudrait encore apprendre, et par quelle méthode]
```

## Constat et diagnostic de refonte

Livrable d'avant-projet ou de cadrage qui croise l'audit du site actuel, les statistiques réelles fournies par le client et la recherche disponible. Même règles : chiffres sourcés et datés, niveau de preuve affiché, aucune donnée d'audience inventée ou estimée sans le dire. Structure type : contexte et objectifs, publics, ce que montrent les données, ce que disent les usagers, problèmes prioritaires, pistes pour la refonte, zones d'ombre.

## Suite et forme

- Les décisions tirées de la synthèse sont datées dans le journal de la fiche projet ; l'arborescence et les priorités par section deviennent le contrat de structure du wireframe (`lba-design:wireframe`).
- Document remis au client : modèles de documents de l'agence, sans codes internes ni détails de recrutement ; les verbatims restent pseudonymisés.

## Anti-défauts

| Éviter | Faire à la place | Pourquoi |
|---|---|---|
| « La plupart », « 60 % » sur 5 entretiens | « 3 sur 5 », par profil | Pas de pourcentage sur un échantillon qualitatif |
| Thème nommé par une étiquette (« navigation ») | Une phrase qui dit quelque chose | Une étiquette ne se défend pas devant le client |
| Citation reformulée présentée comme verbatim | Citation exacte attribuée (P3), ou paraphrase annoncée | Ne rien inventer |
| Persona sans matériau | Profil provisoire marqué « hypothèse, non validée par la recherche » | Un persona inventé devient un argument impossible à contester |
| Arbitrer entre client et usagers | Présenter l'écart tel quel | La décision appartient au client, éclairée |
| Synthèse comblée quand le matériau manque | Synthèse courte, lacunes listées en questions ouvertes | La longueur ne remplace pas la preuve |

## Attribution

Adapté du skill `research-synthesis` du dépôt `anthropics/knowledge-work-plugins` (licence Apache 2.0), traduit et réécrit (niveaux de preuve, analyse par profil, tri de cartes et arborescence, diagnostic de refonte, données personnelles). Voir `NOTICE` à la racine du plugin.
