# Checklist : mode capture d'écran

Ce mode est utilisé quand Claude analyse une capture d'écran de maquette Figma.
L'analyse est visuelle : les valeurs sont estimées. Si les couleurs sont lisibles à l'œil, les relever en hex approximatif et passer quand même par `scripts/contrast.py`, en préfixant le résultat de « ~ ».
Préciser dans le rapport que les valeurs exactes doivent être vérifiées via les tokens Figma.

---

## Étape 1 : Lecture globale de la capture

Avant d'entrer dans les détails, évaluer :
- Type d'interface (mobile, desktop, responsive)
- Contexte fonctionnel (formulaire, dashboard, landing, liste...)
- Éléments interactifs visibles (boutons, liens, champs, cartes cliquables)

## Étape 2 : Contrastes (WCAG 1.4.3 et 1.4.11)

Analyser visuellement :
- Textes sur fonds clairs / fonds sombres / fonds texturés ou dégradés
- Signaler tout texte qui semble avoir un contraste insuffisant (gris clair sur blanc, texte sur image, couleurs pastels)
- Signaler les textes petits sur fond coloré non-neutre

Indiquer systématiquement : « Contraste estimé sur capture, à confirmer avec les valeurs exactes du fichier. »

## Étape 3 : Lisibilité typographique (bonnes pratiques)

Estimer visuellement :
- Les textes qui semblent trop petits (< 14px estimé)
- Les textes en majuscules exclusives sur de longs passages
- Les textes très légers (font-weight 100/200) sur fond clair
- L'espacement entre les lignes sur les blocs de texte longs

## Étape 4 : Zones de clic (bonne pratique, WCAG 2.2 2.5.8)

Identifier les éléments interactifs qui semblent trop petits :
- Icônes seules sans zone de clic étendue visible
- Liens texte courts isolés
- Éléments cliquables adjacents sans espacement suffisant
- Checkboxes / radios de petite taille

## Étape 5 : Hiérarchie visuelle (WCAG 1.3.1)

Évaluer la lisibilité de la structure :
- Y a-t-il une hiérarchie claire titre/sous-titre/corps ?
- L'ordre de lecture est-il intuitif ?
- Les éléments d'action (CTA) sont-ils clairement identifiables ?
- Les champs de formulaire ont-ils des labels visibles (pas juste placeholders) ?

## Étape 6 : Couleur seule (WCAG 1.4.1)

Chercher les cas où la couleur est le seul différenciateur :
- Statuts signalés uniquement par une couleur (vert/rouge/orange)
- Graphiques avec légendes uniquement colorées
- Champs d'erreur sans icône ni texte d'erreur
- Liens non soulignés et non autrement différenciés du texte

## Étape 7 : Focus et états interactifs (WCAG 2.4.7)

Évaluer si les états sont visibles dans les captures :
- Les boutons ont-ils des états hover/focus visibles ?
- Les champs actifs sont-ils différenciés des champs inactifs ?
- L'élément actif dans la navigation est-il identifiable ?

## Étape 8 : Formulaires (WCAG 1.3.1, 3.3.1, 3.3.2)

Si des formulaires sont présents :
- Labels visibles sur tous les champs (pas que placeholders)
- Messages d'erreur descriptifs prévus (pas juste "Champ invalide")
- Ordre logique de tabulation implicite dans le layout
- Champs obligatoires identifiés autrement que par la couleur

---

## Synthèse à produire

Après analyse visuelle, produire le rapport au format défini dans SKILL.md.
Préfixer chaque valeur estimée de "~" pour signaler l'approximation.
Recommander une vérification en mode MCP pour tout point 🔴.
