# Checklist : mode MCP Figma

## 1. Récupérer les données

`get_metadata` pour la structure, `get_design_context` pour les valeurs (couleurs, tailles, styles, variables), `get_screenshot` pour contrôler le rendu. Travailler sur le nœud de frame précis, pas sur la page entière. Les couleurs à opacité ou superposées se calculent sur la couleur résultante (le script accepte un hex à 8 chiffres).

## 2. Contrastes

- Texte et grand texte : seuils de `lba-design:principles` §4. WCAG 1.4.3 / RGAA 3.2.
- Composants d'interface et graphiques porteurs d'information (bordure de champ, icône seule, état sélectionné, courbe de graphique) : seuil de `lba-design:principles` §4. WCAG 1.4.11 / RGAA 3.3.
- Calcul : `python3 scripts/contrast.py FG BG`. Texte sur image ou dégradé : mesurer le cas le plus défavorable et le signaler.

## 3. Information par la couleur seule

Erreur de champ, statut, lien dans un paragraphe, légende de graphique : la couleur doit être doublée par un texte, une icône, une forme ou un soulignement. WCAG 1.4.1 / RGAA 3.1.

## 4. Structure et titres

Hiérarchie de titres identifiable et cohérente avec le sens (pas seulement avec la taille), ordre des calques proche de l'ordre de lecture, composants nommés de façon parlante. WCAG 1.3.1 / RGAA 9.1 pour les titres. Le balisage réel ne se vérifie qu'en code : le dire.

## 5. Formulaires

Étiquette visible et persistante pour chaque champ (un placeholder seul ne suffit pas), champs obligatoires signalés autrement que par la couleur, messages d'erreur rédigés et placés près du champ. WCAG 1.3.1, 3.3.1, 3.3.2 / RGAA 11.1 et 11.10.

## 6. Focus

Un état focus existe pour chaque composant interactif (variant ou état documenté) et il est visible sur tous les fonds utilisés. WCAG 2.4.7 / RGAA 10.7. Bonne pratique : indicateur ≥ 2 px et contraste ≥ 3:1 avec le fond.

## 7. Alternatives textuelles

Images informatives distinguées des décoratives, alternative prévue dans les specs, icônes seules avec un libellé accessible prévu, graphiques avec une alternative (tableau ou texte). WCAG 1.1.1 / RGAA 1.x.

## 8. Redimensionnement et adaptation

Vérifier qu'une déclinaison mobile existe et que rien ne suppose une taille de texte figée (textes dans des images, conteneurs à hauteur fixe). WCAG 1.4.4 et 1.4.10 / RGAA 10.4 et 10.11. Se confirme en code.

## Bonnes pratiques (hors conformité RGAA 4.1)

- Cibles tactiles : seuils de `lba-design:principles` §4 (WCAG 2.5.8 AA, 2.5.5 AAA).
- Corps de texte autour du repère de 16 px, ajusté selon la police (`lba-design:principles` §4), interligne ≥ 1,4 sur les paragraphes, longueur de ligne ≤ 75 caractères (`lba-design:principles` §4).
- Focus non masqué par un en-tête ou un bandeau collant (WCAG 2.2, 2.4.11).

## Correspondances RGAA utilisées

| WCAG | RGAA | Sujet |
|---|---|---|
| 1.1.1 | 1.x | Images |
| 1.4.1 | 3.1 | Couleur seule |
| 1.4.3 | 3.2 | Contraste du texte |
| 1.4.11 | 3.3 | Contraste des composants |
| 1.3.1 (titres) | 9.1 | Titres |
| 2.4.7 | 10.7 | Focus visible |
| 1.4.4 | 10.4 | Agrandissement du texte |
| 1.4.10 | 10.11 | Reflow |
| 3.3.2 | 11.1 | Étiquettes de champ |

Pour tout autre critère, citer WCAG seul et noter « correspondance RGAA à vérifier ».
