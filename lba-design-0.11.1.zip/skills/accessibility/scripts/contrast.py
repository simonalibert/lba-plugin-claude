#!/usr/bin/env python3
"""Compute WCAG contrast ratios.

Usage:
    python3 contrast.py FG BG [FG BG ...]
    python3 contrast.py "#8A8A8A" "#FFFFFF"
    python3 contrast.py "#FFFFFF80" "#1D19A9"   # 8-digit hex: FG alpha blended over BG

Prints ratio and pass/fail for normal text (4.5), large text and UI (3.0).
"""
from __future__ import annotations

import sys


def parse_hex(value: str) -> tuple[float, float, float, float]:
    h = value.strip().lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    if len(h) not in (6, 8):
        raise ValueError(f"Invalid hex colour: {value}")
    r, g, b = (int(h[i : i + 2], 16) / 255 for i in (0, 2, 4))
    a = int(h[6:8], 16) / 255 if len(h) == 8 else 1.0
    return r, g, b, a


def blend(fg: tuple[float, float, float, float], bg: tuple[float, float, float, float]) -> tuple[float, float, float]:
    a = fg[3]
    return tuple(fg[i] * a + bg[i] * (1 - a) for i in range(3))  # type: ignore[return-value]


def luminance(rgb: tuple[float, float, float]) -> float:
    def channel(c: float) -> float:
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4

    r, g, b = (channel(c) for c in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def ratio(fg_hex: str, bg_hex: str) -> float:
    bg = parse_hex(bg_hex)
    fg_rgb = blend(parse_hex(fg_hex), bg)
    l1, l2 = sorted((luminance(fg_rgb), luminance(bg[:3])), reverse=True)
    return (l1 + 0.05) / (l2 + 0.05)


def main(argv: list[str]) -> int:
    if len(argv) < 2 or len(argv) % 2:
        print(__doc__)
        return 1
    for fg, bg in zip(argv[::2], argv[1::2]):
        r = ratio(fg, bg)
        normal = "OK" if r >= 4.5 else "KO"
        large = "OK" if r >= 3.0 else "KO"
        print(f"{fg} sur {bg} : {r:.2f}:1 | texte normal {normal} | grand texte / UI {large}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
