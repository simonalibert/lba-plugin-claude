---
name: accessibility
description: "Audite une maquette (fichier Figma via MCP ou capture d'écran) au regard du RGAA 4.1 et des WCAG 2.1 AA (WCAG 2.2 en bonne pratique), et produit un rapport hiérarchisé avec des annotations, rédigées ou écrites directement dans Figma. Déclencher dès que l'utilisateur mentionne accessibilité, a11y, RGAA, WCAG, contraste, taille des cibles tactiles, focus visible, alternatives textuelles, ou demande si une maquette est accessible ou conforme, même sans le mot « audit ». Ne pas utiliser pour la passe qualité d'une maquette que Claude est en train de concevoir (`lba-design:ui-design` s'en charge), pour l'hygiène technique d'un fichier Figma (`lba-design:figma`), ni pour tester du code en ligne (lecteur d'écran, clavier)."
---

# Audit d'accessibilité de maquette

**Préséance** : invariants de `lba-design:principles` (posture de pré-évaluation, seuils, citation des critères) > demande > référentiel réglementaire (RGAA 4.1) > cible interne (WCAG 2.2 AA, en bonne pratique) > défauts de restitution (ci-dessous).

Charger `lba-design:principles` avant de commencer.

Un audit sur maquette est une **pré-évaluation** : il repère ce qui sera non conforme une fois développé, il ne prononce jamais une conformité. Le dire dans chaque rapport.

## Référentiel

Référentiel, cible interne, bonnes pratiques et règle de citation des critères : `lba-design:principles` §3 ; seuils : §4. Correspondances WCAG / RGAA certaines : tableau de `references/checklist-mcp.md`. Exemples de bonnes pratiques hors RGAA : 2.5.8 taille des cibles, 2.4.11 focus non masqué.

## Selon le profil du projet

Lire le profil dans la fiche projet (`lba-design:principles` §11) ; sans fiche, le demander avec le contexte (étape 2).

- **Conformité RGAA** : pré-évaluation à chaque version validée, pas seulement sur demande ; couvrir toutes les thématiques RGAA vérifiables sur maquette, critère RGAA cité pour chaque non-conformité dont la correspondance est certaine ; signaler les éléments attendus d'un service soumis à l'obligation (mention et déclaration d'accessibilité en pied de page, deux systèmes de navigation, lien d'évitement) ; aucun écart accepté sur les impératifs d'accessibilité de `lba-design:ui-design`.
- **Vitrine expressive** : vérifier en priorité les replis des effets : contenu révélé au défilement accessible sans défilement (clavier, lecteur d'écran), bouton pause sur tout ce qui bouge plus de 5 secondes (WCAG 2.2.2 / RGAA 13.8), comportement en mouvement réduit, texte posé sur image ou vidéo, polices décoratives lisibles.
- **Standard** et **éco-conçu** : déroulé ci-dessous, à la demande.

## Déroulé

1. **Mode** : MCP Figma si un lien de fichier ou de nœud est fourni (lire `references/checklist-mcp.md`), capture sinon (lire `references/checklist-visuel.md`). Les deux se combinent : une capture sert de vue d'ensemble, le MCP donne les valeurs.
2. **Contexte** : type de service, public, statut du client (organisme public ou soumis à l'obligation d'accessibilité : l'enjeu est réglementaire, à signaler sans trancher le périmètre juridique). S'il manque une information qui change l'audit, poser une seule question.
3. **Contrastes** : calculer avec `python3 scripts/contrast.py`, jamais de tête.
4. **Rapport** puis **annotations**.

## Classement des constats

Deux axes indépendants, toujours renseignés tous les deux :

- **Statut** : non-conformité (critère A ou AA du référentiel) ou bonne pratique.
- **Impact** : 🔴 bloquant (un contenu ou une fonction devient inaccessible à certains usagers), 🟠 majeur (gêne forte, contournable), 🟡 mineur (gêne légère), 🔵 observation.

Une non-conformité n'est jamais classée 🔵. Une bonne pratique peut être 🟠 si l'impact le justifie (ex. cibles de 20 px sur mobile).

## Format du rapport

```
## Audit accessibilité : [écran ou composant]
Mode : MCP / capture | Profil : [standard, vitrine expressive, conformité RGAA, éco-conçu] | Référentiel : RGAA 4.1 (WCAG 2.1 AA) | Date : [date]
Pré-évaluation sur maquette, ne vaut pas audit de conformité.

### Synthèse
[2 ou 3 lignes : points critiques, points solides]

### Constats
🔴 [Titre]
Statut : non-conformité, WCAG X.X.X / RGAA X.X
Constat : [observation, valeurs mesurées ou estimées « ~ »]
Correction : [action et valeur cible]

### Vérifié sans écart
[critères contrôlés et conformes, en une ligne chacun]

### Anti-défauts

| Éviter | Faire à la place | Pourquoi |
|---|---|---|
| « La maquette est conforme » | « Pré-évaluation sur maquette, ne vaut pas audit de conformité » | Posture de conformité (`principles` §3) |
| Contraste estimé de tête | `scripts/contrast.py`, ou valeur préfixée « ~ » si lue sur capture | Un ratio deviné engage à tort |
| Critère RGAA cité par analogie | Critère WCAG systématique, RGAA seulement si la correspondance est certaine | Une mauvaise référence décrédibilise tout le rapport |
| Bonne pratique WCAG 2.2 présentée comme non-conformité | Statut « bonne pratique », impact selon la gêne réelle | Référentiel réglementaire : WCAG 2.1 via le RGAA |
| Liste plate de constats | Statut et impact sur chaque constat, du bloquant à l'observation | L'équipe corrige d'abord ce qui bloque |
| Annotation descriptive (« contraste faible ») | Annotation impérative et chiffrée : valeur actuelle, cible, critère | Le designer doit pouvoir corriger sans relire le rapport |

## Hors périmètre de la maquette
[ce qui ne se vérifiera qu'en code : ordre de tabulation, restitution lecteur d'écran, zoom 200 %…]
```

Si le rapport part chez le client sous forme de document, utiliser les modèles de documents de l'agence, jamais la charte du client audité.

## Annotations

Une annotation par constat 🔴 ou 🟠 : impérative, chiffrée (valeur actuelle et cible), avec le critère. Ex. : « Texte gris #8A8A8A sur blanc : 3,5:1. Passer à 4,5:1 minimum (#767676 ou plus sombre). WCAG 1.4.3 / RGAA 3.2. »

Deux sorties possibles, à proposer :

- **Texte à coller**, par défaut.
- **Écriture directe dans le fichier** via `use_figma`, après accord explicite : lire `figma:figma-use` et `lba-design:figma` avant. Privilégier les annotations natives de Dev Mode, catégorie Accessibility, plutôt que des post-it dessinés ; méthode et pièges (normalisation avant réécriture, catégorie à vérifier) dans `lba-design:figma` §3.

## Hors périmètre

Tests sur code (clavier, lecteurs d'écran), qualité rédactionnelle (`lba-design:microcopy` pour les libellés et messages), tests avec des usagers, hygiène du fichier Figma (`lba-design:figma`). Les signaler dans le rapport quand le projet les requiert.
