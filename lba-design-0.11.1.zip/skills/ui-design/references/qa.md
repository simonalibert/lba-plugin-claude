# Passe qualité

Ce qu'on vérifie avant chaque livraison, comment, et ce qui reste hors périmètre. Toute vérification se range dans l'une de trois colonnes du rapport : **vérifié** (mesuré par le script ou constaté sur capture, avec le chiffre), **non vérifié** (prévu mais impossible ici, dit avec la raison), **hors périmètre** (relève d'un autre contrôle : audit RGAA, recette en code, test usagers). Jamais de coche sans chiffre ni capture.

## 1. Le script

```bash
python3 scripts/qa.py page.html --out qa/ --quiet --fiche chemin/fiche-projet.md
```

Entrée : fichier HTML produit, URL locale, ou fichiers d'un artefact récupérés avec l'outil Artifact en action `read` s'ils contiennent une page HTML. Sortie : captures aux largeurs de contrôle et `report.md`.

- `--quiet` écrit le rapport sans l'afficher, pour juger les captures d'abord (§2).
- `--fiche` lit le profil coché et les repères de taille de la fiche projet ; à défaut, `--eco` (budgets du profil éco-conçu) et `--min-text`, `--min-body` (repères de taille ajustés à la police) se passent à la main. Les options manuelles l'emportent.

Il mesure : audit axe-core WCAG 2.2 A/AA (aux largeurs extrêmes), débordements, texte à opacité réduite, focus invisible au clavier, longueurs de ligne, titres sans `balance`, cibles trop petites, espacements hors grille, mouvement et flou malgré `prefers-reduced-motion` (les fondus sont admis), typographie française, tailles de texte, poids des images, des polices et de la page, et les anti-défauts mesurables (texte en dégradé, filet latéral coloré, ombre dure, numérotation, séparateurs « · », emoji-icônes, `transition: all`, `ease-in`, chiffres de tableau sans `tabular-nums`, sélection non stylée), signalés comme des signaux à justifier ou à réécrire, pas comme des erreurs.

**Budgets** : le poids de page est toujours mesuré et rapporté. Profil éco-conçu (`lba-design:principles` §11) : budget imposé, 1,5 Mo transférés au plus pour une page d'accueil chargée à froid et 1 Mo pour une page de contenu (convention à calibrer sur les projets réels), une famille de polices, aucune bibliothèque chargée pour un seul effet, critères RGESN cités ; `--eco` ou `--fiche` l'appliquent. Autres profils : pas de seuil, mais un poids inhabituel se déclare avec sa raison (polices payantes, séquences d'images, vidéo).

C'est un **pré-contrôle**, pas un audit RGAA (`lba-design:principles` §3) ; en profil conformité RGAA, la pré-évaluation `lba-design:accessibility` est requise pour toute version validée. S'il ne peut pas tourner (pas de Python ni de Playwright), faire le contrôle visuel et ranger le reste en « non vérifié ». Dans Figma, `qa.py` ne s'applique pas : `figma.md`.

## 2. Juger, puis lire

1. **Juger avant de lire le rapport.** Regarder les captures (390, 924 et 1440 au minimum) et noter son jugement de conception avant d'ouvrir `report.md` : hiérarchie, identité (test du `SKILL.md`, étape 6), tenue du parti pris. Un rapport chiffré lu en premier oriente le regard vers ce qu'il mesure. Si la surface permet de déléguer à un agent séparé, lui confier l'une des deux lectures.
2. **Ce que le script ne voit pas** : filets en ouverture ou clôture (imp. 2), lignes de base (3), alignement optique (7), colonne gauche (8), visages et recadrages (9), états survol, actif, désactivé (11), grilles en 3+1 et orphelins (16), surfaces du navigateur, anti-défauts non mesurables (cartes identiques, surtitres décoratifs, fausse interface en `div`).
3. **Classer et traiter** : critique (compréhension, accessibilité, navigation) et important (hiérarchie, cohérence, responsive, identité) corrigés avant livraison ; opportunité si le gain est net ; préférence sans sur-optimiser.
4. **Passes bornées** : une inspection groupée (toutes largeurs ensemble), une série de corrections, au plus une passe de confirmation, puis livrer. Au-delà, chaque tour coûte plus qu'il ne rapporte ; ce qui reste va dans « À valider ».

## 3. Test du pire cas

Standard LBA pour toute page qui affiche des contenus éditables par le client (actualités, fiches, annuaire, listes filtrées, formulaires) ; une page vitrine figée peut s'en dispenser, en le disant. Ses conclusions alimentent la section « Contenus et cas limites » de la spec d'écran (`lba-design:handoff`).

Une maquette est presque toujours dessinée avec des contenus qui l'arrangent : titres qui tiennent sur une ligne, noms courts, toutes les images présentes, trois actualités pile. Ce test remplace ces contenus, champ par champ, par le cas le plus défavorable **plausible**, et liste ce qui casse. Il se fait avant de livrer une version à valider et avant tout handoff ; ses conclusions alimentent la section « Contenus et cas limites » de la spec d'écran (`lba-design:handoff`).

Niveau : standard LBA pour toute page qui affiche des contenus éditables par le client (actualités, fiches, annuaire, listes filtrées, formulaires). Une page vitrine figée peut s'en dispenser, en le disant.

### Règles

1. **Plausible ou mesuré, jamais absurde.** Chaque valeur vient soit d'un cas réel du client (le titre le plus long de son site actuel, l'intitulé de poste le plus long de son annuaire), soit d'une limite réelle (champ du CMS, base de données, gabarit éditorial). « aaaaaaaaaaaa » ou un nom de 500 caractères ne prouvent rien et décrédibilisent le test. Pas de limite connue : c'est un constat en soi (« non borné »), à porter en zone grise.
2. **Données de test, pas contenu.** Ces valeurs servent à éprouver la mise en page ; elles ne sont jamais livrées comme contenu et restent derrière une bascule « Contenu de démonstration / Pire cas » visible seulement dans la version de travail. Elles ne contreviennent pas à `lba-design:principles` §1 tant qu'elles ne sortent pas de ce cadre.
3. **Changer les données, pas le gabarit.** Le pire cas entre par le même chemin que le contenu normal (jeu de données, variables, composant). Retoucher le CSS pour provoquer la casse teste la retouche, pas la maquette.
4. **Un seul jeu, plusieurs pièges.** Mélanger les cas sur une même page, comme les vraies données : la première carte a le titre long, la deuxième n'a pas d'image, la troisième un auteur au nom composé.
5. **Constater avant de corriger.** Certaines casses appellent une décision (tronquer ou laisser passer à la ligne, masquer un champ vide ou afficher « Non renseigné »). Les lister toutes avec la correction proposée ; corriger ce qui relève de l'évidence, porter le reste en « À valider ».

### Catalogue

| Champ | Pire cas plausible | Ce qui casse souvent |
|---|---|---|
| Titre d'article, de page | Le plus long du site actuel ; à défaut, 110 à 140 caractères | Carte qui grandit seule dans une grille, `balance` qui produit trois lignes égales trop étroites |
| Mot long | « Interprofessionnalité », « Accompagnement-formation », un nom de dispositif en un seul mot | Débordement horizontal en 390, césure absente (`hyphens: auto` exige `lang="fr"`) |
| Nom de personne | Prénom et nom composés (« Marie-Bénédicte Lefèvre-Delacroix »), et l'inverse : deux lettres (« Lu ») | Initiales d'avatar, alignement d'une carte d'équipe, ligne isolée |
| Intitulé de poste, de rôle | Le plus long de l'organigramme | CTA ou tag poussé hors de la carte |
| Libellé de bouton ou de filtre | Le plus long prévu par le lexique ; une traduction si le site est multilingue (l'allemand allonge de 30 % environ, à mesurer) | Bouton sur deux lignes, filtre qui sort de la piste du segmented control |
| Nombre | 0, 1, 2, puis le plus grand réaliste (« 1 284 résultats ») | Accord (« 1 résultats »), séparateur de milliers absent, colonne de chiffres qui ne s'aligne pas (`tabular-nums`) |
| Prix, durée, date | Montant à 5 chiffres, « du 28 septembre au 3 octobre 2026 » | Retour à la ligne entre nombre et unité (espace insécable, `principles` §6) |
| Liste, grille | 0 élément, 1 élément, nombre impair, 13 éléments | État vide absent, grille en 3+1 (imp. 16), pagination non prévue |
| Image | Absente, verticale dans un emplacement horizontal, visage en bord de cadre | Bloc vide sans repli, recadrage qui coupe le visage (imp. 9) |
| Champ facultatif | Vide (chapô, sous-titre, auteur, lieu) | Espace réservé qui reste, séparateur orphelin (« · » ou filet en tête) |
| Lien externe, e-mail | Adresse longue sans espace (`contact.communication@nom-de-l-organisation.fr`) | Débordement, `overflow-wrap: anywhere` à prévoir |
| Texte saisi | Message d'erreur de formulaire le plus long ; nom de fichier téléversé long | Champ qui grandit, aide masquée |
| Environnement | Zoom texte 200 %, largeur 320, police de secours si la webfont ne charge pas | Débordements, lignes de base décalées, CTA coupés |

### Restitution

Dans le rapport de livraison (`livraison.md`), une ligne dans la QA : nombre de champs testés, nombre de casses, corrigées ou à valider. Dans la spec d'écran, chaque casse tranchée devient une règle de la section « Contenus et cas limites » (longueur maximale, comportement au-delà, repli si vide).

## 4. Éléments souvent oubliés

À vérifier avant la première livraison d'un site ou d'un gabarit de page. Ce qui relève d'une obligation légale est à faire confirmer par le référent du client (`lba-design:principles` §3) ; la maquette prévoit la place, elle ne tranche pas le droit.

| Élément | Ce que la maquette doit prévoir |
|---|---|
| Lien d'évitement | « Aller au contenu » visible au focus clavier, premier élément de la page (WCAG 2.4.1 / RGAA 12.7) |
| Navigation | état de la page courante (`aria-current`), retour possible depuis chaque page profonde (fil d'Ariane ou lien parent) |
| Page 404 et page d'erreur | message clair, recherche ou liens vers les rubriques principales |
| Formulaires | page ou message de confirmation après envoi, erreurs en ligne (`lba-design:microcopy`), mention d'information RGPD près du bouton d'envoi |
| Consentement aux cookies | bandeau ou fenêtre, refus aussi simple que l'acceptation, lien pour modifier ses choix en pied de page (à confirmer avec le référent du client selon les traceurs réellement utilisés) |
| Pied de page | mentions légales, données personnelles, accessibilité (mention et déclaration si le client y est soumis), plan du site, contact |
| Recherche | état « aucun résultat » avec suggestions, si le site a une recherche |
| Médias | alternative de chaque image porteuse d'information, sous-titres et transcription des vidéos |
| Métadonnées | favicon et icônes d'application, titre de page distinct par gabarit, image de partage (Open Graph) prévue au format de `lba-design:media` |
| Impression | pour les pages qui s'impriment (fiches, programmes, documents à emporter) : feuille de style d'impression à demander au dev |

Adaptations : test du pire cas d'après `break-ui` d'Emil Kowalski (MIT) ; jugement avant lecture et passes bornées d'après Impeccable (Apache 2.0). Voir `NOTICE`.
