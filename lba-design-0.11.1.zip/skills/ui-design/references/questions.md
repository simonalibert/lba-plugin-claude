# Questions de cadrage

À poser **en une seule fois**, avant de dessiner, avec l'outil de questions de la surface (fenêtre de choix sur claude.ai, `AskUserQuestion` dans Claude Code). Seulement les questions dont la réponse manque dans la demande, la fiche projet et les fichiers joints : une question dont on a la réponse ne se pose pas. Si tout est connu, aucune fenêtre.

## Règles

- **Trois questions** sur claude.ai et partout où la limite n'est pas connue ; **quatre** dans Claude Code (2 à 4 options chacune, une réponse libre « Autre » est toujours ajoutée par l'outil).
- Chaque question garde une sortie : une option « Au choix, hypothèse » quand il reste de la place, sinon la réponse libre. Ne jamais bloquer : sans réponse, la valeur par défaut devient une hypothèse visible.
- La fenêtre ne permet pas de joindre de fichiers : juste après, une phrase demande de joindre ou de coller ce qui a été coché (zoning, URL, captures, logo, médias).
- Sans outil de questions : les mêmes questions en texte, numérotées, chacune avec sa valeur par défaut.
- Les réponses s'écrivent dans la fiche projet (« Sources », « Cadre », « Profil et livrables »).

## Google Drive : en option, jamais par défaut

Ne jamais fouiller le Google Drive de la personne de sa propre initiative. Le Drive est **une option de la question 2** : on n'y cherche que si elle est cochée.

- Option cochée et connecteur Google Drive disponible : chercher par le nom du client ou du projet (logo, charte, photos), **lister ce qui a été trouvé** (nom, type, date) et faire confirmer avant d'utiliser quoi que ce soit. Un fichier trouvé n'est jamais supposé être le bon.
- Option cochée mais connecteur absent : le dire en une phrase, proposer de le connecter, et demander en attendant de joindre les fichiers.
- Rien de trouvé : le dire, emplacements « À fournir ».

## Exceptions

- **Client public probable** (collectivité, établissement public, service de l'État, ou brief qui cite le RGAA) : le profil change la posture de tout le livrable. Sur une surface à trois questions, poser le profil à la place des pistes (les pistes passent en hypothèse : une si le brief est précis, deux s'il est ambigu). S'il n'y a pas de place non plus pour le profil, l'inscrire d'office en hypothèse « Conformité RGAA », en tête de livraison, en le signalant.
- **Support ambigu** (la demande ne dit pas s'il s'agit d'un site ou d'une app) : poser la question « Support » à la place des pistes (les pistes passent en hypothèse). Si la demande dit « app », « application » ou « écran mobile », ne pas la poser : c'est une app.
- **Avancer sans questions** : si la personne le demande (« pas de questions », « fais au mieux », « va vite »), aucune fenêtre ; appliquer les défauts du tableau et les lister en tête. Ne pas redemander au tour suivant.

## Les questions, par ordre de priorité

| # | En-tête | Question | Options | Choix multiple | Défaut sans réponse |
|---|---|---|---|---|---|
| 1 | Structure | Sur quoi on s'appuie pour la structure ? | Zoning ou wireframe, je le joins · Un site ou une capture existante, je les joins · Rien : propose une structure | non | Rien : structure proposée en hypothèse |
| 2 | Logo, médias | Qu'est-ce qu'on a du client ? | Je joins logo et médias · Chercher dans Google Drive · Charte seulement (couleurs, typos) · Rien pour l'instant | oui | Rien : emplacements « À fournir », aucune charte inventée ; si un existant du client est fourni (site, app, capture), relever ses couleurs et polices et les poser en hypothèse |
| 3 | Pistes | Combien de directions graphiques ? | Une direction · Deux pistes · Trois pistes · Au choix, selon le brief | non | Une si le brief est précis, deux s'il est ambigu |
| S | Support *(seulement si ambigu, voir Exceptions)* | Qu'est-ce qu'on conçoit ? | Site web · App mobile · Les deux | non | Site web, en hypothèse |
| 4 | Profil | Quel type de projet ? *(quatrième question : Claude Code seulement)* | Vitrine expressive · Conformité RGAA · Éco-conçu · Standard | oui | Standard, en hypothèse |

**Selon la réponse à la question 1** :

- **Zoning ou wireframe** : le lire comme un contrat de structure (`sources-entree.md`).
- **Site ou capture existante** : en extraire la structure (sections, ordre, contenus, actions) et la présenter comme point de départ, en distinguant ce qu'on garde de ce qu'on propose de changer ; en refonte, rien ne change en silence. L'existant sert de base de structure, pas de modèle visuel.
- **Rien** : proposer de passer d'abord par `lba-design:wireframe` ; si la personne préfère aller directement à la maquette, poser la structure en hypothèse, listée en tête.

Les **références** (sites que le client aime ou rejette) ne font plus l'objet d'une question : elles se demandent dans la phrase de relance. Sans elles, la direction part de ce que seul le client possède (`direction.md`). Sur une surface à trois questions, le profil et la version mobile dessinée deviennent des hypothèses en tête de livraison (`principles` §11), corrigeables en un mot.

**Phrase de relance**, juste après la fenêtre, adaptée à ce qui a été coché : « Joins-moi ce que tu as coché : [le zoning / l'URL ou les captures / le logo et les médias]. Si tu as des sites que le client aime ou rejette, colle aussi les liens. Je commence dès que je les ai, ou tout de suite avec des emplacements si tu préfères. »
