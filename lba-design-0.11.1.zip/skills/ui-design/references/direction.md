# Construire une direction

Méthode pour passer d'un brief à une direction graphique défendable, avant de poser le système (tokens, échelle, composants). À lire pour toute nouvelle direction, toute refonte visuelle et tout brief ambigu qui appelle plusieurs pistes. Pour une retouche ciblée dans une direction validée, sans objet.

Niveau : standard LBA pour les étapes (mode, références lues, parti pris écrit, critères de choix) ; tout le reste relève du jugement.

Une direction n'est pas une palette et deux fonts. C'est une décision sur **ce qui porte l'identité** de la page et **ce qu'on accepte de sacrifier** pour ça. Sans sacrifice nommé, on obtient une page correcte partout et mémorable nulle part.

## 1. Choisir le mode de la page

Le mode dit à quoi ressemble la réussite pour la personne qui arrive sur la page. Il se choisit **par page**, pas par client : la page d'accueil d'un organisme de formation persuade, sa page de recherche de formations fait agir, ses fiches font lire.

| Mode | La personne réussit quand… | Ce qui passe en premier | Où l'identité s'exprime |
|---|---|---|---|
| **Persuader** | elle comprend, est convaincue et agit (accueil, landing, offre, campagne) | une promesse claire, une preuve, une action | partout : composition, image, typographie, rythme |
| **Faire agir** | elle termine une tâche (recherche, filtres, formulaire, espace client) | lisibilité, constance, conventions attendues, états | dans les détails précis : un accent, une forme, un ton |
| **Faire lire** | elle comprend un contenu (article, fiche, actualité, documentation) | mesure de ligne, hiérarchie des titres, confort | dans la typographie et la mise en page éditoriale |
| **Faire vivre** | elle est dans l'œuvre elle-même (portfolio, galerie, récit, événement) | le contenu montré, dès le premier écran | l'interface s'efface derrière lui |

Un site combine plusieurs modes ; la direction doit tenir dans chacun. Une direction pensée pour le hero d'une page « Persuader » et plaquée sur une page « Faire agir » donne des filtres décoratifs et des formulaires illisibles.

## 2. Inventorier ce que seul le client possède

Avant de regarder ailleurs, lister ce qui appartient au client et qu'aucun concurrent ne peut reprendre :

- identité existante : logo, couleurs, typographies, charte, archives graphiques ;
- produit, savoir-faire, matières, gestes, lieux, territoire ;
- photographies réelles disponibles ou commandables (`lba-design:media`) ;
- vocabulaire propre (noms de gammes, de dispositifs, expressions du métier : lexique du DESIGN.md) ;
- ce que disent les usagers (`lba-design:synthesis`).

Question de contrôle : **qu'est-ce que seul ce client peut montrer ?** La réponse est presque toujours la meilleure matière d'une direction. Rien ne s'invente ici (`lba-design:principles` §1) : un savoir-faire supposé ou une histoire embellie n'est pas une matière, c'est un risque.

## 3. Lire les références, axe par axe

Une référence n'est utile que si on sait **ce qu'on lui prend**. Pour chaque référence (fournie par le client ou proposée par l'agence), remplir une ligne, et un seul axe par référence de préférence :

| Référence | Axe retenu | Ce qu'on prend précisément | Ce qu'on ne prend pas |
|---|---|---|---|
| [site, affiche, livre, objet] | Composition | grille asymétrique 5/7, grands blancs en tête de section | la navigation latérale |
| | Typographie | contraste d'échelle titre / texte d'environ 6 pour 1, titres serrés | la police elle-même |
| | Couleur | un fond chaud dominant, un accent rare | |
| | Image | photos au cadrage serré, sans mise en scène | |
| | Densité, rythme, mouvement | | |

Règles :

- **Les contre-références comptent autant** : ce que le client ne veut pas ressembler, et pourquoi.
- **Jamais une référence entière**, encore moins un concurrent direct : on emprunte un principe, pas une page.
- Références hors du web bienvenues (édition, signalétique, packaging, architecture) : elles éloignent des gabarits du secteur.
- Une référence fournie par le client sans explication : demander ce qui lui plaît dedans, ou formuler une hypothèse sur l'axe et la faire valider.

## 4. Écrire le parti pris

Une phrase, écrite avant de dessiner, en tête des hypothèses de livraison :

> **[Nom de la direction]** : en mode [mode], l'identité est portée par [levier principal], appuyé par [levier secondaire] ; on renonce à [sacrifice].

Leviers possibles, **un seul principal** : typographie, image, couleur, composition, matière (texture, rendu), mouvement. Deux leviers principaux se neutralisent.

Exemples de forme (génériques) :

- « Éditorial » : en mode Persuader, l'identité est portée par la typographie (titres de très grand corps, serrés), appuyée par une grille asymétrique ; on renonce à la couleur, réduite à un accent.
- « Atelier » : l'identité est portée par la photographie de gestes et de matières en pleine largeur, appuyée par une typographie sobre ; on renonce aux illustrations et aux pictogrammes décoratifs.
- « Signalétique » : l'identité est portée par la couleur en aplats francs par entité, appuyée par une typographie condensée ; on renonce aux images d'ambiance.

Le sacrifice est la partie la plus utile de la phrase : c'est lui qui empêche la direction de tout faire à moitié. Si on ne trouve rien à sacrifier, la direction n'est pas encore choisie.

## 5. Construire les pistes

- **Une piste** quand le brief est précis ; **deux ou trois** quand il est ambigu (`SKILL.md`, étape 4). Jamais plus de trois : au-delà, on transfère le travail de choix au client.
- Chaque piste a un **parti pris différent** : un autre levier principal, ou le même levier poussé dans une direction opposée. Deux pistes au même levier, qui ne diffèrent que par la couleur, n'en font qu'une.
- **Même contenu réel** dans toutes les pistes, sinon on compare des textes et non des directions.
- Ne pas dessiner trois sites complets. Une **planche de direction** par piste suffit pour choisir :
  1. le hero en 1440 et en 390 ;
  2. une section de contenu courant (liste d'actualités, fiche, bloc de texte long) : c'est là que les directions faibles s'effondrent ;
  3. les composants qui portent le plus l'identité : bouton, carte, titre de section, lien ;
  4. la ligne de parti pris et les principaux tokens (couleurs, échelle typographique).
- Une piste tiède se corrige en **poussant le levier principal** (plus grand, plus franc, plus rare), pas en ajoutant des effets. Une piste bruyante se corrige en retirant ce qui ne sert pas le levier.

## 6. Départager

Critères, dans cet ordre :

1. **Le mode** : la piste sert-elle l'action principale de chaque page clé ?
2. **Le contenu réel et le pire cas** : tient-elle avec les vrais textes, les vraies photos, les titres longs (`qa.md` §3) ?
3. **La distinction** : test d'identité du §4 ; retirer le logo, reconnaît-on encore le client ?
4. **La tenue à l'échelle du site** : se décline-t-elle sur une page de contenu ordinaire, pas seulement sur le hero ?
5. **Le coût** : production d'images, licences de fonts, poids, complexité de développement, autonomie du client dans son CMS.

Recommander une piste, avec la raison en deux lignes ; le client choisit. Une demande de **fusion** (« le haut de la A avec les couleurs de la C ») se traite comme une nouvelle piste avec son propre parti pris, jamais comme un collage : un mélange de deux directions n'en est aucune. En refonte, si la décision est de garder l'identité existante, la direction l'affine sans la retoucher à moitié ; si elle est de la remplacer, l'ancienne charte devient une contre-référence, pas un point de départ à polir.

## 7. Consigner

Une fois la piste choisie :

- journal de décisions de la fiche projet : piste retenue, parti pris, date, qui a validé (`livraison.md`) ;
- DESIGN.md (`lba-design:handoff`) : le parti pris en tête, les leviers, et les **interdits de la direction** (ce qu'on a sacrifié), pour qu'un autre designer ou un agent ne les réintroduise pas ;
- puis seulement : système avant écrans (`SKILL.md`, étape 5, et `fondations.md`).

## Pièges

- Une direction réduite à une palette et deux fonts, sans levier ni sacrifice.
- Trois pistes qui sont trois réglages d'une même idée.
- Une direction qui ne vit que dans le hero et disparaît dès la deuxième section.
- Une référence copiée au lieu d'être lue.
- Un parti pris dicté par les défauts maison ou par les habitudes de l'outil plutôt que par le client (anti-défauts du `SKILL.md`).
- Un parti pris qui sacrifie l'accessibilité : contraste, taille de texte et cibles sont hors arbitrage (`lba-design:principles` §4).

L'idée des modes de page et le refus de « couper la poire en deux » entre deux directions viennent d'Impeccable (Paul Bakaus, Apache 2.0) ; le reste est la méthode de l'agence. Voir `NOTICE`.
