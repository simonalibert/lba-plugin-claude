# Vocabulaire d'itération

Quand on demande « plus aéré » ou « plus de caractère », un modèle sans vocabulaire devine. Ce fichier donne à chaque verbe un sens fixe : les leviers qu'il actionne, dans quel ordre, et ce qu'il ne touche pas. Il sert dans les deux sens : comprendre une demande d'itération, et formuler une critique (« la section 3 gagnerait à être hiérarchisée »). Idée reprise d'Impeccable (Paul Bakaus, Apache 2.0), écrite pour l'agence : voir `NOTICE`.

## Règles

- **Un verbe, une passe.** Appliquer le verbe demandé, rien d'autre. Deux verbes dans la demande : les appliquer dans l'ordre du tableau (structure avant détail).
- **Leviers dans l'ordre**, du plus fort au plus fin : on s'arrête dès que l'effet est obtenu. Toucher d'abord la hiérarchie et l'espace, la couleur en dernier.
- **Toujours par les tokens** : changer une valeur de l'échelle ou un rôle, jamais une valeur libre écrite à la main. Si l'échelle ne permet pas l'effet, le dire et proposer de l'étendre (`fondations.md`).
- **Garde-fous** : un verbe ne lève jamais un impératif ni un invariant (contrastes, cibles, longueur de ligne, mouvement réduit). « Calmer » ne fait pas tomber un contraste sous le seuil ; « affirmer » ne passe pas une ligne au-delà de la limite.
- **Portée** : sans précision, le verbe s'applique à l'élément ou à la section désignés, pas à la page entière. Page entière : le dire en tête de la réponse.
- **Restituer** : après la passe, dire en une ligne ce qui a changé (« Espacements de section passés de `space-10` à `space-12`, accroche réduite d'un cran »). Le contrôle qualité de l'étape 7 s'applique ensuite comme d'habitude.

## Les verbes

| Verbe | Effet recherché | Leviers, dans l'ordre | Ne touche pas |
|---|---|---|---|
| **Hiérarchiser** | Qu'on sache en deux secondes quoi lire en premier | 1. Un seul élément dominant par écran ; 2. écart d'au moins deux crans d'échelle entre niveaux ; 3. graisse et couleur du texte secondaire ; 4. regrouper ce qui va ensemble | La palette |
| **Aérer** | Respiration, lecture plus posée | 1. Espacement entre sections ; 2. marges internes des blocs ; 3. interlignage du texte courant ; 4. retirer un élément secondaire plutôt que tout serrer | La taille des textes |
| **Densifier** | Plus d'information visible sans perdre la lisibilité | 1. Réduire les espacements intra-blocs d'un cran ; 2. passer une liste en grille ; 3. réduire les visuels décoratifs ; 4. compacter les métadonnées | Les cibles tactiles, la taille du texte courant |
| **Resserrer** | Une composition plus nette, moins flottante | 1. Aligner sur la grille et une colonne gauche commune ; 2. unifier les espacements identiques ; 3. réduire le nombre de largeurs de colonnes | La densité d'information |
| **Calmer** | Moins de bruit, plus de retenue | 1. Retirer des effets (ombres, filets, animations) ; 2. réduire le nombre de couleurs en usage ; 3. remplacer des graisses fortes par la taille ; 4. une seule accentuation par section | Les contrastes, la hiérarchie |
| **Affirmer** (la typo) | Plus de caractère, une typographie qui tranche | 1. Agrandir le titre dominant de plusieurs crans ; 2. contraste de graisse franc ; 3. interlignage et approche serrés sur les grands titres ; 4. famille d'affichage si le système en prévoit une | Le texte courant |
| **Contraster** | Des écarts plus francs entre éléments | 1. Taille ; 2. graisse ; 3. surface (fond inversé ou teinté) ; 4. couleur | Les seuils WCAG (on les dépasse, on ne descend jamais dessous) |
| **Rythmer** | Une page qui ne répète pas la même section | 1. Alterner les compositions (pleine largeur, deux colonnes, grille) ; 2. alterner les surfaces ; 3. varier la taille des visuels ; 4. un temps fort tous les deux ou trois écrans | Le contenu et l'ordre des sections (contrat de structure) |
| **Simplifier** | Moins d'éléments, même message | 1. Supprimer ce qui ne sert pas l'action principale ; 2. fusionner deux blocs redondants ; 3. réduire le nombre de styles de texte | Les contenus figés du contrat de structure (les proposer, ne pas les retirer) |
| **Réchauffer** / **refroidir** | Un registre plus chaleureux ou plus sobre | 1. Teinte des neutres ; 2. part de la couleur d'accent ; 3. traitement des images ; 4. rayons des angles | La couleur de marque du client |
| **Faire respirer les images** | Que les visuels portent la page | 1. Plus grands, moins nombreux ; 2. pleine largeur sur un temps fort ; 3. recadrage sur le sujet (impératif des visages) | Les ratios fixés avec `lba-design:media` |
| **Polir** | Finition, sans rien changer de structurel | 1. Alignements optiques ; 2. orphelins et coupures ; 3. états (survol, focus, actif) ; 4. typographie française | Tout ce qui précède : polir vient en dernier |

## Quand le verbe ne suffit pas

- Demande vague (« c'est pas ouf », « ça manque de quelque chose ») : proposer deux ou trois verbes du tableau avec, pour chacun, ce qu'il changerait, et laisser choisir.
- Verbes contradictoires (« aérer » et « densifier ») : le signaler et demander lequel prime, ou proposer de les appliquer à des sections différentes.
- Un verbe qui irait contre la direction validée (« réchauffer » une piste choisie pour sa froideur) : le signaler, la direction validée est une décision du projet (`lba-design:principles` §10).
