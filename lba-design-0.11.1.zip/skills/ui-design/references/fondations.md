# Fondations : typographie et couleur

Méthode pour poser la typographie et la couleur d'une direction, entre le parti pris (`direction.md`) et les écrans, puis les traduire en tokens (dernière section). Si le client a une charte ou un design system, on part de lui : ce fichier sert alors à le compléter pour le web (échelle, rôles, états), jamais à le remplacer.

Niveaux : les seuils viennent de `lba-design:principles` §4 (principe) ; les étapes ci-dessous sont un standard LBA (on les fait, on peut s'en écarter en le disant) ; les valeurs proposées sont des conventions.

## Typographie

### Choisir les familles

1. **Partir du parti pris.** Si la typographie est le levier principal, elle porte le caractère et mérite une famille affirmée ; si c'est l'image ou la couleur, elle doit servir sans concurrencer.
2. **Contrôler l'usage réel**, pas l'échantillon : composer un titre de la longueur la plus fréquente, un paragraphe de 600 caractères et un libellé de bouton en français, avec accents, apostrophes typographiques, guillemets « », chiffres et « œ ». Une famille qui ne gère pas bien le français ou les chiffres est écartée, quelle que soit sa beauté.
3. **Vérifier avant de proposer** : licence web (auto-hébergement autorisé, nombre de pages vues ou de domaines), graisses et largeurs disponibles, axes variables, sous-ensemble latin étendu, chiffres tabulaires, petites capitales si la direction en use. Une famille dont la licence n'est pas confirmée reste « provisoire » dans les hypothèses.
4. **Une ou deux familles, pas trois.** Associer deux familles quand elles diffèrent nettement (un caractère de titre expressif et un caractère de texte neutre, ou une linéale et une serif) ; deux linéales proches donnent une page qui hésite. Une seule famille variable avec deux largeurs ou deux graisses éloignées suffit souvent.

### Construire l'échelle

- **Rapport de progression** choisi selon la direction, puis arrondi au pixel : environ 1,2 pour une page dense ou un site de service, 1,25 à 1,333 pour un site institutionnel, 1,5 et plus quand la typographie est le levier principal. Le rapport sert de point de départ ; les tailles finales se règlent à l'œil sur le contenu réel.
- **Deux échelles, desktop et mobile**, pas une seule réduite : l'écart entre titre et texte se resserre en 390 (un H1 de 72 px en desktop ne devient pas 72 × 390/1440).
- **Typographie fluide** entre les deux : `clamp(min-rem, calcul-vw, max-rem)`, jamais de `vw` seul, qui bloque le zoom du texte (WCAG 1.4.4).
- **Chaque style nommé** a sa taille, sa graisse, son interligne, son approche (letter-spacing) et son comportement responsive (défauts du `SKILL.md`). Interligne : 1,4 à 1,6 pour le texte courant, plus serré pour les grands titres (1 à 1,15) ; approche négative légère sur les grands titres, positive sur les petites capitales.
- **Mesure** : paragraphes en `ch`, seuil de `lba-design:principles` §4.

### Détails qui font la différence

- Chiffres : `font-variant-numeric: lining-nums tabular-nums` dans les tableaux, compteurs et prix alignés (`tabular-nums` seul laisse des chiffres elzéviriens si la police les utilise par défaut : vérifier le style de chiffres de la police choisie) ; chiffres elzéviriens seulement dans un texte éditorial qui s'y prête.
- Césure : `hyphens: auto` avec `lang="fr"` sur les colonnes étroites et en 390, jamais sur les titres.
- Police de repli calée sur la webfont (`size-adjust`, `ascent-override` dans un `@font-face` de repli) pour éviter le saut de mise en page au chargement.
- Graisses réellement utilisées seulement, en woff2, sous-ensemble latin.

## Couleur

### Construire la palette

1. **Partir des couleurs du client** et les mesurer (valeurs exactes, pas une capture). Les placer dans un espace perceptif (OKLCH) pour raisonner en clarté, saturation et teinte : deux couleurs de même clarté OKLCH paraissent aussi claires l'une que l'autre, ce qui n'est pas vrai en HSL.
2. **Fixer les proportions** avant les valeurs : une couleur dominante (souvent un neutre ou un fond de marque), une couleur de structure, un accent rare. Un accent présent partout n'accentue plus rien. Quand la couleur est le levier principal du parti pris, la proportion s'inverse : de grands aplats, et le neutre devient l'exception.
3. **Neutres teintés** : dériver les gris d'une teinte de la palette (chroma très faible) plutôt que des gris purs ; une seule famille de neutres, jamais un mélange de gris chauds et froids.
4. **Dériver les états** (survol, actif, désactivé, focus) par variation de clarté du même token, pas par des couleurs nouvelles ; le focus garde un contraste suffisant sur toutes les surfaces (token `focus/ring`, plus bas).
5. **Couleurs de statut** (succès, alerte, erreur, information) : seulement si l'interface en a besoin, accordées à la palette, toujours doublées d'un texte ou d'une icône (WCAG 1.4.1).
6. **Calculer chaque paire** texte / surface réellement utilisée avec `contrast.py`, et pas seulement le texte courant : texte secondaire, texte sur accent, texte sur image, placeholder, état désactivé lisible.

Client à plusieurs entités : une couleur par entité, appliquée à l'identique aux tags, pastilles, cartes et CTA.

### Mode sombre

Pas de mode sombre par défaut sur un site institutionnel ou de marque : c'est une décision projet, à prendre selon la situation d'usage (lecture longue le soir, application utilisée en continu) et le budget de recette, puisqu'il double les contrôles de contraste et de captures. S'il est décidé : deux jeux de valeurs pour les mêmes rôles (la logique surface / inverse, plus bas, s'étend), pas de noir pur ni de blanc pur en grande surface, ombres remplacées par des différences de clarté, images et logos vérifiés sur fond sombre, et `qa.py` lancé dans les deux modes.

## Tokens

Primitives (la palette, l'échelle) puis rôles en alias ; les composants ne consomment que des rôles.

### Rôles minimum

- Surfaces : `surface/base`, `surface/subtle`, `surface/elevated`, `surface/inverse`, `surface/accent`
- Texte : `text/primary`, `text/secondary`, `text/inverse`, `text/on-accent`
- Bordures : `border/subtle`, `border/strong`
- Accent : `accent/*` (une entrée par entité si le client en a plusieurs)
- Focus : `focus/ring` et `focus/ring-inverse`

Chaque paire texte/surface utilisée est vérifiée selon les seuils de `lba-design:principles` §4.

### Surface et inverse

Un composant garde sa logique quand il change de surface : seuls les tokens changent.

```css
:root            { --surface: #fff; --text: #111; --border: #d0d0d0; --focus-ring: #111; }
[data-surface="inverse"] { --surface: #111; --text: #fff; --border: #444; --focus-ring: #fff; }
.btn { color: var(--text); border-color: var(--border); }
.btn:focus-visible { outline: 2px solid var(--focus-ring); outline-offset: 2px; }
```

### Handoff

Format des tokens (DTCG), contenu du handoff, spécification d'écran et annotations Figma : `lba-design:handoff`.

## Avant de passer aux écrans

Une planche de fondations, une seule page : échelle typographique complète en 390 et 1440 avec du vrai contenu, palette avec ses proportions, chaque paire de contraste et son ratio calculé, états d'un bouton et d'un lien sur chaque surface. Si cette planche n'a pas de caractère, les écrans n'en auront pas : revenir au parti pris plutôt que d'ajouter des effets.
