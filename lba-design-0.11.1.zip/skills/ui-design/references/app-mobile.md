# Écran d'app mobile et prototype interactif

Le plugin est d'abord pensé pour le web. Pour un écran d'application ou un prototype interactif, la méthode reste la même (cadrage, direction, système, écrans, passe qualité, fiche projet) ; cette check-list ajoute ce qui change. Version courte, à enrichir au fil des projets d'app.

## Cadre

- **Taille de référence** : 390 × 844 (iPhone courant) ; vérifier en 360 de large (Android courant). Présenter l'écran dans un cadre de smartphone sobre, sans maquette de téléphone décorative.
- **Zones sûres** : rien d'interactif ni de texte essentiel sous la barre d'état ni dans la zone de l'indicateur d'accueil ; en HTML, `env(safe-area-inset-*)`.
- **Plateforme** : demander iOS, Android ou les deux si ce n'est pas dit ; sans réponse, conventions neutres (ni barre de navigation iOS, ni bouton flottant Android imposé) et le dire en hypothèse.

## Navigation et interaction

- **Navigation principale** : barre d'onglets en bas, de 3 à 5 entrées, libellé sous chaque icône ; jamais d'icône seule pour une destination principale.
- **Action principale** dans la zone du pouce (moitié basse de l'écran) ; actions destructrices loin de l'action principale.
- **Cibles** : en app, 44 × 44 au moins pour tout élément interactif, pas seulement la navigation et les CTA (recommandations d'Apple : 44 pt ; de Material Design : 48 dp). C'est plus exigeant que le minimum de `lba-design:principles` §4, qui reste le plancher.
- **Gestes** : jamais le seul moyen d'accomplir une action (balayage doublé d'un bouton visible).
- **États** : chargement, vide, erreur, hors connexion pour chaque écran qui charge des données ; retour haptique et animations décrits pour le dev, pas seulement dessinés.

## Prototype interactif

- Rendre cliquables les parcours demandés, pas toute l'app : les autres écrans restent des options proposées (comme pour le wireframe).
- Un seul fichier, transitions sobres, `prefers-reduced-motion` respecté (`lba-design:motion`).
- Données de démonstration réalistes mais génériques, jamais de faux chiffres présentés comme réels ; « À fournir » sinon.

## Contexte d'usage

- Usage terrain (industrie, chantier, extérieur) : contraste renforcé pour la lumière forte, textes et cibles plus grands, saisie minimale, gants possibles. À poser en hypothèse si le brief évoque le terrain.
