# Maquette haute fidélité directement dans Figma

`ui-design` pilote ; les skills Figma portent la technique (`figma:figma-use`, `figma:figma-generate-design`, `lba-design:figma`). Les impératifs ne changent pas, leur mise en œuvre et leur contrôle si.

## Traduction des impératifs (`SKILL.md`, « Impératifs »)

| Impératif | En HTML | Dans Figma |
|---|---|---|
| 1. CTA centrés optiquement | `text-box: trim-both cap alphabetic` | `leadingTrim: CAP_HEIGHT` sur le style du libellé, auto-layout centré ; corriger les instances avant le style partagé (piège documenté dans `lba-design:figma` §3) |
| 2. Filets entre éléments | `:not(:last-child)` | Pas de filet sur le premier ni le dernier élément ; préférer le séparateur d'auto-layout ou un composant séparateur placé entre |
| 3. Ligne de base partagée | Mesure en capture | Aligner les premières lignes ; vérifier par capture zoomée |
| 4. Grille de 8 | Variables d'espacement | Espacements et paddings liés aux variables d'espacement du fichier, jamais en valeur libre |
| 5. Longueur de ligne | `max-width` en `ch` | Largeur fixe du bloc de texte calculée pour la limite de `lba-design:principles` §4 à la taille de corps |
| 6. Pas d'orphelin | `text-wrap` | Ajuster à la main et vérifier à chaque largeur dessinée |
| 9. Visages jamais coupés | `object-position` | Recadrage de l'image vérifié dans chaque frame 390 et 1440 |
| 10. Contraste | Script `qa.py` | `contrast.py` (`lba-design:accessibility`) sur chaque paire texte / fond utilisée |
| 11. États complets | CSS | Variantes de composant pour chaque état, focus visible compris ; états vide, chargement, erreur dessinés pour les contenus chargés |
| 12. Cibles | Mesure | Hauteur et largeur des zones cliquables dans les propriétés du composant |
| 13. Sémantique, 14. Mouvement réduit | Code | Ne se voient pas dans Figma : les porter en annotation pour le dev (`lba-design:handoff`) |
| 16. Responsive | Cinq largeurs | Frames 390 et 1440 au minimum, autres largeurs seulement si la structure y change |

## Contrôle qualité (`qa.py` ne s'applique pas)

1. Inspecter la structure (`get_metadata`) et lire les variables (`get_variable_defs`) : couleurs, espacements et textes liés aux variables et aux styles, aucune valeur libre non déclarée.
2. Calculer les contrastes avec `contrast.py`.
3. Capturer chaque frame (`get_screenshot`) et regarder ce que les propriétés ne montrent pas : filets, alignements, recadrages, hiérarchie.
4. Passer l'audit d'hygiène de `lba-design:figma` avant de présenter au client.
5. Dans le rapport, dire que le contrôle est visuel et par propriétés, sans script : c'est une pré-évaluation.
