# Livraison, versions et décisions

## Versions

- Nouvelle direction ou refonte : nouvelle version `Nom vN+1`, les précédentes restent intactes. Retouche ciblée : modification sur place, et rien d'autre.
- Ligne de version dans la fiche projet : `v12 (JJ/MM) : parti pris « Éditorial », impératifs appliqués, 1440 (+ 390 si mobile dessiné)`.

## Décisions

- Toute décision (direction retenue, écart à un impératif, abandon d'un défaut, choix de profil) se consigne, datée, dans le journal de la fiche projet. Une décision validée n'est rouverte que sur demande, nouvelle contrainte ou conflit avec un invariant ; la réouverture se consigne aussi.
- Si la fiche projet est un doc modifiable par Claude, y écrire directement ; sinon fournir le bloc à coller.
- Les décisions qui engagent le développement (tokens, comportements, profil) passent aussi dans le DESIGN.md (`lba-design:handoff`).

```markdown
### JJ/MM/AAAA : titre court
Décision : …
Pourquoi : …
Conséquence : …
Statut : validée par <nom> | à valider
```

## Rapport de livraison (modèle)

Dans cet ordre, court. Pas de coche sans chiffre ni capture correspondante.

```markdown
## Nom vN : livraison du JJ/MM

**Fait** : 2 à 3 lignes.

**Profil** : vitrine expressive ; version mobile dessinée : oui.
**Parti pris** : « Éditorial » : en mode Persuader, l'identité est portée par la typographie, appuyée par une grille asymétrique ; on renonce à la couleur, réduite à un accent.
**Hypothèses** : lecture du brief ; desktop 1440 / mobile 390 ; font X provisoire (licence non confirmée) ; défauts maison appliqués (ex. CTA en capitales condensées) ; …
**Décisions** : liste courte (reportées au journal).

**Écarts**
- Impératif n°4 : padding hero à 60px, alignement optique avec le logo (capture 1440).
- Wireframe, section Actualités : 3 articles au lieu de 4, le 4e passait sous la ligne de flottaison.

**QA**
Vérifié
- axe-core : 0 violation ; 2 contrastes « à vérifier » sur image, contrôlés à la main.
- Débordement : aucun aux 5 largeurs. Cibles < 24px : 0. Focus invisible : 0.
- Poids : page 1,2 Mo, plus grosse image 210 Ko, 2 familles (4 fichiers).
- Contrôle visuel 390 / 924 / 1440 : filets, lignes de base, colonne gauche, recadrages.
- Anti-défauts : 1 signalé par le script (filet latéral sur les encadrés), conservé et justifié (charte client).
- Pire cas : 9 champs testés, 3 casses, 2 corrigées, 1 à valider (titre d'actualité au-delà de 3 lignes).
Non vérifié
- Animations GSAP en mouvement réduit : pas de navigateur de test disponible ici.
Hors périmètre
- Audit de conformité RGAA, restitution lecteur d'écran, recette en code.

**À valider** : …
**À fournir par le client** : textes, chiffres, photos, logos partenaires, licences de fonts.
```

## Livrables

Le design (artefact ou HTML autonome), PNG pleine page 1440 (et 390 si la version mobile est dessinée), HTML autonome hors ligne (photos compressées, fonts réduites aux graisses utilisées), handoff dev pour toute version validée (tokens et composants avec leurs états, à produire avec `lba-design:handoff`).
