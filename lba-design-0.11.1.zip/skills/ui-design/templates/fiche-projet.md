# Fiche projet : <Client / Nom du site>

> Méthode : plugin `lba-design` (`ui-design`, `wireframe`…). Dans une conversation reprise ou résumée, recharger le skill concerné avant toute modification ; cette fiche fait foi.

## Sources
- Wireframe : <lien claude.ai ou Figma> (statut : validé client le JJ/MM | à challenger)
- Design system : <nom exact du design system client>
- Site actuel : <URL>
- Figma : <lien fichier / page>
- Contenus : <lien doc ou dossier> ; langue de l'interface : <celle des utilisateurs finaux> ; termes à reprendre des documents source : lexique du DESIGN.md (§2.2), sinon ici
- Médias : <dossier photos, logos, pictos> (banque d'images autorisée : oui/non)
- Fonts : <noms, fichiers, licence web oui/non>

## Contrat de structure
- Figé : <ex. ordre des sections, libellés du menu, CTA du hero>
- Ajustable : <ex. nombre d'actualités, proportions>
- Libre : traitement visuel

## Cadre
- Publics prioritaires et action principale : …
- Intention (3 à 5 mots) : …  Références (avec l'axe retenu pour chacune) : …  Contre-références : …
- Mode des pages clés : <ex. accueil : persuader ; recherche : faire agir ; fiches : faire lire>
- Ce que seul le client possède : …
- Parti pris retenu : <nom> : levier principal …, appui …, sacrifice … (validé le JJ/MM par …)
- Contraintes : accessibilité (référentiel visé), CMS / techno cible, navigateurs, hébergement
- Confidentialité : contenus non publics autorisés dans les maquettes partagées ? oui/non

## Profil et livrables
- Profil (`lba-design:principles` §11) : [ ] standard  [ ] vitrine expressive  [ ] conformité RGAA  [ ] éco-conçu
- Version mobile dessinée : oui / non (si non : comportement mobile décrit dans la spec)
- Repères de taille ajustés à la police (sinon, repères de `principles` §4) : texte courant … px ; libellés … px

Cocher en remplaçant `[ ]` par `[x]` : `scripts/qa.py --fiche` lit cette section pour appliquer le profil.
- Arbitrages entre profils, s'il y en a deux : …

## Défauts maison écartés
- <ex. boutons 56px ; pas de capitales condensées ; rayon 0 ; CTA à 13 px car la police a une grande hauteur d'x, vérifié au zoom 200 %>

## Versions
- v1 (JJ/MM) : …

## Décisions
<journal au format de references/livraison.md>

## À fournir par le client
- …
