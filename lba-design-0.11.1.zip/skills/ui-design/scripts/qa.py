#!/usr/bin/env python3
"""Pre-delivery QA for web mockups (La Bonne Agence).

Takes full-page screenshots at control widths and runs automated checks:
axe-core (WCAG 2.2 A/AA), horizontal overflow, reduced text opacity,
invisible focus, line length, heading wrap, target size, off-grid spacing,
reduced motion, French typography, media / font / page weight, and
generation tells (gradient text, side stripes, hard shadows, ease-in, etc.).

This is a pre-check, not an accessibility compliance audit.

Usage:
    python3 qa.py <page.html | http://localhost:...> [--out qa] [--widths 390,768,924,1280,1440] [--shots-only] [--quiet] [--fiche fiche-projet.md] [--eco] [--min-text 14] [--min-body 16]
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import subprocess
import sys
import urllib.parse
from typing import Any

from playwright.sync_api import Page, sync_playwright

DEFAULT_WIDTHS = [390, 768, 924, 1280, 1440]
AXE_TAGS = ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"]
IMG_LIMIT_BYTES = 250 * 1024
PAGE_LIMIT_BYTES = 1536 * 1024  # home page budget (references/qa.md §1, convention to calibrate)
FONT_FILES_LIMIT = 4
CACHE_DIR = pathlib.Path.home() / ".cache" / "lba-qa"

# In-page checks. Returns a dict of findings for the current viewport.
CHECKS_JS = r"""
(opts) => {
  const vw = document.documentElement.clientWidth;
  const out = {};
  const sel = (el) => {
    let s = el.tagName.toLowerCase();
    if (el.id) s += '#' + el.id;
    else if (el.classList.length) s += '.' + [...el.classList].slice(0, 2).join('.');
    const t = (el.innerText || el.getAttribute('aria-label') || '').trim().replace(/\s+/g, ' ');
    return t ? `${s} « ${t.slice(0, 40)} »` : s;
  };
  const visible = (el) => {
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden') return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  };
  const all = [...document.querySelectorAll('body *')].filter(visible);

  // Horizontal overflow
  out.overflow = document.documentElement.scrollWidth > vw + 1;
  out.overflowOffenders = out.overflow
    ? all.filter(el => el.getBoundingClientRect().right > vw + 1).slice(0, 8).map(sel) : [];

  // Target size
  const interactiveSel = 'a[href], button, input:not([type=hidden]), select, textarea, summary, [role=button], [role=switch], [role=tab], [role=checkbox], [role=radio], [tabindex]:not([tabindex="-1"])';
  const inlineLink = (el) => {
    if (el.tagName !== 'A') return false;
    const p = el.parentElement;
    if (!p || !['P', 'LI', 'SPAN', 'TD', 'DD'].includes(p.tagName)) return false;
    return (p.innerText || '').trim().length > (el.innerText || '').trim().length + 10;
  };
  const targets = [...document.querySelectorAll(interactiveSel)].filter(visible);
  out.targetsUnder24 = []; out.targetsUnder44 = [];
  for (const el of targets) {
    if (inlineLink(el)) continue;
    const r = el.getBoundingClientRect();
    const m = Math.min(r.width, r.height);
    const item = `${sel(el)} (${Math.round(r.width)}×${Math.round(r.height)})`;
    if (m < 24) out.targetsUnder24.push(item);
    else if (m < 44) out.targetsUnder44.push(item);
  }

  // Line length in ch
  const chWidth = (el) => {
    const s = document.createElement('span');
    s.textContent = '0000000000';
    s.style.cssText = 'position:absolute;visibility:hidden;white-space:nowrap;font:inherit;letter-spacing:inherit';
    el.appendChild(s);
    const w = s.getBoundingClientRect().width / 10;
    s.remove();
    return w || 8;
  };
  out.longLines = [];
  for (const el of all.filter(e => ['P', 'LI', 'DD', 'BLOCKQUOTE'].includes(e.tagName))) {
    if ((el.innerText || '').length < 160) continue;
    const ch = el.clientWidth / chWidth(el);
    if (ch > opts.maxCh) out.longLines.push(`${sel(el)} (${Math.round(ch)}ch)`);
  }

  if (!opts.full) return out;

  // Headings / paragraphs wrap
  const wrapStyle = (el) => { const cs = getComputedStyle(el); return cs.textWrapStyle || cs.textWrap || ''; };
  out.headingsNoBalance = all.filter(e => /^H[1-3]$/.test(e.tagName) && !wrapStyle(e).includes('balance')).slice(0, 10).map(sel);
  const paras = all.filter(e => e.tagName === 'P' && (e.innerText || '').length > 80);
  out.parasNoPretty = { count: paras.filter(e => !wrapStyle(e).includes('pretty')).length, total: paras.length };

  // Reduced text opacity or translucent text color
  out.textOpacity = [];
  for (const el of all) {
    const hasText = [...el.childNodes].some(n => n.nodeType === 3 && n.textContent.trim());
    if (!hasText || el.closest('[aria-hidden="true"]')) continue;
    let op = 1, a = el;
    while (a && a !== document.documentElement) { op *= parseFloat(getComputedStyle(a).opacity); a = a.parentElement; }
    const c = getComputedStyle(el).color.match(/rgba?\(([^)]+)\)/);
    const alpha = c && c[1].split(/[ ,/]+/).length > 3 ? parseFloat(c[1].split(/[ ,/]+/)[3]) : 1;
    if (op < 0.999 || alpha < 0.999) out.textOpacity.push(`${sel(el)} (opacité ${op.toFixed(2)}, alpha ${alpha.toFixed(2)})`);
    if (out.textOpacity.length >= 12) break;
  }

  // Off-grid spacing (padding and gap; margins skipped because auto resolves to px)
  const props = ['paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'rowGap', 'columnGap'];
  const off = {};
  for (const el of all) {
    const cs = getComputedStyle(el);
    for (const p of props) {
      const v = parseFloat(cs[p]);
      if (!v || isNaN(v)) continue;
      const r = Math.round(v * 2) / 2;
      if (r % 4 !== 0) { (off[r] = off[r] || []).push(sel(el)); }
    }
  }
  out.offGrid = Object.entries(off).sort((a, b) => b[1].length - a[1].length).slice(0, 8)
    .map(([v, els]) => `${v}px ×${els.length} (ex. ${els[0]})`);

  // French typography (text nodes only, skip code, URLs, times)
  out.frTypo = [];
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  const bad = /([A-Za-zÀ-ÿ0-9»)\]])([:;!?])(?=\s|$)|( )([:;!?»])|(«)( )/g;
  let n;
  while ((n = walker.nextNode()) && out.frTypo.length < 12) {
    const p = n.parentElement;
    if (!p || p.closest('code, pre, script, style, [aria-hidden="true"]') || !visible(p)) continue;
    const t = n.textContent;
    if (/https?:|www\.|\d:\d/.test(t)) continue;
    bad.lastIndex = 0;
    const m = bad.exec(t);
    if (m) out.frTypo.push(`${sel(p)} : « …${t.slice(Math.max(0, m.index - 15), m.index + 5).trim()}… »`);
  }
  out.straightQuotes = [...document.body.innerText.matchAll(/"[^"\n]{2,60}"/g)].slice(0, 5).map(m => m[0]);

  // Images: natural vs rendered size
  out.images = [...document.images].filter(visible).map(img => {
    const r = img.getBoundingClientRect();
    return { src: img.currentSrc || img.src, natural: [img.naturalWidth, img.naturalHeight],
             rendered: [Math.round(r.width), Math.round(r.height)], srcset: !!img.srcset,
             alt: img.getAttribute('alt'), lazy: img.loading === 'lazy', top: Math.round(r.top + scrollY) };
  });
  out.bgImages = [...new Set(all.map(el => getComputedStyle(el).backgroundImage)
    .filter(b => b && b.startsWith('url(')).map(b => b.slice(4, -1).replace(/["']/g, '')))];
  out.autoplay = [...document.querySelectorAll('video[autoplay], audio[autoplay]')].map(sel);

  // Fonts actually loaded
  out.fonts = [...document.fonts].filter(f => f.status === 'loaded')
    .map(f => `${f.family.replace(/["']/g, '')} ${f.weight} ${f.style}`);

  // Baseline styles for focus check
  window.__qaTargets = targets;
  window.__qaBase = targets.map(el => { const cs = getComputedStyle(el);
    return [cs.outlineStyle, cs.outlineWidth, cs.outlineColor, cs.boxShadow, cs.borderColor, cs.backgroundColor, cs.textDecorationLine, cs.color].join('|'); });
  out.focusCandidates = targets.length;
  return out;
}
"""

FOCUS_STEP_JS = r"""
() => {
  const el = document.activeElement;
  if (!el || el === document.body) return null;
  const i = (window.__qaTargets || []).indexOf(el);
  const cs = getComputedStyle(el);
  const now = [cs.outlineStyle, cs.outlineWidth, cs.outlineColor, cs.boxShadow, cs.borderColor, cs.backgroundColor, cs.textDecorationLine, cs.color].join('|');
  const hasOutline = cs.outlineStyle !== 'none' && parseFloat(cs.outlineWidth) > 0;
  const changed = i >= 0 ? now !== window.__qaBase[i] : hasOutline;
  let s = el.tagName.toLowerCase() + (el.id ? '#' + el.id : '');
  const t = (el.innerText || el.getAttribute('aria-label') || '').trim().replace(/\s+/g, ' ').slice(0, 40);
  return { key: s + '|' + t, label: t ? `${s} « ${t} »` : s, visible: hasOutline || changed };
}
"""

MOTION_JS = r"""
() => {
  // Under reduced motion, opacity and color may still change (not motion per WCAG 2.3.3);
  // movement and blur may not. Returns { moving: [...], unclear: [...] }.
  const MOVING = /^(transform|translate|scale|rotate|filter|backdrop-filter|top|left|right|bottom|inset|margin.*|width|height|clip-path|offset.*)$/;
  const keyframeProps = {};
  for (const sheet of document.styleSheets) {
    let rules; try { rules = sheet.cssRules; } catch (e) { continue; }
    for (const r of rules) if (r.type === CSSRule.KEYFRAMES_RULE) {
      const props = new Set();
      for (const kf of r.cssRules) for (let i = 0; i < kf.style.length; i++) props.add(kf.style[i]);
      keyframeProps[r.name] = [...props];
    }
  }
  const label = (el) => el.tagName.toLowerCase() + (el.className && typeof el.className === 'string' ? '.' + el.className.split(' ')[0] : '');
  const dur = (v) => Math.max(...v.split(',').map(x => parseFloat(x) * (x.includes('ms') ? 0.001 : 1)));
  const moving = new Set(), unclear = new Set();
  for (const el of document.querySelectorAll('body *')) {
    const cs = getComputedStyle(el);
    if (dur(cs.transitionDuration) > 0.01) {
      const props = cs.transitionProperty.split(',').map(s => s.trim());
      if (props.some(p => MOVING.test(p))) moving.add(label(el) + ' (transition : ' + props.filter(p => MOVING.test(p)).join(', ') + ')');
      else if (props.includes('all')) unclear.add(label(el) + ' (transition : all)');
    }
    if (cs.animationName !== 'none' && dur(cs.animationDuration) > 0.01) {
      for (const name of cs.animationName.split(',').map(s => s.trim())) {
        const props = keyframeProps[name];
        if (!props) unclear.add(label(el) + ' (animation ' + name + ' : images clés illisibles)');
        else if (props.some(p => MOVING.test(p))) moving.add(label(el) + ' (animation ' + name + ')');
      }
    }
  }
  return { moving: [...moving], unclear: [...unclear] };
}
"""


# Generation tells (signals, not errors): see SKILL.md, "Anti-défauts".
TELLS_JS = r"""
(opts) => {
  const out = { gradientText: [], sideStripe: [], hardShadow: [], transitionAll: [], easeIn: [],
                sectionNumbers: [], dotSeparators: [], emojiIcons: [], numbersNotTabular: 0, selectionStyled: false,
                textUnder14: [], bodyUnder16: [] };
  const sel = (el) => {
    let s = el.tagName.toLowerCase();
    if (el.id) s += '#' + el.id;
    else if (el.classList.length) s += '.' + [...el.classList].slice(0, 2).join('.');
    const t = (el.innerText || '').trim().replace(/\s+/g, ' ');
    return t ? `${s} « ${t.slice(0, 40)} »` : s;
  };
  const visible = (el) => {
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden') return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  };
  const push = (arr, v) => { if (arr.length < 12 && !arr.includes(v)) arr.push(v); };
  const neutral = (c) => {  // gray or transparent
    const m = c.match(/[\d.]+/g); if (!m) return true;
    const [r, g, b, a = 1] = m.map(Number);
    return a === 0 || (Math.max(r, g, b) - Math.min(r, g, b) < 16);
  };
  const ownText = (el) => [...el.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent).join('').trim();
  const easeInLike = (tf) => tf.split(/,(?![^(]*\))/).some(f => {
    f = f.trim();
    if (f === 'ease-in') return true;
    const m = f.match(/cubic-bezier\(([^)]+)\)/); if (!m) return false;
    const [x1, y1, x2, y2] = m[1].split(',').map(Number);
    return x1 >= 0.25 && y1 <= 0.1 && x2 >= 0.9 && y2 >= 0.9;  // slow start, linear-ish end
  });
  const dur = (v) => Math.max(...v.split(',').map(x => parseFloat(x) * (x.includes('ms') ? 0.001 : 1)));

  for (const el of document.querySelectorAll('body *')) {
    if (!visible(el)) continue;
    const cs = getComputedStyle(el);
    const txt = ownText(el);
    if (txt && (cs.backgroundClip === 'text' || cs.webkitBackgroundClip === 'text') && cs.backgroundImage.includes('gradient'))
      push(out.gradientText, sel(el));
    const bl = parseFloat(cs.borderLeftWidth), br = parseFloat(cs.borderRightWidth);
    const bt = parseFloat(cs.borderTopWidth), bb = parseFloat(cs.borderBottomWidth);
    const side = bl > 1 ? ['Left', bl] : br > 1 ? ['Right', br] : null;
    if (side && cs.display !== 'inline' && el.tagName !== 'HR' && Math.max(bt, bb) <= 1
        && cs[`border${side[0]}Style`] !== 'none' && !neutral(cs[`border${side[0]}Color`]))
      push(out.sideStripe, `${sel(el)} (${side[1]}px ${side[0] === 'Left' ? 'gauche' : 'droite'})`);
    if (cs.boxShadow !== 'none' && cs.boxShadow.split(/,(?![^(]*\))/).some(s => {
          const n = s.replace(/rgba?\([^)]*\)/, '').match(/-?[\d.]+px/g) || [];
          return n.length >= 3 && parseFloat(n[2]) === 0 && (parseFloat(n[0]) !== 0 || parseFloat(n[1]) !== 0);
        }))
      push(out.hardShadow, sel(el));
    if (dur(cs.transitionDuration) > 0.01) {
      if (cs.transitionProperty.split(',').some(p => p.trim() === 'all')) push(out.transitionAll, sel(el));
      if (easeInLike(cs.transitionTimingFunction)) push(out.easeIn, sel(el) + ' (transition)');
    }
    if (cs.animationName !== 'none' && easeInLike(cs.animationTimingFunction)) push(out.easeIn, sel(el) + ' (animation)');
    if (txt && txt.length > 1) {  // text sizes (principles §4): nothing under 14px, running text >= 16px
      const fs = parseFloat(cs.fontSize);
      if (fs < opts.minText) push(out.textUnder14, `${sel(el)} (${fs}px)`);
      else if (fs < opts.minBody && el.matches('p, li, dd, td, blockquote') && txt.length > 80) push(out.bodyUnder16, `${sel(el)} (${fs}px)`);
    }
    if (txt && /^0\d(\s*[\/·.\-–—]|$)/.test(txt) && txt.length < 40) push(out.sectionNumbers, sel(el));
    if (txt && (txt.match(/ · /g) || []).length >= 2) push(out.dotSeparators, sel(el));
    if (txt && txt.length <= 3 && /\p{Extended_Pictographic}/u.test(txt) && el.closest('a,button,li,nav,[role=button]'))
      push(out.emojiIcons, sel(el.closest('a,button,li,nav,[role=button]')));
    if (el.matches('td, th, [data-number], output') && txt && /^[\s\d.,%€$+\-−  ]+$/.test(txt)
        && /\d/.test(txt) && !cs.fontVariantNumeric.includes('tabular-nums'))
      out.numbersNotTabular++;
  }
  try {
    out.selectionStyled = [...document.styleSheets].some(s => {
      try { return [...s.cssRules].some(r => (r.selectorText || '').includes('::selection')); } catch (e) { return false; }
    });
  } catch (e) { out.selectionStyled = null; }
  return out;
}
"""


def read_fiche(path: str) -> dict[str, Any]:
    """Read profile and size references from a fiche projet (templates/fiche-projet.md)."""
    import re
    text = pathlib.Path(path).read_text(encoding="utf-8")
    checked = [m.strip().lower() for m in re.findall(r"\[[xX]\]\s*([^\[\n]+?)(?=\s{2,}|\[|$)", text, re.M)]
    profiles = []
    for name, keys in (("vitrine expressive", ("vitrine",)), ("conformité RGAA", ("rgaa",)),
                       ("éco-conçu", ("éco", "eco")), ("standard", ("standard",))):
        if any(any(k in c for k in keys) for c in checked):
            profiles.append(name)
    sizes: dict[str, float] = {}
    line = next((l for l in text.splitlines() if "Repères de taille" in l), "")
    for key, pat in (("minBody", r"texte courant\s*:?\s*(\d+(?:[.,]\d+)?)\s*px"), ("minText", r"libellés\s*:?\s*(\d+(?:[.,]\d+)?)\s*px")):
        m = re.search(pat, line)
        if m:
            sizes[key] = float(m.group(1).replace(",", "."))
    return {"profiles": profiles or ["standard (aucun profil coché)"], **sizes}


def to_url(target: str) -> str:
    if urllib.parse.urlparse(target).scheme in ("http", "https", "file"):
        return target
    return pathlib.Path(target).resolve().as_uri()


def find_axe() -> pathlib.Path | None:
    candidates = [
        os.environ.get("AXE_PATH"),
        pathlib.Path(__file__).resolve().parent.parent / "assets" / "axe.min.js",
        CACHE_DIR / "node_modules" / "axe-core" / "axe.min.js",
    ]
    for c in candidates:
        if c and pathlib.Path(c).is_file():
            return pathlib.Path(c)
    try:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        subprocess.run(["npm", "install", "--prefix", str(CACHE_DIR), "axe-core@4", "--silent", "--no-audit", "--no-fund"],
                       check=True, capture_output=True, timeout=120)
    except Exception as exc:  # noqa: BLE001
        print(f"[qa] axe-core indisponible ({exc}); audit axe ignoré.", file=sys.stderr)
        return None
    p = CACHE_DIR / "node_modules" / "axe-core" / "axe.min.js"
    return p if p.is_file() else None


def load(page: Page, url: str) -> None:
    try:
        page.goto(url, wait_until="networkidle", timeout=30000)
    except Exception:  # noqa: BLE001
        page.goto(url, wait_until="load", timeout=30000)
    page.evaluate("document.fonts.ready.then(() => true)")
    # Scroll to trigger lazy content, then back to top.
    page.evaluate("""async () => { for (let y = 0; y < document.body.scrollHeight; y += innerHeight * 0.8) {
        scrollTo(0, y); await new Promise(r => setTimeout(r, 60)); } scrollTo(0, 0); }""")
    page.wait_for_timeout(300)


def run_axe(page: Page, axe_path: pathlib.Path) -> dict[str, Any]:
    page.add_script_tag(path=str(axe_path))
    return page.evaluate(
        """async (tags) => {
            const r = await axe.run(document, { runOnly: { type: 'tag', values: tags }, resultTypes: ['violations', 'incomplete'] });
            const bp = await axe.run(document, { runOnly: { type: 'tag', values: ['best-practice'] }, resultTypes: ['violations'] });
            const slim = (list) => list.map(v => ({ id: v.id, impact: v.impact, help: v.help,
                nodes: v.nodes.slice(0, 5).map(n => n.target.join(' ')), count: v.nodes.length }));
            return { violations: slim(r.violations), incomplete: slim(r.incomplete), bestPractice: slim(bp.violations) };
        }""",
        AXE_TAGS,
    )


def focus_check(page: Page, max_tabs: int = 120) -> tuple[list[str], int]:
    seen, invisible = set(), []
    page.mouse.click(1, 1)
    for _ in range(max_tabs):
        page.keyboard.press("Tab")
        info = page.evaluate(FOCUS_STEP_JS)
        if not info:
            continue
        if info["key"] in seen:
            break
        seen.add(info["key"])
        if not info["visible"]:
            invisible.append(info["label"])
    return invisible, len(seen)


def asset_size(url: str, sizes: dict[str, int]) -> int | None:
    if url in sizes:
        return sizes[url]
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme == "file":
        p = pathlib.Path(urllib.parse.unquote(parsed.path))
        return p.stat().st_size if p.is_file() else None
    if parsed.scheme == "data":
        return len(url) * 3 // 4
    return None


def kb(n: int | None) -> str:
    return "?" if n is None else f"{n / 1024:.0f} Ko"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("target")
    ap.add_argument("--out", default="qa")
    ap.add_argument("--widths", default=",".join(map(str, DEFAULT_WIDTHS)))
    ap.add_argument("--max-ch", type=int, default=80, help="line length threshold (75ch rule + tolerance)")
    ap.add_argument("--shots-only", action="store_true")
    ap.add_argument("--fiche", help="fiche projet (markdown): reads the profile and adjusted text-size references")
    ap.add_argument("--eco", action="store_true", help="eco-designed profile: enforce page and font budgets (references/qa.md §1)")
    ap.add_argument("--min-text", type=float, default=None, help="smallest text size to flag below (px, reference adjustable to the font)")
    ap.add_argument("--min-body", type=float, default=None, help="running text size to flag below (px, reference adjustable to the font)")
    ap.add_argument("--quiet", action="store_true", help="write report.md without printing it (look at the screenshots first)")
    args = ap.parse_args()

    out = pathlib.Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    widths = [int(w) for w in args.widths.split(",")]
    url = to_url(args.target)
    axe_path = None if args.shots_only else find_axe()

    fiche = read_fiche(args.fiche) if args.fiche else {"profiles": []}
    if "éco-conçu" in fiche["profiles"]:
        args.eco = True
    args.min_text = args.min_text if args.min_text is not None else fiche.get("minText", 14)
    args.min_body = args.min_body if args.min_body is not None else fiche.get("minBody", 16)
    report: dict[str, Any] = {"profiles": fiche["profiles"], "eco": args.eco, "minText": args.min_text, "minBody": args.min_body, "url": url, "maxCh": args.max_ch, "widths": {}, "shots": []}
    sizes: dict[str, int] = {}

    with sync_playwright() as p:
        browser = p.chromium.launch()
        for w in widths:
            ctx = browser.new_context(viewport={"width": w, "height": 900}, device_scale_factor=1)
            page = ctx.new_page()

            def on_response(resp):  # collect transfer sizes for http(s) assets
                try:
                    if resp.url.startswith("http"):
                        sizes[resp.url] = len(resp.body())
                except Exception:  # noqa: BLE001
                    pass

            page.on("response", on_response)
            load(page, url)
            shot = out / f"{w:04d}.png"
            page.screenshot(path=str(shot), full_page=True)
            report["shots"].append(str(shot))
            if not args.shots_only:
                full = w == max(widths)
                res = page.evaluate(CHECKS_JS, {"maxCh": args.max_ch, "full": full})
                if axe_path and w in (min(widths), max(widths)):
                    res["axe"] = run_axe(page, axe_path)
                if full:
                    res["tells"] = page.evaluate(TELLS_JS, {"minText": args.min_text, "minBody": args.min_body})
                    res["focusInvisible"], res["focusReached"] = focus_check(page)
                report["widths"][w] = res
            ctx.close()

        if not args.shots_only:
            ctx = browser.new_context(viewport={"width": max(widths), "height": 900}, reduced_motion="reduce")
            page = ctx.new_page()
            load(page, url)
            report["reducedMotionStillAnimated"] = page.evaluate(MOTION_JS)
            ctx.close()
        browser.close()

    (out / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str))
    if args.shots_only:
        print("\n".join(report["shots"]))
        return 0
    md = render_md(report, widths, sizes)
    (out / "report.md").write_text(md)
    if not args.quiet:
        print(md)
    print(f"\n[qa] Rapport : {out / 'report.md'} ; captures : {out}/")
    return 0


def render_md(r: dict[str, Any], widths: list[int], sizes: dict[str, int]) -> str:
    L: list[str] = ["# Pré-contrôle QA (non constitutif d'un audit de conformité)", "", f"Source : {r['url']}"]
    if r.get("profiles"):
        L.append(f"Profil (fiche projet) : {', '.join(r['profiles'])} ; repères de taille : {r['minBody']:g} px texte courant, {r['minText']:g} px libellés")
    if "conformité RGAA" in r.get("profiles", []):
        L.append("Profil conformité RGAA : ce pré-contrôle ne suffit pas, pré-évaluation `lba-design:accessibility` requise pour toute version validée.")
    if "vitrine expressive" in r.get("profiles", []):
        L.append("Profil vitrine expressive : les animations GSAP pilotées en JavaScript échappent à ce script ; vérifier leur comportement en mouvement réduit dans le navigateur (`lba-design:motion`).")
    L.append("")
    big = r["widths"][max(widths)]

    def section(title: str, items: list[str], empty: str = "aucun") -> None:
        L.append(f"**{title}** : {len(items) if items else empty}")
        L.extend(f"- {i}" for i in items[:10])
        L.append("")

    L.append("## Accessibilité (axe-core, WCAG 2.2 A/AA)")
    for w in (min(widths), max(widths)):
        axe = r["widths"][w].get("axe")
        if not axe:
            L.append(f"- {w}px : axe non exécuté")
            continue
        L.append(f"- {w}px : {len(axe['violations'])} règle(s) en violation, {len(axe['incomplete'])} à vérifier manuellement")
        for v in axe["violations"]:
            L.append(f"  - [{v['impact']}] {v['id']} ×{v['count']} : {v['help']} ({'; '.join(v['nodes'][:3])})")
        for v in axe["incomplete"][:5]:
            L.append(f"  - à vérifier : {v['id']} ×{v['count']} ({'; '.join(v['nodes'][:2])})")
    bp = (big.get("axe") or {}).get("bestPractice", [])
    if bp:
        L.append("- Bonnes pratiques : " + ", ".join(f"{v['id']} ×{v['count']}" for v in bp))
    L.append("")

    section(f"Focus non visible ({big.get('focusReached', 0)} éléments parcourus au clavier)", big.get("focusInvisible", []))
    section("Texte à opacité ou couleur translucide (imp. 10)", big.get("textOpacity", []))
    rm = r.get("reducedMotionStillAnimated", {"moving": [], "unclear": []})
    section("Mouvement ou flou malgré prefers-reduced-motion (imp. 14 ; les fondus et couleurs sont admis)", sorted(rm["moving"]))
    if rm["unclear"]:
        section("Mouvement réduit à vérifier à l'œil (transition sur « all », images clés externes)", sorted(rm["unclear"]))

    L.append("## Responsive")
    for w in widths:
        res = r["widths"][w]
        L.append(f"- **{w}px** : débordement {'OUI ' + ', '.join(res['overflowOffenders'][:3]) if res['overflow'] else 'non'} ; "
                 f"cibles < 24px : {len(res['targetsUnder24'])} ; < 44px : {len(res['targetsUnder44'])} ; "
                 f"lignes > {r['maxCh']}ch : {len(res['longLines'])}")
        for t in res["targetsUnder24"][:3]:
            L.append(f"  - < 24px : {t}")
        for t in res["longLines"][:2]:
            L.append(f"  - ligne longue : {t}")
    L.append("")
    section("Cibles entre 24 et 44px à la plus grande largeur (vérifier nav, filtres, CTA)", big.get("targetsUnder44", []))

    L.append("## Typographie")
    section("Titres h1 à h3 sans text-wrap: balance (imp. 6)", big.get("headingsNoBalance", []))
    pp = big.get("parasNoPretty", {"count": 0, "total": 0})
    L.append(f"**Paragraphes sans text-wrap: pretty** : {pp['count']} / {pp['total']}")
    L.append("")
    tl = big.get("tells") or {}
    section(f"Texte sous {r['minText']:g} px (repère de principles §4, à juger selon la police)", tl.get("textUnder14", []))
    section(f"Texte courant sous {r['minBody']:g} px (repère de principles §4, à juger selon la police)", tl.get("bodyUnder16", []))
    section("Typographie française à vérifier (imp. 15)", big.get("frTypo", []))
    if big.get("straightQuotes"):
        section("Guillemets droits dans le texte", big["straightQuotes"])

    section("Espacements hors grille de 4 (padding, gap) (imp. 4)", big.get("offGrid", []))

    L.append("## Médias et poids")
    heavy, oversized, no_alt = [], [], []
    for im in big.get("images", []):
        size = asset_size(im["src"], sizes)
        name = im["src"].split("/")[-1][:60]
        if size and size > IMG_LIMIT_BYTES:
            heavy.append(f"{name} : {kb(size)}")
        if im["rendered"][0] and im["natural"][0] > im["rendered"][0] * 2.5 and not im["srcset"]:
            oversized.append(f"{name} : {im['natural'][0]}px pour {im['rendered'][0]}px affichés, sans srcset")
        if im["alt"] is None:
            no_alt.append(name)
    for bg in big.get("bgImages", []):
        size = asset_size(bg, sizes)
        if size and size > IMG_LIMIT_BYTES:
            heavy.append(f"(fond) {bg.split('/')[-1][:60]} : {kb(size)}")
    section("Images > 250 Ko", heavy)
    section("Images surdimensionnées", oversized)
    section("Images sans attribut alt", no_alt)
    section("Médias en lecture automatique", big.get("autoplay", []))
    fonts = big.get("fonts", [])
    over = f" : AU-DELÀ du budget éco-conçu de {FONT_FILES_LIMIT} fichiers (references/qa.md §1)" if r["eco"] and len(fonts) > FONT_FILES_LIMIT else ""
    L.append(f"**Fonts chargées** : {len(fonts)} ({', '.join(sorted(set(fonts))[:8])}){over}")
    total = sum(sizes.values())
    if total:
        over = " : AU-DELÀ du budget éco-conçu de 1,5 Mo (references/qa.md §1)" if r["eco"] and total > PAGE_LIMIT_BYTES else ""
        L.append(f"**Poids transféré (ressources http)** : {kb(total)}{over}")
    else:  # local file: HTML + images found on disk (CSS/JS/fonts external to the file not counted)
        local = {r["url"]} | {im["src"] for im in big.get("images", [])} | set(big.get("bgImages", []))
        est = sum(filter(None, (asset_size(u, sizes) for u in local)))
        L.append(f"**Poids estimé (HTML + images locales)** : {kb(est)}")
    L.append("")
    t = big.get("tells")
    if t:
        L.append("## Anti-défauts mesurables (signaux : à justifier ou à réécrire)")
        section("Texte en dégradé", t["gradientText"])
        section("Filet latéral coloré épais", t["sideStripe"])
        section("Ombre dure sans flou", t["hardShadow"])
        section("Numérotation de section ou d'image (01, 02…)", t["sectionNumbers"])
        section("Métadonnées à séparateurs « · » multiples", t["dotSeparators"])
        section("Emoji en guise d'icône", t["emojiIcons"])
        section("Transition sur « all » (préciser les propriétés)", t["transitionAll"])
        section("Courbe en accélération seule (ease-in) sur l'interface", t["easeIn"])
        L.append(f"**Chiffres de tableau sans tabular-nums** : {t['numbersNotTabular'] or 'aucun'}")
        sel_state = {True: "oui", False: "non (couleur du navigateur)", None: "indéterminé (feuilles de style externes)"}[t["selectionStyled"]]
        L.append(f"**Sélection de texte stylée (::selection)** : {sel_state}")
        L.append("")
    L.append("## Non couvert par le script (contrôle visuel obligatoire)")
    L.append("Filets en ouverture ou clôture (imp. 2), lignes de base (3), alignement optique (7), colonne gauche (8), "
             "visages et recadrages (9), états hover/active/disabled (11), grilles en 3+1 et orphelins (16), hiérarchie et identité, "
             "anti-défauts non mesurables (cartes identiques, surtitres, fausse interface en div), test du pire cas (references/qa.md §3).")
    return "\n".join(L)


if __name__ == "__main__":
    sys.exit(main())
