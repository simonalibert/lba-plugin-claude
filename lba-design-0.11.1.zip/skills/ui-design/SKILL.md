---
name: ui-design
description: "Méthode de conception de La Bonne Agence, du brief à la maquette haute fidélité livrée : pages de site, landing, refonte, écrans d'app mobile et prototypes interactifs, en HTML, dans Claude Design ou dans Figma, à partir d'un wireframe, d'une capture ou d'un existant. Couvre cadrage, direction et pistes, typographie et couleur, écrans, passe qualité, livraison. Déclencher dès qu'il est question de webdesign, de maquette, d'écran ou de prototype d'app, de direction graphique, de pistes, de passer d'un wireframe au design, de déclinaison mobile, d'itération sur un écran ou un composant d'une maquette en cours (« plus aéré », « modifier l'affichage ») ou de passe qualité, même sans le mot « maquette ». Ne pas utiliser pour un wireframe ou une arborescence (`lba-design:wireframe`), un audit d'accessibilité (`lba-design:accessibility`), une spec dev (`lba-design:handoff`), une présentation ou un document imprimable."
---

# Maquette web : méthode La Bonne Agence

**Préséance** : invariants de `lba-design:principles` > demande ou brief > décisions validées (fiche projet, DESIGN.md) > design system ou charte du client > impératifs (ci-dessous) > défauts maison (ci-dessous).

Charger `lba-design:principles` avant de commencer : il porte les invariants (ne rien inventer, statuts, conformité, seuils, typographie française, données personnelles). Les défauts maison ne servent qu'en l'absence de design system ou de charte du client, et un défaut se quitte sans justification ; un impératif, seulement par un écart déclaré.

## Profil et livrables

Lire dans la fiche projet le **profil** (`lba-design:principles` §11 : standard, vitrine expressive, conformité RGAA, éco-conçu, combinables) et si la **version mobile est dessinée**. Absents : les demander au cadrage ou les poser en hypothèse. Le profil change le motion, les polices, le budget de page et le niveau d'audit ; il ne touche jamais un invariant.

## Déroulé

| Étape | Ce qu'on fait | À lire |
|---|---|---|
| 1. Sources | Fiche projet (elle fait foi), design system du client (vérifier que c'est bien le sien, pas un kit neutre), wireframe, site, contenus, médias, fonts. Ne jamais redemander ce qu'elles disent. | `references/sources-entree.md` dès qu'un lien ou un fichier est fourni |
| 2. Cadrage et hypothèses | Fenêtre de questions si la structure (zoning, existant), le logo et les médias ou le nombre de pistes manquent ; la **lecture du brief** en une phrase ; tout le reste en hypothèses visibles et réversibles. | `references/questions.md` ; `templates/fiche-projet.md` s'il n'y a pas de fiche |
| 3. Structure | Le wireframe est un contrat : extraire sections, contenus, priorités, CTA ; classer figé, ajustable, libre. Pas de structure claire : la faire d'abord avec `lba-design:wireframe`. | `references/sources-entree.md`, « Contrat de structure » |
| 4. Direction | Mode de chaque page, ce que seul le client possède, références lues axe par axe, **parti pris** en une phrase avec son levier principal et son sacrifice ; une piste si le brief est précis, deux ou trois s'il est ambigu, chacune nommée par son parti pris. | `references/direction.md` |
| 5. Système | Familles, échelle typographique, palette, validées sur une planche de fondations ; puis tokens par rôle, grille, espacements, composants. | `references/fondations.md` |
| 6. Écrans | Impératifs, défauts, anti-défauts ci-dessous. Écran d'app mobile : `references/app-mobile.md`. **Test d'identité** à chaque itération : retirer le logo, reconnaît-on encore le client ? Sinon, renforcer le levier principal avant de raffiner le détail. Valider la hiérarchie avant le pixel. | ce fichier ; `references/vocabulaire.md` pour chaque demande d'itération |
| 7. Critique et QA | `qa.py`, jugement avant lecture du rapport, pire cas, éléments oubliés, passes bornées ; contrastes calculés avec `contrast.py` de `lba-design:accessibility` quand `qa.py` ne tourne pas (Claude Design, Figma) ; vérifié, non vérifié, hors périmètre. | `references/qa.md` |
| 8. Livraison | Rapport, versions, journal de décisions, livrables. À chaque itération validée, **mettre à jour la fiche projet** sans attendre qu'on le demande (version, décisions, hypothèses, à fournir). Finir chaque livraison par l'étape en cours et la suivante, en une ligne. | `references/livraison.md` |

**Cadrage** (étape 2) : si la demande, la fiche et les fichiers ne disent pas sur quoi s'appuie la structure (zoning ou wireframe, site ou capture existante), ce qu'on a du client (logo, médias, charte) et le nombre de pistes, **ouvrir la fenêtre de questions** de la surface avant de dessiner, avec les questions de `references/questions.md` (trois sur claude.ai, quatre dans Claude Code), puis demander en une phrase de joindre ce qui a été coché, et les sites aimés ou rejetés s'il y en a. Ne chercher dans Google Drive que si l'option a été cochée (`references/questions.md`). Jamais de question dont la réponse est déjà connue ; jamais de blocage : sans réponse, la valeur par défaut devient une hypothèse. Une font ou une photo manquante ne bloque jamais : emplacement explicite et hypothèse. Contenus réels dès qu'ils existent, le reste marqué « À fournir » ; textes d'interface : `lba-design:microcopy`.

**Lecture du brief** : « Je lis ce projet comme : [type de page] pour [public], dans un registre [ambiance], avec [système ou famille visuelle]. » En tête des hypothèses ; elle se corrige en un mot si elle est fausse.

**Refonte : ce qui ne change jamais en silence** : adresses des pages et ancres, libellés de la navigation principale, noms et ordre des champs de formulaire (suivi d'audience, autocomplétion), logo, textes légaux et de consentement, acquis d'accessibilité du site actuel. Toute modification d'un élément figé ou de cette liste est proposée et tracée dans les écarts.

**Arbitrage** entre défauts : compréhension du contenu > hiérarchie de l'information > identité > cohérence du système > composition et rythme > préférence esthétique.

## Impératifs (standard LBA)

Les points ratés le plus souvent quand on laisse de la latitude. Vérifiés à chaque livraison ; un écart est déclaré et justifié dans le rapport.

1. **CTA centrés optiquement** : libellé dans un span `display:block; text-box: trim-both cap alphabetic`, icône en élément frère, conteneur `align-items:center` ; repli `@supports not (text-box: trim-both cap alphabetic)` par padding compensé. Vaut pour boutons, liens-flèches, tags, switchs, pastilles.
2. **Filets entre les éléments seulement**, jamais en ouverture ni en clôture d'une liste, d'une grille ou d'un bloc, y compris après passage à la ligne.
3. **Ligne de base partagée** entre un titre et le texte placé en face, au pixel près.
4. **Grille de 8 px**, 4 toléré en micro-ajustement ; exception optique déclarée.
5. **Longueur de ligne** : `max-width` en `ch`, limite de `principles` §4.
6. **Pas d'orphelin** : `text-wrap: balance` sur les titres, `pretty` sur les paragraphes.
7. **Alignement optique** des flèches et chevrons.
8. **Colonne gauche commune** : logo, titres, textes et bords de cartes sur le même axe d'une section à l'autre.
9. **Visages jamais coupés**, cadrage vérifié à chaque largeur (`object-position` par image).
10. **Contraste** : seuils de `principles` §4, jamais de tag semi-transparent.
11. **États complets** : survol, focus visible sur fond clair et sombre, actif, désactivé ; chargement, vide et erreur pour tout contenu filtré ou chargé.
12. **Cibles** : `principles` §4 (44 px pour navigation, filtres et CTA).
13. **Sémantique** : vrais `button` et `a`, landmarks, `aria-expanded`, `aria-pressed`, `aria-checked`, `alt` utiles, `aria-hidden` sur le décoratif, `lang="fr"`.
14. **Mouvement réduit** : `principles` §4 (déplacements et flou coupés, fondus courts conservés) ; au-delà des transitions simples, `lba-design:motion`.
15. **Typographie française** : `principles` §6.
16. **Responsive** : aucun débordement, aucune grille en 3+1, aucun orphelin, à toutes les largeurs de contrôle du HTML livré. Mobile dessiné : 390 et 1440 conçus ensemble, hero, navigation et conversion d'abord en 390 ; sinon, comportement mobile décrit pour le dev. Un écran mobile n'est jamais un desktop empilé.

## Défauts maison

Points de départ quand ni la demande, ni la fiche projet, ni le client n'en disposent autrement. Chacun avec sa raison, pour savoir quand le quitter. Les partis pris marqués † sont listés dans les hypothèses de livraison, pour qu'on puisse les refuser en connaissance de cause.

| Défaut | Valeur | Raison |
|---|---|---|
| Boutons | 3 variantes au plus (principal, secondaire, contour), hauteur unique 48 px, flèche en fin quand l'action mène ailleurs | Hiérarchie d'actions lisible d'un coup d'œil ; 48 px tient la cible de 44 px avec de la marge |
| Texte cliquable † | Navigation, CTA, liens, filtres en capitales de la version condensée, 14 px, léger letter-spacing ; pas plus de quelques mots | Distinguer l'action du texte courant par la largeur ; la lisibilité se juge selon la police (`principles` §4) |
| Icônes | Une famille, `currentColor`, trait homogène | Cohérence, et la couleur d'état suit sans token supplémentaire |
| Rayons | Une famille (small, medium, large) | Un rayon par composant fragmente le système |
| Ombres | Rares et fonctionnelles ; pas d'ombre par défaut sur les cartes, un seul survol commun aux cartes | Une ombre signale l'élévation ; partout, elle ne signale plus rien |
| Échelle typographique | 5 à 7 styles nommés (Display, H1 à H3, Lead, Body, Small, Label), chacun complet et responsive ; fonts variables : axes lus avant usage, largeur du texte courant sur `body`, condensée explicite sur les CTA | Au-delà, les écarts deviennent indistincts ; une redéfinition de `font-variation-settings` sur un enfant écrase tous les axes |
| Espacements | Échelle 8, 16, 24, 32, 48, 64, 80, 96, 128, 160 ; grille de 12 colonnes desktop, marges et gouttières constantes | Partagée avec les développeurs, divisible, cohérente avec l'impératif 4 |
| Rythme vertical | Padding de section 96 px desktop, 64 px mobile ; filet entre deux sections consécutives de même fond | Séparer les sections sans boîte ; deux fonds identiques fusionnent sinon. À resserrer pour un site dense |
| Couleur par entité | Client à plusieurs entités : une couleur par entité, identique sur tags, pastilles, cartes, CTA | L'usager reconnaît l'entité partout sans lire |
| Segmented control | Piste gris clair, curseur blanc ombré, `transition: transform .42s cubic-bezier(.32,.72,0,1)`, `scale(.96)` à l'appui | Comportement éprouvé, lisible comme une seule commande |
| Switch | Piste 51×31, pastille 27 px, `role="switch"`, `aria-checked` ; zone cliquable étendue au libellé, 44 px de haut | La piste seule est sous la cible de 44 px |
| Contenus chargés | Skeleton au chargement, état vide avec message et action de retour | Pas de saut de mise en page, un vide qui s'explique |
| Page institutionnelle | Questions à couvrir, pas un gabarit : où suis-je, pour qui, pourquoi cela me concerne, que faire ensuite ; un seul CTA principal dans le hero ; chiffres clés en une bande sobre, seulement validés ; footer complet | Chaque section répond au prochain besoin de l'usager ; deux sections qui se concurrencent se fusionnent |
| Surfaces du navigateur | `::selection`, `caret-color`, focus, soulignement (`text-underline-offset`, épaisseur), barres de défilement internes, `tabular-nums`, réglés depuis les tokens | Le signe le moins coûteux d'une page construite plutôt qu'assemblée |
| Médias | Originaux 1800 px (JPEG ~82) dans `assets/`, WebP aux dimensions de l'emplacement et du retina, 250 Ko par image au plus, `srcset` si la taille varie, lazy loading hors premier écran ; fonts en woff2, sous-ensemble latin, graisses utilisées | Poids maîtrisé sans perte visible. Vitrine expressive : dépassement déclaré ; éco-conçu : budget de page imposé (`references/qa.md` §1) |
| Mouvement automatique | Vidéo en lecture automatique, carrousel automatique, animation décorative en boucle : exclus | Distraction et poids. Vitrine expressive : possibles, avec bouton pause au-delà de 5 s (WCAG 2.2.2, invariant) et arrêt en mouvement réduit |

## Anti-défauts

Ce que les gabarits et les outils de génération produisent quand rien ne les contraint. La demande ou la charte peuvent en justifier un ; sans raison, réécrire l'élément plutôt que l'adoucir. `qa.py` signale ceux qui se mesurent.

| Éviter | Faire à la place | Pourquoi |
|---|---|---|
| Dégradés, glassmorphism, blobs pour « faire premium » | Pousser le levier principal du parti pris (typographie, image, couleur franche) | L'effet remplace une décision |
| Tout centrer, tout mettre en cartes, cartes imbriquées | Grille et colonne gauche commune ; une carte seulement quand le contenu est un objet cliquable | La boîte par défaut écrase la hiérarchie |
| Rangée de cartes identiques icône + titre + texte comme ossature | Liste éditoriale, tableau, alternance image et texte, selon le contenu | Le gabarit le plus reconnaissable des pages générées |
| « Gros chiffre, petit libellé » répété, ou sans chiffres validés | Une bande sobre de chiffres sourcés, une fois | Ne rien inventer ; la répétition dilue |
| Surtitre décoratif en petites capitales au-dessus de chaque titre | Un titre qui se suffit ; un surtitre seulement s'il informe (rubrique, date) | Bruit qui retarde la lecture |
| Numérotation 01, 02, 03 et « 01 / 4 » sans ordre réel | Pas de numéro, ou un vrai ordre (étapes d'une démarche) | Faux signal de séquence |
| Bandeau de mots décoratifs, « Faites défiler », pastilles colorées sans état | Rien, ou une information réelle (lien, statut) | Décor qui imite du contenu |
| Séparateurs « · » en série dans les métadonnées | Une puce par ligne au plus, sinon colonnes ou retours à la ligne | Lisibilité des métadonnées |
| Fausse interface produit en `div` dans le hero | Capture réelle, visuel commandé (`lba-design:media`) ou rien | Un faux produit trompe et vieillit mal |
| Texte en dégradé | Graisse ou taille | Contraste incalculable, effet daté |
| Filet latéral coloré épais sur cartes, encadrés, alertes | Fond teinté léger, icône, titre explicite | Tic visuel ; la couleur seule ne porte pas l'information |
| Ombre dure sans flou hors univers néo-brutaliste | Ombre douce rare, ou différence de surface | Costume plutôt que système de profondeur |
| Emoji ou caractères Unicode en guise d'icônes | La famille d'icônes du système | Rendu variable selon les plateformes, restitution vocale imprévisible |
| Chasse fixe comme costume « technique » | Chasse fixe pour le code, les données, les mesures | Le registre doit avoir une raison |
| Thème sombre ou clair par habitude du secteur | Choix selon la situation d'usage (`references/fondations.md`) | Le mode se décide, il ne se suppose pas |
| Animation pour compenser une hiérarchie faible | Reprendre la hiérarchie | Le mouvement attire, il n'organise pas |
| Une variante de composant par exception | Une variante du système, ou un écart déclaré | Le système se dissout |
| Changer une décision validée sans le dire | Proposer, consigner au journal | Préséance des décisions validées |
| Une même information deux fois dans un composant (pastille « 3 » et libellé « 3 en cours ») | Une seule occurrence, au bon niveau de lecture | Alourdit sans informer |
| Remplacer un composant et laisser l'ancien dans le système | À chaque remplacement, lister ce qui devient inutilisé (composants, variantes, jetons, icônes) et proposer de le supprimer, jamais en silence | Le système accumule du mort |

Textes génériques (« Découvrez », « au cœur de », phrases-slogans) : anti-défauts de `lba-design:microcopy`.

## Conversation longue ou résumée

Quand une conversation est résumée automatiquement, les instructions de ce skill peuvent disparaître du contexte. Avant toute nouvelle modification d'une maquette dans une conversation reprise ou résumée : recharger ce skill et relire la fiche projet, qui fait foi. La fiche indique la méthode en tête pour cette raison.

## Selon l'environnement

Les surfaces n'ont pas les mêmes outils (`EXECUTION.md` à la racine du plugin) : vérifier ce qui est disponible avant de promettre un livrable, ne jamais simuler un outil absent ni annoncer une publication qui n'a pas eu lieu.

- **claude.ai** : design en artefact ou type Design ; lecture d'un wireframe publié avec l'outil Artifact.
- **Sans Artifact ni Claude Design** (Claude Code, Cowork) : HTML autonome dans le dossier du projet (`design/<page>-v<N>.html`) ; wireframe lu depuis un fichier, un export ou Figma ; `qa.py` sur le poste (Python et Playwright), sinon contrôle visuel et « non vérifié » dans le rapport.
- **Directement dans Figma** : ce skill pilote la méthode ; `figma:figma-use` (obligatoire), `figma:figma-generate-design` et `lba-design:figma` portent la technique. Traduction des impératifs et contrôle sans `qa.py` : `references/figma.md`, avant de construire.
- **Questions de cadrage** : outil de questions de la surface s'il existe, sinon en texte.

## Références

- `references/questions.md` : au cadrage, avant d'ouvrir la fenêtre de questions.
- `references/sources-entree.md` : dès qu'un lien, un wireframe ou un fichier source est fourni ; contrat de structure.
- `references/direction.md` : avant toute nouvelle direction, refonte visuelle ou série de pistes.
- `references/fondations.md` : en posant typographie, couleur et tokens.
- `references/qa.md` : avant chaque livraison (script, budgets, jugement, pire cas, éléments oubliés).
- `references/livraison.md` : avant la première livraison ; versions et journal de décisions.
- `references/figma.md` : avant de construire dans Figma.
- `references/vocabulaire.md` : à chaque demande d'itération (« plus aéré », « plus de caractère »…) et pour formuler une critique.
- `templates/fiche-projet.md` : s'il n'existe pas encore de fiche projet.
- `scripts/qa.py` : pré-contrôle automatique, mode d'emploi dans `references/qa.md`.
