# Tokens au format DTCG

Repris de `lba-design:ui-design` (références, tokens). Rôles minimum et logique surface/inverse : voir ce skill.

## Format

Livrer les tokens au format Design Tokens (DTCG 2025.10), lisible par les outils qui suivent la spécification (Style Dictionary pour générer CSS, iOS, Android) :

```json
{
  "color": {
    "neutral": {
      "900": { "$type": "color", "$value": { "colorSpace": "srgb", "components": [0.067, 0.067, 0.067], "hex": "#111111" } }
    },
    "text": {
      "primary": { "$type": "color", "$value": "{color.neutral.900}" }
    }
  },
  "space": {
    "3": { "$type": "dimension", "$value": { "value": 24, "unit": "px" } }
  }
}
```

Principes : primitives (`color.neutral.900`) puis sémantiques par rôle en alias (`text.primary`) ; les composants ne consomment que des tokens sémantiques.

## Contenu du handoff

- Foundations : couleurs, typographie, espacements, grille, rayons, ombres, surfaces.
- Composants : boutons, liens, navigation, cartes, tags, formulaires, filtres, contrôles, avec tous leurs états.
- Patterns : hero, listing, éditorial, chiffres, newsletter, footer.
- Responsive : décrire les changements de comportement par largeur (ordre, colonnes, recadrage, navigation), pas seulement les dimensions.

