# DESIGN.md : [Nom du projet]

> Ce fichier donne à un agent de code (Claude Code, Cursor) le contexte produit et système de design du projet. Il documente des décisions déjà prises, il ne doit jamais être complété par inférence à partir des maquettes Figma seules. En cas de doute sur une règle non couverte ici, la poser explicitement plutôt que de la déduire visuellement. À maintenir à jour à chaque décision structurante, en particulier la section 9.

**Mise à jour du [date]** : [résumé bref de ce qui a changé dans cette révision (pas "mise à jour du contenu", dire quoi et pourquoi)]

## 1. Mission & contexte produit

[Une phrase sur le projet : qui, quoi, positionnement. Cibles/audiences si le produit en a plusieurs. Verticales/domaines métier si pertinent.]

## 2. Marque, voix et lexique

- [Voix de marque, avec des exemples de référence réels plutôt que des adjectifs abstraits]
- [Éléments graphiques signature]
- [Règles de contenu propres à la marque, si elles existent]

### 2.1 Ton

- **Adresse** : [vouvoiement ou tutoiement, et pour quels publics]
- **Registre** : [ex. sobre et direct ; exclamation réservée aux confirmations de réussite]
- **Formulations approuvées** : [phrases ou accroches validées par le client, citées telles quelles]
- **Écriture inclusive** : [décision du client, ou zone grise]

### 2.2 Lexique

Mots retenus pour nommer les choses, avec leur raison. Sources : vocabulaire relevé par `lba-design:synthesis`, décisions du client. Lu par `lba-design:microcopy` et par tout agent qui écrit un texte d'interface.

| Dire | Ne pas dire | Pourquoi | Source et date |
|---|---|---|---|
| [mot des usagers] | [mot interne ou ambigu] | [ex. 7 familles sur 8 l'emploient ; l'autre désigne autre chose en interne] | [synthèse du JJ/MM, ou décision client du JJ/MM] |

## 3. Fondations techniques (non négociables)

- **Stack** : [CMS/framework, contraintes explicites, par ex. pas de headless, pas de tel framework]
- **Accessibilité** : [référentiel visé : RGAA, WCAG, niveau]
- **Réglementaire** : [RGPD, secteur spécifique si pertinent]
- **Profil du projet** : [standard, vitrine expressive, conformité RGAA, éco-conçu ; voir `lba-design:principles` §11] et ce qu'il implique ici (budget, référentiel, niveau de motion)
- **Breakpoints** : [desktop de référence, mobile, autres modes ; version mobile dessinée ou seulement décrite]
- **Rétine** : [politique d'export @2x ou non]

## 4. Tokens

### 4.1 Spacing
[Collection, échelle, convention de nommage. Exceptions légitimes non tokenisées à lister explicitement.]

### 4.2 Couleurs
[Table token → valeur hex → usage observé. Marquer "non confirmé" toute valeur non vérifiée directement dans le fichier de travail. Noter les points de vigilance RGAA connus (contrastes limites).]

### 4.3 Typographie
[Polices de marque, rôles distincts. Échelle de tailles avec source (desktop/mobile si deux modes). Règles de construction : interlignage, leading trim, etc. si le projet en a besoin.]

### 4.4 Ratios médias
[Table ratio → usage → dimensions @1x/@2x. Voir le skill `lba-design:media` pour la méthode de calcul et l'inventaire par gabarit.]

### 4.5 Icônes
[Bibliothèque retenue, graisse par défaut, raison du choix si plusieurs sets coexistaient.]

### 4.6 Interopérabilité (si pertinent)
[Pistes d'évolution non mises en œuvre, par ex. format de tokens interopérable. Marquer explicitement "piste, non implémentée".]

## 5. Composants existants (inventaire)

[Table composant → rôle → variants connus. Un composant non encore stabilisé ou créé hors décision actée doit être signalé comme tel, pas listé au même niveau que le reste.]

## 6. Accessibilité

[Règles transverses déjà actées. Séparer clairement ce qui est une décision UX actée de ce qui relève d'un point de conformité juridique à faire confirmer par un référent : ne pas mélanger les deux registres.]

## 7. Do / Don't

**Do :**
- [Règles de construction positives, spécifiques au projet]

**Don't :**
- [Erreurs déjà rencontrées ou pièges identifiés, plus utiles qu'une liste générique]

## 8. Ce qui est fait, contrairement à une version antérieure de ce fichier

[Sert à corriger le "déjà-vu" : si une version précédente disait qu'un composant n'existait pas et qu'il a été construit depuis, le dire ici explicitement plutôt que de laisser une contradiction silencieuse dans le fichier.]

## 9. Zones grises à valider avant usage en production

[La section la plus importante à tenir à jour. Une ligne par point ouvert : la question précise, ce qui est déjà su, qui peut trancher. Retirer une ligne seulement quand elle a été effectivement tranchée, et dire par qui et quand dans la section correspondante, pas juste supprimer la ligne.]
