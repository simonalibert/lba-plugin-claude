# Modèle : spec d'écran

Adapté de `design-handoff` (anthropics/knowledge-work-plugins, Apache 2.0). Supprimer les sections sans objet plutôt que de les laisser vides ; statuts selon `lba-design:principles` §2. Largeurs du tableau responsive : §5.

```markdown
## Spec : [écran ou composant], version [vN] du [JJ/MM/AAAA]
Source : [lien de nœud Figma] | DESIGN.md : [lien ou « aucun »] | Stack : [si connue]
Statut : validé par [nom] le [date] | à valider

### Rôle de l'écran
[Ce que fait l'écran, pour qui, action principale. 2 ou 3 lignes.]

### Structure
[Sections dans l'ordre, grille (colonnes, gouttières, marges), landmarks attendus (header, nav, main, footer).]

### Tokens utilisés
| Token | Valeur | Usage | Statut |
|---|---|---|---|
| `text/primary` | #111111 | Titres, corps | confirmé |
| `space/3` | 24 px | Entre carte et légende | confirmé |
| (valeur libre) | 60 px | Padding du hero | exception optique déclarée |

### Composants
| Composant | Variante | Propriétés | Particularités sur cet écran |
|---|---|---|---|

### États et interactions
| Élément | État | Comportement |
|---|---|---|
| CTA principal | survol | [changement, token] |
| CTA principal | focus visible | anneau `focus/ring` 2 px, décalage 2 px, sur fond clair et sombre |
| Liste filtrée | chargement | squelette, [n] cartes |
| Liste filtrée | vide | message + action de retour : [texte] |
| Liste filtrée | erreur | message + réessayer : [texte] |

### Responsive
| Largeur | Changements |
|---|---|
| 1440 | [référence] |
| 1280 | |
| 924 | |
| 768 | |
| 390 | |
[Décrire les changements de comportement (ordre, colonnes, recadrage et point focal des images, navigation), pas seulement les dimensions.]

### Contenus et cas limites
- Longueurs : [titre max n caractères ou n lignes, comportement au-delà]
- Donnée manquante : [image, date, auteur : que montrer]
- Volume : [0, 1, beaucoup d'éléments]
- Médias : [ratio par emplacement, point focal, poids cible]

### Mouvement
| Élément | Déclencheur | Animation | Durée | Courbe | Mouvement réduit |
|---|---|---|---|---|---|
[Toujours renseigner la colonne « mouvement réduit » : ce qui est coupé ou remplacé. Durées, courbe et distances : repères chiffrés de `lba-design:motion`.]

### Accessibilité (décisions UX)
- Hiérarchie des titres : [h1 unique, niveaux]
- Libellés accessibles à prévoir : [boutons icônes, liens ambigus]
- Clavier : [interactions spécifiques, gestion du focus à l'ouverture et à la fermeture]
- À vérifier en recette : ordre de tabulation, restitution lecteur d'écran, zoom 200 %.

### Zones grises
| Question | Ce qu'on sait | Qui tranche |
|---|---|---|
```
