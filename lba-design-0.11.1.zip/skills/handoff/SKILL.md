---
name: handoff
description: "Documentation de passation design vers dev, méthode La Bonne Agence : DESIGN.md (documentation vivante d'un design system, lisible par un agent de code comme par une personne), spécification d'un écran ou d'une version validée (tokens, composants, états, responsive, cas limites, mouvement) et annotations Figma d'écran ou de composant. Déclencher dès qu'il est question de handoff, de passation aux développeurs, de spec d'écran, de DESIGN.md, de documenter un design system ou des décisions de tokens et de composants, d'annoter une maquette pour le dev, ou quand une version est validée et doit être développée. Ne pas utiliser pour les annotations d'accessibilité (`lba-design:accessibility`), pour implémenter une maquette en code, ni pour construire la bibliothèque de composants dans Figma."
---

# Handoff : DESIGN.md, spec d'écran, annotations

**Préséance** : invariants de `lba-design:principles` > demande > état réel inspecté (Figma via `get_metadata`, `get_design_context`, `get_variable_defs`, ou code) > DESIGN.md existant > rendu visuel ou capture (jamais seul) > défauts du modèle.

Charger `lba-design:principles` avant de commencer.

Une valeur inventée dans une doc de passation devient une contrainte de production. **Ne jamais compléter une section par inférence visuelle ou par supposition : marquer une zone grise explicite plutôt que de deviner.** C'est la règle la plus importante de ce skill, avant toute question de format.

## Choisir le livrable

| Situation | Livrable | Référence |
|---|---|---|
| Vrai design system (tokens, composants réutilisables) suivi dans la durée par un agent de code ou plusieurs personnes | **DESIGN.md** | `references/design-md-template.md`, puis test de l'agent vierge |
| Écran, page ou version validée à développer | **Spec d'écran** | `references/spec-ecran.md` |
| Consigne ponctuelle sur un nœud précis de la maquette | **Annotation Figma** | section « Annotations » ci-dessous |
| Tokens à transmettre sous forme exploitable | **Fichier DTCG** | `references/tokens-dtcg.md` |

Ne pas systématiser un DESIGN.md pour un projet d'une page : une spec d'écran et quelques annotations suffisent. Une spec d'écran renvoie au DESIGN.md s'il existe au lieu de redocumenter les tokens.

## Règles communes, non négociables

1. **Vérifier avant d'écrire.** Toute valeur (hex, taille, ratio, durée) vient d'une inspection directe du fichier de travail (`get_metadata`, `get_design_context`, `get_variable_defs` sur le Figma réel) ou du code, jamais du rendu visuel seul ni du nom d'un composant.
2. **Tokens plutôt que valeurs** : citer `space/3` ou `text/primary`, avec la valeur en regard. Une valeur non tokenisée est signalée comme telle (exception légitime ou oubli à trancher).
3. **Statut explicite** sur toute affirmation non triviale (`lba-design:principles` §2). Une zone grise nommée vaut mieux qu'une case remplie approximativement.
4. **Tous les états** de chaque élément interactif ou chargé : défaut, survol, focus visible, actif, désactivé, et chargement, vide, erreur pour tout contenu filtré ou chargé. Un état absent de la maquette est listé comme manquant, pas inventé.
5. **Dire le pourquoi** des comportements non évidents (« la navigation passe en tiroir sous 924 px parce que les six entrées ne tiennent plus sur une ligne ») : le développeur arbitre mieux les cas non prévus.
6. **Dater** chaque mise à jour notable et dire ce qui a changé et pourquoi.
7. **Accessibilité** : séparer la décision UX actée de ce qui relève de la conformité (posture : `lba-design:principles` §3).

## DESIGN.md

### Où vit le fichier

Là où le lisent ceux qui le suivent : à la racine du dépôt si un agent de code ou une équipe de dev s'en sert (versionné avec le code), sinon dans le dossier projet partagé. Le demander à la création si ce n'est pas évident, et noter l'emplacement dans la fiche projet. Une seule source : pas de copie parallèle dans Figma ou dans un Claude Doc qui divergerait.

### Créer

1. Récupérer le contexte : brief, comptes rendus d'ateliers, premières maquettes ou composants déjà posés dans le Figma.
2. Poser la structure complète du modèle avec des zones grises explicites plutôt que des valeurs non vérifiées. Ne pas tout écrire en une passe si l'information manque.
3. Faire valider les fondations non négociables (stack, contraintes réglementaires, largeurs de référence) par la personne responsable côté client ou projet avant de les figer.

### Mettre à jour

1. Relire le fichier entier avant de toucher quoi que ce soit : ce qui est tranché, ce qui est en zone grise.
2. Vérifier l'état réel du Figma avant d'affirmer un écart, une évolution ou une correction ; ne jamais se fier à la mémoire d'une session précédente.
3. Éditer par petites touches datées, dans la section qui correspond ; ne jamais réécrire le fichier en entier ni écraser une section vérifiée par une inférence.
4. Ne retirer une zone grise que si elle a été tranchée, en disant par qui et quand.
5. Signaler un écart entre la doc et le fichier (composant documenté mais introuvable, par exemple) plutôt que de corriger en silence dans un sens ou dans l'autre.

### Tester avant de livrer : l'agent vierge

Un DESIGN.md est bon si quelqu'un qui ne connaît pas le projet peut s'en servir. Avant toute livraison ou mise à jour majeure :

1. Ouvrir une session sans aucun contexte du projet : nouvelle conversation hors projet Claude (claude.ai), ou nouvelle session Claude Code dans un dossier qui ne contient que le DESIGN.md et ses fichiers de tokens.
2. Lui demander un écran que personne n'a dessiné : un état vide, une page d'erreur, une rubrique non maquettée, une variante mobile d'un composant.
3. Relever chaque décision qu'il a dû prendre seul : couleur, espacement, comportement, formulation. Chaque invention révèle un manque.
4. Pour chacune : ajouter la règle manquante si elle est décidée, sinon l'inscrire en zone grise avec la question et la personne qui tranche.
5. Noter dans la ligne « Mise à jour du » ce que le test a révélé.

Ce test ne prouve rien sur la conformité ni sur la qualité du design ; il mesure seulement si le document suffit à décider sans deviner. Le refaire quand le projet ajoute un type d'écran.

### Taille

Rester actionnable : un agent ou un dev doit retrouver une information en quelques secondes. Au-delà de 300 à 400 lignes, envisager un découpage en fichiers liés ; ne pas fragmenter un projet encore petit.

## Selon le profil du projet

Reporter le profil (`lba-design:principles` §11) dans le DESIGN.md (§3, fondations) et en tête de chaque spec d'écran : il dit au développeur ce qui est négociable.

- **Vitrine expressive** : colonne « Mouvement » complète, effet par effet, avec son repli en mouvement réduit et à intensité 0 ; polices payantes : nom exact, licence web, fichiers à charger ; poids attendu de la page déclaré.
- **Conformité RGAA** : section accessibilité détaillée (titres, libellés accessibles, gestion du focus, messages de statut), critères RGAA associés, points « à vérifier en recette » listés pour l'audit de conformité qui suivra.
- **Éco-conçu** : budget de poids par gabarit (`lba-design:ui-design`, `references/qa.md` §1), formats et poids cibles des médias, polices limitées, chargement différé ; critères RGESN visés quand le client les a choisis.

## Spec d'écran

1. **Sources** : lien de nœud Figma précis (frame de l'écran, pas la page), version validée et sa date, DESIGN.md s'il existe, stack cible si connue (elle change les notes d'implémentation, pas la spec).
2. **Extraire** : structure, tokens utilisés, composants et variantes, états, comportement aux largeurs de contrôle (`lba-design:principles` §5), mouvement.
3. **Cas limites** à traiter systématiquement : contenu minimum et maximum (titre sur trois lignes, liste vide, 100 éléments), texte plus long qu'en maquette, donnée manquante (image, date, auteur), connexion lente, erreur de chargement.
4. **Rédiger** avec le modèle `references/spec-ecran.md`. Ce qui ne se vérifie qu'en code (ordre de tabulation réel, restitution lecteur d'écran, zoom 200 %) est listé « à vérifier en recette ».
5. Si le rapport part chez le client ou chez un prestataire de développement sous forme de document, utiliser les modèles de documents de l'agence.

## Annotations Figma

Une annotation est une consigne, pas une description : impérative, chiffrée (valeur et token), rattachée au nœud concerné. Par exemple : « Au-delà de 2 lignes, le titre est tronqué avec points de suspension ; titre complet dans l'attribut title du lien. » ou « Sous 768 px, les cartes passent en défilement horizontal, 1,2 carte visible pour signaler la suite. »

- Ne pas annoter ce que le composant ou le DESIGN.md documente déjà : l'annotation porte sur l'écart ou le comportement propre à cet écran.
- **Sortie par défaut** : texte à coller, une ligne par nœud, avec le nom du calque.
- **Écriture directe dans le fichier** via `use_figma`, après accord explicite seulement : lire `figma:figma-use` et `lba-design:figma` avant. Annotations natives de Dev Mode, méthode et pièges dans `lba-design:figma` §3 ; contrôle par relecture, les captures ne les montrent pas.
- Annotations d'accessibilité : `lba-design:accessibility`.

## Anti-défauts

| Éviter | Faire à la place | Pourquoi |
|---|---|---|
| Valeur déduite d'une capture ou d'un nom de composant | Valeur inspectée, ou zone grise nommée avec qui tranche | Une valeur inventée devient une contrainte de production |
| Valeur brute (`#1A1A1A`, `24px`) | Token cité, valeur en regard ; valeur non tokenisée signalée | Le développeur doit savoir ce qui varie avec le système |
| État absent de la maquette, rempli pour faire complet | Listé comme manquant | Un état inventé n'a été validé par personne |
| DESIGN.md réécrit d'un bloc | Petites touches datées dans la bonne section | On perd la trace de ce qui était vérifié |
| Comportement décrit sans raison | Le pourquoi en une phrase | Le développeur arbitre mieux les cas non prévus |
| DESIGN.md systématique pour un site d'une page | Spec d'écran et quelques annotations | Documenter un système qui n'existe pas |

## Attribution

La spec d'écran s'inspire du skill `design-handoff` du dépôt `anthropics/knowledge-work-plugins` (licence Apache 2.0), traduit et adapté à la méthode LBA. Voir `NOTICE` à la racine du plugin.
