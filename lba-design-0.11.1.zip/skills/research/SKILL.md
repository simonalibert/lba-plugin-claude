---
name: research
description: "Prépare et conduit la recherche utilisateur d'un projet web, méthode La Bonne Agence : choix des méthodes selon la question et le budget, plan de recherche, guides d'entretien, ateliers avec le client, tri de cartes et test d'arborescence pour une refonte, tests d'utilisabilité sur wireframe ou maquette, questionnaires, recrutement et consentement des participants. Déclencher dès qu'il est question de préparer des entretiens, un atelier, un test utilisateur, un questionnaire, un tri de cartes, de recruter des participants, ou de « savoir ce que veulent les usagers » avant de concevoir, même sans le mot « recherche ». Ne pas utiliser pour analyser un matériau déjà recueilli (`lba-design:synthesis`)."
---

# Recherche utilisateur

**Préséance** : invariants de `lba-design:principles` (données personnelles, consentement, ne rien inventer) > demande > décisions de conception à éclairer > études et données existantes du client > méthodes et repères d'échantillon (défauts maison).

Charger `lba-design:principles` avant de commencer.

En agence, la recherche se fait dans une phase de cadrage courte et un budget serré. Le but n'est pas une étude exhaustive, mais de réduire le risque sur les décisions qui coûteront cher à défaire : l'arborescence, les parcours prioritaires et le vocabulaire.

## 1. Partir de la décision, pas de la méthode

Avant toute méthode, écrire les **2 à 4 décisions de conception** que la recherche doit éclairer, par exemple « faut-il un espace par public ou une entrée par thème ? ». Chaque question de recherche se rattache à l'une d'elles. Une question sans décision derrière est retirée.

Lire d'abord la fiche projet (`lba-design:ui-design`, modèle de fiche projet), le brief et ce qui existe déjà : études du client, statistiques, retours du support, ancien site. Ne jamais planifier une étude pour apprendre ce qu'un document existant dit déjà.

## 2. Choisir la méthode

| Question | Méthode | Ordre de grandeur couramment admis | Remarques agence |
|---|---|---|---|
| Qu'est-ce que l'organisation attend, qui décide ? | Entretiens parties prenantes, atelier de cadrage | 4 à 8 personnes | Toujours faisable ; ne remplace pas les usagers |
| Comment se comporte-t-on sur le site actuel ? | Analyse de l'audience (statistiques, recherche interne, parcours) | Données existantes | Gratuit et factuel ; dit *quoi*, jamais *pourquoi* |
| Quels besoins, quels mots, quels freins ? | Entretiens usagers | 5 à 8 par profil | Le plus riche ; à prévoir dans le devis |
| Comment regrouper et nommer les contenus ? | Tri de cartes ouvert ou fermé | 15 à 30 participants | Méthode clé d'une refonte |
| L'arborescence proposée permet-elle de trouver ? | Test d'arborescence | Plusieurs dizaines de participants | À faire avant les maquettes |
| Le parcours fonctionne-t-il ? | Test d'utilisabilité modéré sur wireframe ou prototype | 5 à 8 par profil | Sur wireframe, c'est moins cher à corriger |
| Combien pensent quoi ? | Questionnaire | 100 et plus pour des proportions lisibles | Utile pour quantifier, jamais pour découvrir |

Les tailles d'échantillon sont des repères de pratique, pas des garanties statistiques : les présenter comme tels (statut « estimé », `lba-design:principles` §2).

**Quand il n'y a pas de budget usagers**, le dire au client plutôt que de le masquer. On peut alors combiner l'analyse de l'audience, les entretiens avec les équipes au contact du public (accueil, support, médiation) et un test de guérilla rapide sur wireframe. Tout ce qui en sort est une **hypothèse à valider**, et la synthèse le signalera.

**Publics multiples** (grand public et professionnels, familles et chercheurs) : recruter et analyser **par profil**, jamais en moyenne. Cinq entretiens répartis sur trois profils ne disent rien d'aucun d'entre eux.

## 3. Plan de recherche

```markdown
## Plan de recherche : [projet], [date]
Décisions à éclairer : 1. … 2. …
Questions de recherche (rattachées à une décision) : …
Méthodes et pourquoi : …
Profils et recrutement : [profil, nombre, canal de recrutement, qui recrute (agence ou client)]
Calendrier : [jalons, dans le planning de la phase de cadrage]
Livrables : [synthèse, arborescence, recommandations]
Données personnelles : [ce qui est recueilli, conservé, où, combien de temps, qui y accède]
Hors champ : [ce que cette recherche ne dira pas]
```

## 4. Guide d'entretien

Structure de 45 à 60 minutes : accueil et consentement (5 min), contexte et habitudes (10 min), exploration du sujet (20 min), réaction à un support si besoin (10 min), clôture (5 min).

Règles d'écriture des questions :

- faire raconter des faits passés (« la dernière fois que vous avez cherché… ») plutôt que des intentions ou des préférences (« est-ce que vous utiliseriez… ») ;
- des questions ouvertes, une idée par question, et des relances neutres (« c'est-à-dire ? », « et ensuite ? ») ;
- ne jamais montrer la solution avant d'avoir compris le besoin ;
- noter à côté de chaque bloc la question de recherche qu'il sert.

## 5. Atelier avec le client

L'atelier recueille la vision de l'organisation, pas celle des usagers : le dire dans le compte rendu. Formats utiles en refonte : priorisation des publics et de leurs tâches principales, tri de cartes collectif sur les contenus existants, carte des parcours actuels avec leurs points de friction connus. Préparer le déroulé minuté, le matériel (FigJam ou papier) et la sortie attendue de chaque séquence.

## 6. Tests d'utilisabilité

Tester des **tâches**, pas des écrans : « trouvez les horaires du spectacle de samedi », et non « que pensez-vous de cette page ? ». Rédiger 3 à 6 tâches issues des parcours prioritaires, avec un critère de réussite défini à l'avance. Sur wireframe, le contenu doit être assez réel pour que la tâche ait un sens.

Inclure si possible des personnes qui utilisent des technologies d'assistance. Ce n'est pas un audit RGAA (`lba-design:accessibility`), mais c'est souvent là que se voient les vrais blocages.

## 7. Participants, consentement, données

- **Consentement éclairé** avant toute séance : objet de l'étude, enregistrement ou non, usage et durée de conservation, droit de se retirer. Pas d'enregistrement sans accord explicite.
- **Minimiser et pseudonymiser** selon `lba-design:principles` §7, dès la prise de notes.
- **Mineurs** : un recrutement de moins de 18 ans demande des précautions particulières, dont l'accord des représentants légaux. Le signaler au client et le faire valider par son ou sa référente RGPD ; ne pas trancher le cadre juridique.
- **Outils** : un outil en ligne de tri de cartes, de test ou de questionnaire héberge des données de participants ; hébergement à vérifier avec le client (`lba-design:principles` §7).

## 8. Suite

Le matériau recueilli s'analyse avec `lba-design:synthesis`. Les décisions prises à partir de la recherche sont reportées, datées, dans le journal de décisions de la fiche projet.

## Anti-défauts

| Éviter | Faire à la place | Pourquoi |
|---|---|---|
| Choisir la méthode avant la question | Partir des 2 à 4 décisions à éclairer | Une étude sans décision derrière ne change rien |
| Questions d'intention (« utiliseriez-vous… ? ») | Faire raconter des faits passés | Les intentions déclarées prédisent mal les usages |
| Montrer la solution avant de comprendre le besoin | Explorer d'abord, réagir à un support ensuite | Le support oriente les réponses |
| Moyenne entre publics | Recrutement et analyse par profil | Cinq entretiens sur trois profils ne disent rien d'aucun |
| Masquer l'absence de budget usagers | Le dire, combiner sources disponibles, tout marquer « hypothèse » | Le client doit savoir sur quoi repose la décision |
| Questionnaire pour découvrir | Entretiens pour découvrir, questionnaire pour quantifier | Un questionnaire ne trouve que ce qu'on lui demande |

## Attribution

Adapté du skill `user-research` du dépôt `anthropics/knowledge-work-plugins` (licence Apache 2.0), traduit et réécrit pour le contexte d'une agence web (refontes, publics multiples, RGPD, budgets de cadrage). Voir `NOTICE` à la racine du plugin.
