---
name: wireframe
description: "Conçoit la structure d'un site ou d'une page avant toute direction graphique, méthode La Bonne Agence : arborescence et plan de site, zoning, wireframes basse fidélité (niveaux de gris, police par défaut) en mobile first (Figma avec un design system neutre, Claude Design ou HTML), hiérarchie des contenus, parcours, annotations de comportement, et contrat de structure transmis à la maquette. Déclencher dès qu'il est question de wireframe, de zoning, d'arborescence, de plan de site, de structure ou de squelette de page, d'ordre des sections, de maquette fil de fer ou basse fidélité, même sans le mot « wireframe ». Ne pas utiliser pour la haute fidélité ou la direction graphique (`lba-design:ui-design`), pour préparer une étude (`lba-design:research`) ni pour analyser un matériau recueilli (`lba-design:synthesis`)."
---

# Wireframe : structure avant le visuel

**Préséance** : invariants de `lba-design:principles` > demande > synthèse de recherche et décisions validées > arborescence ou structure imposée par le client > rendu lofi et contrat de structure (standards) > défauts maison.

Charger `lba-design:principles` avant de commencer (ne rien inventer, statuts, données personnelles).

Un wireframe décide de la structure, des contenus, de leur priorité et des parcours. Il ne décide de rien de visuel : rendu basse fidélité imposé, niveaux de gris et police par défaut, selon `references/rendu-lofi.md` (palette de sept valeurs, quatre tailles de texte, conventions pour images, boutons et annotations). À lire avant de construire, quel que soit l'outil. Un wireframe trop joli fait valider un style au client avant l'heure et brouille la discussion sur la structure. Sa sortie est un **contrat de structure**, que `lba-design:ui-design` reçoit ensuite.

## 1. Sources avant de dessiner

Lire la fiche projet (son modèle fait partie du skill `lba-design:ui-design`), le brief, et ce qui existe : synthèse de recherche et arborescence issues de `lba-design:synthesis`, inventaire des contenus du site actuel, contenus réels fournis, DESIGN.md s'il existe (lexique §2.2). Puis, si la demande et la fiche ne le disent pas, **ouvrir la fenêtre de questions** de la surface (choix sur claude.ai, `AskUserQuestion` dans Claude Code), en une seule fois, seulement pour ce qui manque :

| # | En-tête | Question | Options | Défaut sans réponse |
|---|---|---|---|---|
| 1 | Outil | Dans quel outil faire le wireframe ? | Figma + Simple Design System · Claude Design · HTML autonome · Au choix | Figma + Simple Design System si le connecteur Figma est disponible (pratique de l'agence) ; sinon Claude Design sur claude.ai, HTML ailleurs |
| 2 | Périmètre | Qu'est-ce qu'on structure ? | Une page · Accueil et gabarits clés · Arborescence et gabarits clés | La page demandée, et seulement elle |
| 3 | Contenus | Avec quels contenus ? | Contenus réels fournis · Chercher dans Google Drive · Génériques, à fournir · Un mélange | Génériques, marqués « À fournir » |

N'offrir Figma que si le connecteur Figma est disponible dans la session ; sinon, le dire en une phrase et proposer de le connecter. Si les contenus réels sont choisis, demander ensuite en une phrase de les joindre. Google Drive : seulement si l'option est cochée, jamais par défaut ; lister ce qui a été trouvé et faire confirmer avant de l'utiliser (règle détaillée dans les questions de cadrage de `lba-design:ui-design`). Une quatrième question, dans Claude Code seulement, peut porter sur le public prioritaire et l'action principale attendue. Sans réponse, les défauts deviennent des hypothèses listées en tête. Si la personne demande d'avancer sans questions (« pas de questions », « fais au mieux »), aucune fenêtre : appliquer les défauts et les lister en tête.

## 2. Arborescence

Si une synthèse de recherche existe, l'arborescence en part. Sinon, la proposer comme **hypothèse** (`lba-design:principles` §2) : entrées par public ou par tâche plutôt que par organigramme, trois niveaux au plus sauf justification, libellés tirés du lexique du projet ou du vocabulaire des usagers, jamais du jargon interne. La faire valider par un test d'arborescence dès que le projet le permet (`lba-design:research`).

Livrable : plan de site en liste indentée ou en diagramme, chaque rubrique avec son public principal et sa source (recherche, brief, site actuel, hypothèse).

## 3. Page : structure et contenus

- **Mobile first** : construire d'abord à 390 px, puis 1440 px ; les autres largeurs de contrôle (`lba-design:principles` §5) seulement si la structure y change. Un écran mobile n'est pas un desktop empilé : l'ordre des sections peut différer et se justifie.
- **Sections** : pour chacune, son rôle (en une phrase), ses contenus, sa priorité, son action principale. Une section sans rôle clair est retirée ou signalée.
- **Contenus** : réels uniquement s'ils sont fournis. Sinon, le contenu générique du design system utilisé (« Titre », texte de remplacement neutre), jamais un faux contenu réaliste inventé, et l'étiquette « À fournir » sur ce qui doit venir du client. Pour les contenus denses (résultats, tableaux, graphiques), montrer le cas réel le plus chargé et le cas vide.
- **Cas limites** à poser dès ce stade : titre long, liste vide, beaucoup de résultats, donnée manquante.
- **Libellés** de navigation et de CTA : les écrire avec `lba-design:microcopy`, même provisoires ; ce sont des décisions de structure.
- **Accessibilité structurelle** : un seul h1, hiérarchie des titres sans saut, ordre de lecture identique à l'ordre visuel, landmarks identifiables. Le reste viendra en haute fidélité.

## Selon le profil du projet

Le wireframe reste en 390 et 1440 quel que soit le profil (`lba-design:principles` §11) : c'est là que la structure mobile se décide, même si la haute fidélité ne sera dessinée qu'en desktop. Le profil change ce que la structure doit prévoir :

- **Vitrine expressive** : annoter les intentions de mouvement qui changent la structure (section épinglée et sa longueur de défilement, média qui persiste d'une section à l'autre, séquence d'images) ; chacune a son équivalent statique, décrit.
- **Conformité RGAA** : deux systèmes de navigation au moins (menu plus recherche ou plan du site, RGAA 12.1), lien d'évitement, fil d'Ariane sur les pages profondes, emplacement des mentions et de la déclaration d'accessibilité en pied de page.
- **Éco-conçu** : chaque média du zoning justifie sa présence ; pas d'emplacement de vidéo en lecture automatique ni de carrousel ; pages courtes, parcours sans détour (famille « Expérience et interface utilisateur » du RGESN).

**Périmètre** (défaut maison) : dessiner seulement les écrans demandés. Les écrans qui sembleraient utiles se proposent en une liste, sans les dessiner, et ne se construisent qu'après accord.

**Langue et termes** (défaut maison) : l'interface est dans la langue de ses utilisateurs finaux, avec les termes des documents source fournis (présentation, cahier des charges, site existant) plutôt que des synonymes. Relever ces termes dans le lexique du DESIGN.md (§2.2) ou, à défaut, dans la fiche projet.

## 4. Construire

Défaut maison : construire **la page complète en un seul passage**, puis présenter le résultat, sauf si une validation section par section est demandée.

Selon l'outil :

- **Figma** : design system neutre (Simple Design System ou celui du projet), recoloré avec les variables « Lofi » (`references/rendu-lofi.md`), sans détacher les composants. Charger `figma:figma-use`, `figma:figma-generate-design` pour l'assemblage par composants, et `lba-design:figma` pour les pièges connus, dont l'import des bibliothèques de la communauté. Inspecter le nœud visé (`get_metadata`) avant d'écrire, et signaler tout écart entre le nœud et la demande avant de modifier.
- **Claude Design ou HTML** : variables CSS et classes de `references/rendu-lofi.md`, telles quelles.
- **Wireframe existant** (Axure, client, autre outil) : ne pas le refaire ; en extraire le contrat de structure (§5).

Vérifier par capture après construction : ordre des sections, rien de tronqué, mobile et desktop cohérents, aucune couleur ni police hors de la spécification lofi.

## 5. Contrat de structure (sortie obligatoire)

Format commun avec `lba-design:ui-design` (référence `sources-entree.md`) : si l'un change, changer l'autre.

| Section | Contenu | Priorité | Statut | Note |
|---|---|---|---|---|
| Hero | Titre, accroche, CTA « Réserver une visite » | 1 | figé | libellé validé client |
| Agenda | 3 événements, 1 à la une | 2 | ajustable | ordre interne libre |

Statuts : **figé** (validé par le client, annoté, demandé), **ajustable** (ordre interne, proportions), **libre** (tout traitement visuel). Avant validation client, tout est au mieux ajustable. Les annotations de comportement (repli, filtre, troncature, contenu dynamique) accompagnent le contrat ; elles priment sur le dessin.

## Défauts maison

| Défaut | Raison |
|---|---|
| Mobile first : 390 d'abord, puis 1440 | La place réduite force la hiérarchie ; la structure mobile se décide ici, même si la haute fidélité ne sera dessinée qu'en desktop |
| Arborescence par public ou par tâche, trois niveaux au plus | L'usager cherche ce qu'il veut faire, pas l'organigramme ; au-delà de trois niveaux, on se perd |
| Page complète en un seul passage, puis présentation | La structure se juge d'un bloc ; section par section, seulement si demandé |
| Trois questions de cadrage au plus | Le wireframe est rapide à corriger : mieux vaut une hypothèse visible qu'une attente |
| Libellés de navigation et de CTA écrits dès le wireframe (`lba-design:microcopy`) | Ce sont des décisions de structure, pas de la finition |

## Anti-défauts

| Éviter | Faire à la place | Pourquoi |
|---|---|---|
| Wireframe « joli » (couleurs, photos, police de marque) | Rendu lofi de `references/rendu-lofi.md`, tel quel | Le client valide un style avant l'heure et ne discute plus la structure |
| Faux contenu réaliste (noms, chiffres, citations crédibles) | Contenu générique du design system et étiquette « À fournir » | Un faux crédible passe pour validé (`principles` §1) |
| Desktop empilé en guise de mobile | Ordre et regroupements pensés pour 390, écarts justifiés | Un écran mobile a ses propres priorités |
| Arborescence calquée sur l'organigramme ou le jargon interne | Entrées par public ou par tâche, mots des usagers (lexique, synthèse) | L'usager ne connaît pas l'organisation |
| Section sans rôle clair | La retirer, ou la signaler en question | Une section qui ne sert pas dilue celles qui servent |
| Refaire un wireframe existant (client, Axure, autre outil) | En extraire le contrat de structure | Le travail validé ne se redessine pas |
| Montrer seulement le cas idéal | Le cas réel le plus chargé et le cas vide, pour les contenus denses | Le pire cas se décide au stade de la structure |

## 6. Livrer

Rapport court : hypothèses en tête, plan de site, wireframes 390 et 1440, contrat de structure, annotations, contenus à fournir, points à valider avec le client. Décisions datées dans le journal de la fiche projet. Après validation, la haute fidélité part de ce contrat (`lba-design:ui-design`).
