# Rendu basse fidélité (lofi) : spécification imposée

Le wireframe doit se lire comme une structure, jamais comme une proposition graphique. Ce rendu est un **standard LBA** (`lba-design:principles` §10) : on ne s'en écarte que sur demande explicite, déclarée dans le rapport.

## Palette : sept valeurs, aucune autre

| Rôle | Valeur | Usage |
|---|---|---|
| Fond | `#FFFFFF` | Fond de page |
| Surface | `#F2F2F2` | Sections alternées, cartes, blocs |
| Boîte | `#D9D9D9` | Images, vidéos, logos, icônes |
| Trait | `#8C8C8C` | Bordures, filets, champs, croix des images (3,36:1, réservé aux éléments non textuels) |
| Texte secondaire | `#595959` | Métadonnées, légendes (7:1 sur blanc, 6,3:1 sur surface) |
| Texte | `#1A1A1A` | Texte courant, titres, bouton principal |
| Annotation | `#C2185B` | **Uniquement** les pastilles et notes d'annotation, jamais un élément de la page |

Contrastes calculés avec `contrast.py` : tout texte reste au-dessus des seuils de `lba-design:principles` §4, même en lofi.

## Typographie : une famille, deux graisses, quatre tailles

- Police par défaut de l'outil : **Inter** dans Figma (déjà chargée), **Arial** dans le navigateur (`Arial, Helvetica, sans-serif`). Jamais la police de la marque.
- Graisses : Regular et Bold seulement. Pas d'italique décoratif, pas de capitales espacées.

| Style | Mobile (390) | Desktop (1440) |
|---|---|---|
| Titre 1 | 32 / 40 | 48 / 56 |
| Titre 2 | 24 / 32 | 32 / 40 |
| Texte | 16 / 24 | 18 / 28 |
| Petit | 14 / 20 | 14 / 20 |

## Éléments

- **Image ou vidéo** : boîte `#D9D9D9`, croix diagonale en trait `#8C8C8C`, étiquette centrée sur fond de la boîte, pour rester lisible au-dessus de la croix, avec la nature et le ratio (« Photo 16:9 », « Vidéo 4:5 ») ; en HTML : `<div class="lofi-img"><span>Photo 16:9</span></div>`. Ratio repris de `lba-design:media` ou du DESIGN.md s'il existe, sinon hypothèse.
- **Logo** : boîte avec le mot « Logo ». **Icône** : carré de 24 px `#D9D9D9`.
- **Bouton principal** : fond `#1A1A1A`, texte blanc Bold. **Secondaire** : contour 1 px `#1A1A1A`, fond blanc. **Lien** : texte souligné.
- **Champ de formulaire** : rectangle contour `#8C8C8C`, étiquette visible au-dessus.
- **Angles** : 0, ou 4 px au plus. Espacements sur la grille de 8.
- **Annotations** : pastille numérotée `#C2185B` sur l'élément, note correspondante dans la marge ou une colonne à part, jamais par-dessus le contenu.

## Interdit en lofi

Couleur de marque, photo, illustration, emoji décoratif, dégradé, ombre, transparence, police de la marque, animation, effet de survol stylisé. Un élément qui « fait joli » est retiré.

## HTML et Claude Design

```css
:root {
  --lofi-fond: #ffffff;
  --lofi-surface: #f2f2f2;
  --lofi-boite: #d9d9d9;
  --lofi-trait: #8c8c8c;
  --lofi-texte-2: #595959;
  --lofi-texte: #1a1a1a;
  --lofi-annotation: #c2185b;
  --lofi-font: Arial, Helvetica, sans-serif;
}
body { margin: 0; background: var(--lofi-fond); color: var(--lofi-texte); font: 400 16px/24px var(--lofi-font); }
.lofi-img { background: var(--lofi-boite); display: grid; place-items: center; color: var(--lofi-texte-2); font-size: 14px;
  background-image: linear-gradient(to top right, transparent calc(50% - 0.5px), var(--lofi-trait) 50%, transparent calc(50% + 0.5px)),
                    linear-gradient(to bottom right, transparent calc(50% - 0.5px), var(--lofi-trait) 50%, transparent calc(50% + 0.5px)); }
.lofi-img > span { background: var(--lofi-boite); padding: 2px 8px; } /* étiquette lisible au-dessus de la croix */
.lofi-btn { font: inherit; background: var(--lofi-texte); color: #fff; font-weight: 700; border: 0; border-radius: 0; padding: 12px 24px; min-height: 44px; }
.lofi-btn--secondaire { background: #fff; color: var(--lofi-texte); border: 1px solid var(--lofi-texte); }
.lofi-note { color: var(--lofi-annotation); font-size: 14px; }
@media (min-width: 924px) { body { font-size: 18px; line-height: 28px; } } /* 924 : largeur de contrôle (principles §5) */
```

## Figma

- Créer (ou réutiliser) une collection de variables locale « Lofi » avec les sept couleurs, et y lier tous les remplissages et contours. Styles de texte locaux « Lofi / Titre 1 » à « Lofi / Petit » en Inter.
- Avec un design system de la communauté (Simple Design System) : garder les composants pour leur structure, mais lier leurs couleurs aux variables Lofi (mode de variables ou remplissages des instances). Ne jamais détacher un composant pour le recolorer.
- Frames 390 et 1440 nommés `Lofi / <page> / 390` et `Lofi / <page> / 1440`.
- Vérifier par capture qu'aucune couleur hors palette ne subsiste (`get_variable_defs`, `get_screenshot`).
