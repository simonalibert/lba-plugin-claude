---
name: principles
description: "Règles communes à tous les skills `lba-design` de La Bonne Agence, écrites une seule fois : ne rien inventer, statuts de vérification et niveaux de preuve, posture de conformité (RGAA, WCAG, RGPD), seuils d'accessibilité, largeurs de contrôle, typographie française, données personnelles, forme des livrables. À charger dès qu'un autre skill `lba-design` le demande, et quand l'utilisateur interroge les règles, principes ou standards de l'agence en UX / UI. Ne remplace aucun skill métier : il fixe les règles, les autres skills disent comment faire."
---

# Principes communs LBA Design

Source unique des règles partagées par les skills du plugin. Un skill qui applique une de ces règles la cite (« seuils de `lba-design:principles` ») au lieu de la recopier : une règle recopiée finit par diverger. En cas d'écart apparent entre ce fichier et un autre skill, ce fichier fait foi ; signaler l'écart. Avant d'appliquer une règle, savoir à quel niveau elle appartient et quelle source l'emporte (§10), et quel profil de projet est déclaré (§11).

## 1. Ne rien inventer

Aucun chiffre, citation, témoignage, valeur de token, ratio, statistique, logo, délai ou engagement qui ne vienne d'une source réelle (fichier inspecté, document fourni, données du client, propos d'un participant). Un contenu manquant est remplacé par un emplacement explicite « À fournir » et listé en fin de livraison. Un matériau lacunaire donne un livrable court, pas un livrable comblé.

## 2. Statuts

**Provenance d'une valeur ou d'un fait** (tokens, ratios, quantités, mesures, comportements) :

- **Vérifié** : lu directement dans la source réelle (Figma inspecté, code, site mesuré, document du client).
- **Estimé** : déduit par analogie, extrapolé ou lu à l'œil sur une capture. Préfixer la valeur de « ~ » et le dire.
- **À trancher avec [personne nommée]** : question ouverte, avec la question précise et qui peut y répondre.

L'absence de preuve contraire ne vaut pas vérification : sans inspection, le statut reste « estimé » ou « à trancher ». Un livrable qui mélange des statuts sans les distinguer trompe sur sa fiabilité.

**Niveau de preuve d'un constat de recherche** :

- **Solide** : plusieurs sources ou profils concordants.
- **À confirmer** : une seule source ou peu de participants.
- **Hypothèse** : issu d'un atelier interne ou d'un avis d'expert, pas d'usagers.

Compter plutôt que qualifier (« 6 sur 8 », jamais « la plupart ») ; pas de pourcentage sur un échantillon qualitatif.

## 3. Posture de conformité

- Ne jamais prononcer une conformité (RGAA, RGPD, éco-conception) ni trancher une question juridique comme un fait établi. Un contrôle sur maquette ou par script est une **pré-évaluation**, à dire comme telle. Le cadre juridique se fait confirmer par le référent du client ou de l'agence.
- **Référentiel réglementaire** : RGAA 4.1, qui s'appuie sur WCAG 2.1 niveaux A et AA. En Europe, l'European Accessibility Act et la norme EN 301 549 encadrent aussi certains services.
- **Cible interne** : WCAG 2.2 AA, plus exigeante que le référentiel. Un critère WCAG 2.2 absent du RGAA, ou un critère AAA, est signalé comme **bonne pratique**, jamais comme non-conformité.
- **Éco-conception** : référentiel RGESN 2024 (référentiel général d'écoconception des services numériques, 78 critères en 9 familles, publié le 17 mai 2024 par l'Arcep et l'Arcom avec l'ADEME, en application de la loi REEN du 15 novembre 2021). Les critères de la famille « Expérience et interface utilisateur » et « Contenus » concernent directement la conception ; les citer par leur numéro quand une recommandation s'y rattache. Même posture qu'en accessibilité : on contribue à une démarche, on ne déclare pas une conformité à la place du client, qui publie lui-même sa déclaration d'écoconception.
- Citer le critère WCAG systématiquement ; citer le critère RGAA seulement si la correspondance est certaine, sinon écrire « correspondance RGAA à vérifier ».

## 4. Seuils d'accessibilité

| Règle | Seuil | Critère |
|---|---|---|
| Contraste du texte | ≥ 4,5:1 | WCAG 1.4.3 |
| Contraste du grand texte (≥ 24 px, ou ≥ 18,66 px en gras) | ≥ 3:1 | WCAG 1.4.3 |
| Composants d'interface et graphiques porteurs d'information | ≥ 3:1 | WCAG 1.4.11 |
| Focus visible | présent sur tout élément interactif, lisible sur tous les fonds ; bonne pratique : ≥ 2 px et ≥ 3:1 | WCAG 2.4.7 |
| Cibles | ≥ 24 × 24 px partout (WCAG 2.2, 2.5.8) ; ≥ 44 × 44 px pour navigation, filtres et CTA (cible interne, 2.5.5 AAA) | WCAG 2.5.8, 2.5.5 |
| Mouvement | `prefers-reduced-motion: reduce` coupe tout déplacement, changement d'échelle, flou, parallaxe et défilement automatique, sans perte de compréhension ; les fondus d'opacité courts et les changements de couleur sont conservés | WCAG 2.3.3 (AAA), bonne pratique |
| Longueur de ligne | paragraphes à 75 caractères au plus | bonne pratique |
| Taille de texte | ce qui ne bouge pas : texte lisible et intact au zoom 200 % (WCAG 1.4.4). Repères de départ (convention, ajustables) : texte courant 16 px (18 en desktop), libellés, métadonnées et CTA 14 px. Ils s'ajustent à la police : une famille à petite hauteur d'x demande plus, une condensée en capitales peut rester à 14 px ; juger sur rendu, pas sur le chiffre | WCAG 1.4.4 ; repères : bonne pratique |

Jamais d'opacité réduite sur du texte, jamais de couleur seule pour porter une information (WCAG 1.4.1). Contrastes toujours calculés, jamais estimés de tête (`lba-design:accessibility`, script `contrast.py`).

Ces seuils sont aussi codés dans `ui-design/scripts/qa.py` et `accessibility/scripts/contrast.py` : toute modification ici se reporte dans les scripts, et inversement.

## 5. Largeurs de contrôle

390, 768, 924, 1280 et 1440 px. Le site livré fonctionne à toutes ces largeurs (principe : rien ne déborde, rien ne disparaît). Ce qui est **dessiné** est une décision projet : 1440 seul, ou 390 et 1440. Quand le mobile est dessiné, les deux versions se conçoivent ensemble, au même numéro, sans que l'une soit la déclinaison de l'autre. Quand il ne l'est pas, le comportement mobile est décrit (annotations ou spec d'écran, `lba-design:handoff`) et contrôlé sur le HTML. Ces largeurs sont codées dans `qa.py` (`DEFAULT_WIDTHS`).

## 6. Typographie française

- Espace insécable avant « : » ; espace fine insécable avant « ? », « ! » et « ; ».
- Guillemets français « … », avec espaces insécables à l'intérieur.
- Espace insécable entre un nombre et son unité, et entre les tranches de milliers.
- Majuscule au premier mot seulement dans les titres et libellés.

## 7. Données personnelles et confidentialité

- Minimiser : ne recueillir et ne traiter que ce qui sert la tâche.
- Pseudonymiser avant toute analyse : participants désignés par un code (P1, P2…), aucune donnée identifiante (nom, contact, enregistrement brut) collée dans une conversation.
- Outils en ligne qui hébergent des données de participants ou de clients : vérifier l'hébergement avec le client, préférer une solution hébergée en Europe.
- Secret, mot de passe ou jeton repéré dans un fichier ou une conversation : le signaler immédiatement, ne pas le réutiliser ; s'il s'agit d'une donnée réelle, prévenir le référent sécurité.

## 8. Forme des livrables

- Dater chaque livrable et chaque mise à jour notable, en disant ce qui a changé et pourquoi.
- Hypothèses listées en tête, visibles et réversibles ; écarts aux règles déclarés et justifiés.
- Documents agence vers client : modèles de documents de l'agence ; livrables pour le site du client : charte du client.
- Décisions reportées, datées, dans le journal de la fiche projet (modèle dans `lba-design:ui-design`).
- Concis : tableaux plutôt que prose quand le contenu s'y prête, pas de justification répétée.

## 9. Faire évoluer ces règles, écrire un skill

Toute nouvelle règle est classée dans un des niveaux du §10 dès son ajout. Une règle commune s'ajoute ici, pas dans un skill métier. Toute modification est datée dans le CHANGELOG du plugin et vérifiée par les évaluations du skill concerné (`EVALS.md`).

**Gabarit d'écriture d'un skill** (sections dans cet ordre, facultatives quand le domaine ne s'y prête pas) :

1. **Description** (frontmatter) : ce que fait le skill, les mots que les gens emploient pour le demander, ce qui relève d'un autre skill. Rien d'autre : c'est elle qui décide du déclenchement.
2. **Préséance** : une ligne, propre au domaine, qui dit quelle source l'emporte (modèle au §10).
3. **Invariants** : un renvoi à ce fichier, jamais une copie ; seuls les invariants propres au domaine s'écrivent dans le skill.
4. **Profil** : ce que les profils du §11 changent dans ce domaine, quand ils changent quelque chose.
5. **Déroulé** : les étapes, chacune avec la référence à lire à ce moment-là.
6. **Règles du domaine** (standards) : vérifiées à chaque livraison, écart déclaré.
7. **Défauts maison, chacun avec sa raison** : une raison permet d'abandonner un défaut à bon escient ; un défaut sans raison connue le dit (« raison à écrire »).
8. **Anti-défauts** : ce qu'on évite, ce qu'on fait à la place, pourquoi. Remplacer vaut mieux qu'interdire.
9. **Selon l'environnement** : outils, replis (`EXECUTION.md`).
10. **Références** : chaque fichier avec le moment où le lire.

Le `SKILL.md` reste court (150 lignes environ) ; les méthodes longues vont en références, lues au moment dit par le déroulé. Un même sujet n'a qu'une source : un skill renvoie à un autre plutôt que de le recopier.

## 10. Préséance et niveaux de règle

**Préséance générale**, de la plus forte à la plus faible :

> invariants > demande ou brief > décisions validées (fiche projet, DESIGN.md) > design system ou charte du client > standards LBA > défauts maison

Une demande explicite rouvre une décision validée, et le changement se consigne ; elle ne rouvre jamais un invariant. Chaque skill décline cette ligne pour son domaine.

| Niveau | Ce que c'est | Peut-on s'en écarter ? | Exemples |
|---|---|---|---|
| **Invariant** (« principe » dans les skills) | Règle valable dans toute situation, souvent réglementaire ou éthique | Non, quels que soient la demande, le profil ou le client | Ne rien inventer (§1), statuts (§2), posture de conformité (§3), seuils WCAG AA et mouvement réduit (§4), données personnelles (§7) |
| **Standard LBA** | Exigence de qualité de l'agence, vérifiée à chaque livraison | Oui, par un écart déclaré et justifié dans le livrable | Impératifs de `lba-design:ui-design`, socle de `lba-design:motion`, règles communes de `lba-design:handoff`, rendu lofi de `lba-design:wireframe` |
| **Défaut maison** (« convention LBA » dans les skills) | Point de départ de l'agence, avec sa raison | Oui, dès que la demande, la fiche projet, le design system ou la charte du client en dispose autrement, sans justification | Défauts de `ui-design`, repères chiffrés de `motion`, ton par défaut de `microcopy`, nomenclatures de `media` |

Les **décisions projet** ne sont pas un niveau mais une source : consignées et datées dans la fiche projet ou le DESIGN.md, elles se révisent là, jamais en silence. Les **profils** (§11) déplacent des standards et des défauts, jamais un invariant. Le jugement (direction artistique, arbitrage entre défauts) s'exerce dans l'espace laissé par ces règles, jamais contre un invariant ni contre un standard non écarté.

Un défaut maison n'est pas une vérité du design : chez un client, sa charte et ses décisions passent avant nos habitudes.

## 11. Profils de projet

Les sites de l'agence ne se ressemblent pas : vitrine animée avec polices payantes, service soumis au RGAA, site éco-conçu. Le profil se déclare dans la fiche projet (modèle dans `lba-design:ui-design`), un ou plusieurs à la fois ; sans profil déclaré, les conventions par défaut s'appliquent. Un profil déplace des **conventions** et des **standards** ; il ne touche jamais aux **principes** (§1 à §4, §7) : ne rien inventer, contrastes, focus visible, aucun contenu invisible, mouvement réduit respecté, données personnelles.

| | Standard (défaut) | Vitrine expressive | Conformité RGAA | Éco-conçu |
|---|---|---|---|---|
| Pour qui | sites institutionnels et de marque sans contrainte particulière | marque, produit, événement, portfolio ; GSAP, effets, polices payantes | organisme soumis à l'obligation, ou client qui vise la conformité | client engagé dans une démarche RGESN, ou demande de sobriété |
| Motion (`motion`) | socle et repères chiffrés | repères étendus (durées plus longues, effets bonus, séquences), toujours avec intensité, mouvement réduit et safety nets | sobre : pas d'effet bonus, aucun contenu révélé seulement au défilement sans repli | minimal : transitions CSS, pas de GSAP ni Lenis sans justification |
| Polices | woff2, graisses utilisées | payantes possibles, licence web vérifiée ; nombre de fichiers libre, poids déclaré | lisibilité avant caractère ; repères de taille tenus | une famille (variable si possible) ou police système |
| Budget de page (`ui-design`, `references/qa.md` §1) | mesuré et rapporté, pas de seuil | mesuré, dépassement déclaré | mesuré | **imposé** : 1,5 Mo accueil, 1 Mo contenu (à calibrer), `qa.py --eco` |
| Accessibilité | seuils §4, pré-contrôle `qa.py` | idem ; les effets ne passent qu'avec leur repli | pré-évaluation `lba-design:accessibility` à chaque version validée, critères RGAA AA cités, aucun écart aux impératifs d'accessibilité | seuils §4 |
| Version mobile dessinée (§5) | décision projet | décision projet | recommandée | décision projet |
| Référentiel cité | aucun | aucun | RGAA 4.1 (§3) | RGESN 2024 (§3) |

Combinaisons : « Vitrine expressive + Conformité RGAA » est possible (les effets restent, chacun avec un repli accessible) ; « Vitrine expressive + Éco-conçu » se contredit sur le motion et les polices : la fiche projet tranche, effet par effet.

