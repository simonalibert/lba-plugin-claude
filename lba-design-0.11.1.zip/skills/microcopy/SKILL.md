---
name: microcopy
description: "Rédige ou relit les textes d'interface en français selon la méthode La Bonne Agence : libellés de boutons et de liens, messages d'erreur et de validation, états vides, chargements, dialogues de confirmation, étiquettes et aides de formulaire, infobulles, messages de statut. Déclencher dès que l'utilisateur demande quoi écrire sur un bouton, un lien ou un champ, veut relire ou reformuler un message d'erreur ou un état vide, nomme un CTA, ou prépare les textes d'une maquette, même sans le mot « microcopie ». Ne pas utiliser pour les textes éditoriaux longs (articles, pages de contenu), le référencement ou le ton de marque global."
---

# Rédaction d'interface

**Préséance** : invariants de `lba-design:principles` (ne rien inventer, accessibilité des libellés et des messages) > demande > lexique et formulations validés (DESIGN.md §2) > charte éditoriale du client > principes de rédaction (ci-dessous) > défauts maison.

Charger `lba-design:principles` avant de commencer (typographie française §6).

Un texte d'interface dit à la personne ce qui se passe et ce qu'elle peut faire. Il est jugé en situation (écran, état, moment du parcours), jamais isolé.

## Avant d'écrire

Lire la fiche projet et le DESIGN.md s'ils existent (ton, tutoiement ou vouvoiement, lexique établi), puis la maquette si un lien Figma est fourni (place disponible, composant, état). Ne demander que ce qui manque et change le texte : écran et état, ce que la personne cherche à faire, contrainte de longueur. Le reste devient une hypothèse visible.

**Défauts maison**, remplacés par la fiche projet ou la charte éditoriale du client :

| Défaut | Raison |
|---|---|
| Vouvoiement | Registre attendu de la plupart des clients institutionnels ; le tutoiement est une décision de marque |
| Ton sobre et direct | L'interface informe et fait agir ; le ton de marque vit dans les contenus éditoriaux |
| Pas d'exclamation, sauf confirmation de réussite | Une exclamation partout ne signale plus rien |
| CTA de trois mots au plus avec les capitales condensées (`lba-design:ui-design`) | Au-delà, les capitales se lisent mal |

## Principes

1. **Clair** : le mot que la personne emploie, pas celui de l'organisation ni du back-office.
2. **Court** : le moins de mots possible sans perte de sens.
3. **Constant** : un même objet porte le même nom partout, et dans les termes des documents source fournis par le client (présentation, cahier des charges) plutôt que des synonymes. L'interface est dans la langue de ses utilisateurs finaux. Lire le lexique du DESIGN.md (§2.2) avant d'écrire ; y ajouter un terme dès qu'il est tranché.
4. **Utile** : chaque mot aide à agir ; supprimer les formules de politesse qui retardent l'information.
5. **Jamais inventé** : `lba-design:principles` §1 ; vaut aussi pour les délais et engagements promis dans un message.

## Modèles

**Boutons et CTA** : verbe à l'infinitif et objet (« Télécharger le rapport », « Créer un compte »). Jamais « Valider », « OK » ou « Envoyer » seuls quand l'objet n'est pas évident. Le libellé annonce le résultat réel du clic. Avec le parti pris agence des CTA en capitales condensées, viser trois mots au plus.

**Liens** : l'intitulé seul doit dire la destination ; bannir « Cliquez ici ». Un « En savoir plus » répété sur une page n'est acceptable que si le contexte le rend explicite (titre de carte associé), sinon compléter le libellé accessible. WCAG 2.4.4 / RGAA 6.1.

**Messages d'erreur** : ce qui s'est passé, puis comment corriger, sans accuser la personne. Placé près du champ, relié à lui, jamais signalé par la seule couleur. « Adresse e-mail incomplète : il manque le nom de domaine (par exemple nom@exemple.fr). » WCAG 3.3.1 et 3.3.3 / RGAA 11.10 et 11.11.

**Étiquettes et aides de formulaire** : étiquette visible et persistante, le placeholder n'en tient jamais lieu. Format attendu donné avant la saisie (« JJ/MM/AAAA »), champs obligatoires signalés par du texte. WCAG 3.3.2.

**États vides** : ce qu'on verra ici, pourquoi c'est vide, comment commencer. Distinguer « rien encore » de « aucun résultat pour ce filtre », qui propose de modifier ou d'effacer les filtres.

**Dialogues de confirmation** : la question nomme l'action et l'objet (« Supprimer ces 3 fichiers ? »), la conséquence est dite (« Cette action est définitive. »), les boutons reprennent l'action (« Supprimer » / « Conserver »), jamais « Oui » / « Non ».

**Chargement et messages de statut** : dire ce qui se passe quand l'attente dépasse une ou deux secondes. Un message de statut (résultat de recherche, ajout au panier) doit être restitué par les technologies d'assistance sans prendre le focus : le signaler au dev. WCAG 4.1.3 / RGAA 7.5.

**Infobulles** : réservées à l'information complémentaire ; jamais une information indispensable, jamais une répétition du libellé.

## Anti-défauts

Ils valent aussi pour les titres de section et les accroches posés dans une maquette en attendant les vrais textes. La charte éditoriale du client peut en décider autrement.

| Éviter | Faire à la place | Pourquoi |
|---|---|---|
| « Cliquez ici », « En savoir plus » répété sans contexte | Un intitulé qui dit la destination | WCAG 2.4.4 / RGAA 6.1 ; un lien se lit souvent seul |
| « Valider », « OK », « Envoyer » seuls | Verbe et objet : « Envoyer la demande » | Le libellé annonce le résultat du clic |
| « Oui » / « Non » dans un dialogue | Les boutons reprennent l'action : « Supprimer » / « Conserver » | On répond sans relire la question |
| Placeholder en guise d'étiquette | Étiquette visible et persistante | Elle disparaît à la saisie (WCAG 3.3.2) |
| « Une erreur est survenue » | Ce qui s'est passé et comment corriger | Une erreur sans issue bloque |
| Verbes et adjectifs creux : « Découvrez », « Plongez », « Libérez », « Boostez », « au cœur de », « incontournable », « sur mesure » ou « innovant » sans preuve, « solution » sans dire laquelle | Le verbe concret de l'action et l'objet réel | Formules interchangeables d'un site à l'autre |
| Superlatifs invérifiables : « le meilleur », « leader », « inégalé » | Une preuve sourcée, ou rien | Ne rien inventer (`principles` §1) |
| Cadence aphoristique : « Simple. Rapide. Efficace. », triades systématiques, « Pas X. Y. », « Plus qu'un X, un Y » | Une phrase qui dit quelque chose de précis ; une formule de marque au plus, si la charte la porte | Une fois, c'est un ton ; partout, un gabarit |
| Étiquettes poétiques sur des sections fonctionnelles : « Carnet de terrain », « Dans l'atelier » | Libellé fonctionnel (« Actualités », « Témoignages ») ou pas de libellé | L'usager cherche une rubrique, pas une énigme |
| Ponctuation de rythme : tiret cadratin à chaque phrase, points de suspension, exclamations | Phrases courtes et ponctuation ordinaire ; le tiret garde son usage typographique (incise) | Effet de style qui s'use vite |
| Faux contenus réalistes : noms, entreprises, chiffres « crédibles » | Contenu générique ou « À fournir » | Un faux crédible passe pour validé |

## Français

- Typographie (espaces insécables, guillemets, majuscules) : `lba-design:principles` §6. Piège fréquent : les majuscules à l'anglaise (« Nos Offres d'Emploi »).
- Dates en toutes lettres dans le texte courant (« 29 septembre 2026 »), format numérique réservé aux champs et tableaux.
- Écriture inclusive : la décision appartient au client (fiche projet). Quelle que soit la décision, privilégier les formulations épicènes (« les personnes inscrites ») ; le point médian est mal restitué par une partie des lecteurs d'écran, le signaler si le client le demande, sans trancher à sa place.
- Site bilingue : le libellé le plus long fixe la place à prévoir. Le français est souvent plus long que l'anglais, vérifier les deux dans le composant.

## Format de réponse

```markdown
## Textes : [écran, état]

**Recommandé** : [texte]

| Variante | Texte | Quand la préférer |
|---|---|---|
| A | | |
| B | | |

**Pourquoi** : [2 ou 3 lignes : situation de la personne, choix de vocabulaire]
**Hypothèses** : [ton, longueur, lexique supposés]
**Pour le dev** : [libellé accessible différent du texte visible, message de statut, liaison erreur-champ]
```

Pour une relecture, lister chaque texte avec : texte actuel, proposition, raison en une ligne. Ne pas réécrire ce qui fonctionne.

## Attribution

Adapté du skill `ux-copy` du dépôt `anthropics/knowledge-work-plugins` (licence Apache 2.0), traduit et étendu (règles françaises, correspondances RGAA, défauts LBA). Voir `NOTICE` à la racine du plugin.
