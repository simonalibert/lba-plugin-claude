---
name: feedback
description: "Retour d'usage du plugin lba-design en fin de session, pour l'améliorer : quels skills se sont chargés ou non, ce que la personne a dû corriger ou redemander, les consignes qu'elle redonne à chaque projet, ce qui a marché, le tout en un tableau anonymisé prêt à coller sur la page des retours de l'équipe. Déclencher sur « retour LBA », « retour plugin », « fais un retour d'usage du plugin », « bilan du plugin sur cette conversation », ou toute demande de faire le point sur l'usage du plugin avant de clore une session. Ne pas utiliser pour compiler les retours d'un client sur une maquette, ni pour un compte rendu de réunion."
---

# Retour d'usage du plugin

À la fin d'une session, ce skill produit un retour sur le plugin lui-même, pas sur le projet. Il sert à l'améliorer : chaque retour est collé sur la page partagée de l'équipe, où il est découpé en points, voté (« Moi aussi ») et trié.

Pour les niveaux de règle, lire `lba-design:principles` §10.

## Règles

1. **Se baser uniquement sur ce qui s'est passé dans cette conversation.** Ne rien supposer, ne rien reconstituer. Ce qui n'est plus visible est dit comme tel.
2. **Conversation résumée** : si une partie a été résumée automatiquement, le dire en tête et préciser que les chargements de skills de la partie résumée ne sont plus vérifiables. C'est en soi une information utile.
3. **Lecture partielle** : si un skill ou une référence n'a été lu qu'en partie, le dire (« principles lu jusqu'au §6 »). Un niveau déduit d'un intitulé est marqué « déduit ».
4. **Citer la demande** de la personne quand un déclenchement est en cause, telle qu'elle l'a formulée, sans contenu client.
5. **Anonymiser** : aucun nom de client, de projet ni de personne (« site e-commerce », « collectivité », « app terrain »…), aucune citation de contenu client, aucune donnée, aucun accès, aucun tarif.
6. **Séparer le plugin du projet** : une décision propre au projet est classée « décision projet » et va dans la fiche projet, pas dans le plugin.
7. **Être bref** : une ligne par point, pas de paraphrase de la conversation.

## Ce qu'il faut couvrir

1. **Skills chargés** : lesquels, à quel moment, sur quelle demande. Si aucun, lequel aurait été pertinent.
2. **Déclenchement** : un skill chargé à tort, ou un skill attendu qui ne s'est pas chargé.
3. **Corrections** : ce que la personne a dû corriger, préciser ou redemander. Pour chaque point : le skill avait-il une règle (non appliquée), une règle contraire, ou rien ?
4. **Habitudes** : une consigne donnée ici, et probablement redonnée à chaque projet.
5. **Classement** : pour chaque point de 3 et 4, un niveau selon `principles` §10 : invariant, standard LBA, défaut maison, ou décision projet. Les anciens noms (« principe », « convention LBA ») sont acceptés mais ne s'emploient plus.
6. **Ce qui a marché** : une ou deux règles qui ont visiblement amélioré le résultat.

## Format de sortie, et rien d'autre

Un seul tableau, avec exactement ces colonnes, dans cet ordre (la page des retours les lit par leur nom) :

```markdown
| Type | Skill | Ce qui s'est passé | Règle existante | Niveau proposé | Changement proposé |
|---|---|---|---|---|---|
| Déclenchement | ui-design | … | oui / non / contraire | standard LBA | … |
```

- **Type** : déclenchement, correction, habitude ou réussite (ajouter « (manqué) » pour un skill qui ne s'est pas chargé).
- **Skill** : nom court sans préfixe ; plusieurs séparés par une virgule ; « aucun » si rien ne couvre le point.
- **Règle existante** : oui, oui (non appliquée), non, ou contraire.

Avant le tableau, une ligne de contexte anonymisée (« Contexte : wireframes d'atelier pour une collectivité »). Après, une dernière ligne au format exact :

`Surface : claude.ai · JJ/MM/AAAA` (ou Cowork, ou Claude Code)

Puis une phrase : « Colle ce tableau sur la page des retours LBA Design (bouton « Déposer un retour ») : https://claude.ai/artifact/7yiKQLNNoPgPff1rR9znaM »
