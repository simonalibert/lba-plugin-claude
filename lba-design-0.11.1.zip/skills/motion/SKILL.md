---
name: motion
description: "Méthode La Bonne Agence pour les interactions et le motion design web avec GSAP (ScrollTrigger, SplitText, CustomEase) et Lenis : apparitions de texte ligne par ligne, sections épinglées au scroll, reveals de cartes, CTA, hovers, ouverture de menus, modales et infobulles, carrousels, bandeaux de texte défilants (marquee) et animations en boucle, compteurs, effets de vélocité, suivi souris, médias qui persistent entre sections. À utiliser dès qu'il faut animer, faire défiler ou bouger quelque chose sur une page, rendre « vivant », « soigner les interactions » ou « faire un effet whaou » sur un site ou un POC (React ou JS sans framework), même si GSAP n'est pas nommé, et pour corriger un bug d'animation (texte coupé, saut en fin d'anim, saccade, texte invisible, animation qui ignore la réduction des animations). Ne pas utiliser pour le motion vidéo, les animations dans Figma ou les prototypes Figma."
---

# Motion web : méthode La Bonne Agence

**Préséance** : invariants de `lba-design:principles` (mouvement réduit, aucun contenu invisible, bouton pause au-delà de 5 s) > demande > système motion du projet (`MOTION.md`, `src/lib/`) > charte motion du client > socle (standard) > repères et bannis (défauts maison).

Charger `lba-design:principles` avant de commencer. Objectif : un site qui donne la sensation d'un **objet bien fabriqué**, pas un site qui montre qu'il sait faire du GSAP. Moins d'animations, mieux exécutées ; en cas de doute, on retire. Un effet démonstratif (suivi souris, reflet, vélocité) n'entre que s'il valorise le produit, avec son propre interrupteur, et jamais pour compenser une hiérarchie faible.

Projets de référence : Opinel (`lba-demo`, sobriété validée client) et le POC « expertises » LBA : des exemples, pas des règles.

## Profil

`lba-design:principles` §11. **Standard** : repères ci-dessous. **Vitrine expressive** : repères allongés, effets bonus multipliés, séquences, boucles avec bouton pause. **Conformité RGAA** : sobre, pas d'effet bonus, aucun contenu révélé seulement au défilement sans repli. **Éco-conçu** : transitions CSS, GSAP et Lenis seulement si un effet le justifie. Le socle vaut pour tous les profils.

## Déroulé

1. **Lire l'existant.** Un `MOTION.md` ou un dossier `src/lib/` (intensity, ease, replayBus, lineReveal…) : on **étend ce système**, jamais un système parallèle. Sinon, copier le socle de `assets/`.
2. **Décider avant de coder.** Pour chaque animation : à quoi elle sert (guider la lecture, montrer l'état, valoriser le produit) ? « C'est joli » : proposer plus sobre ou s'en passer. Composant d'interface (menu, modale, infobulle, bouton) : `references/composants.md`.
3. **Construire sur le socle** et les recettes (`references/recipes.md`).
4. **Vérifier** avec la checklist, à 0 %, 100 % et 150 % d'intensité, puis en mouvement réduit (case de `MotionControls` ou réglage système), en desktop et mobile. Navigateur de test disponible : mesurer positions et opacités plutôt que se fier à une capture (un onglet masqué met le ticker GSAP en pause). Bug signalé : `references/pitfalls.md` d'abord.
5. **Livrer** en disant ce qui n'a pas été vu tourner.

## Le socle (standard LBA, tous profils)

- **Intensité** `getIntensity()` : multiplicateur 0–1,5 piloté par le slider « Animations » (pas de 5 %), 1 par défaut, lu **au démarrage** de chaque animation (pas via un state React). Distances, stagger et flou passent par `getMoveFactor()` (l'intensité, ou 0 en mouvement réduit) ; durées par `scaledDuration(base, plancher)`. À 0 (`isStatic()`), rien ne s'anime : états finaux posés instantanément, tout reste lisible.
- **Mouvement réduit** `isReducedMotion()` : suit `prefers-reduced-motion` (forçable en démo par `setReducedMotion()`). Coupés : translations, échelle, rotation, flou, parallaxe, inclinaison, défilement fluide, défilement automatique. Les entrées deviennent des **fondus d'opacité courts** (`REDUCED_FADE`, 0,25 s, sans découpage en lignes ni stagger). Opacité et couleur ne sont pas du mouvement au sens du WCAG (Understanding 2.3.3) ; le flou l'est, depuis un erratum. Comportement de chaque recette : `references/a11y-perf.md`.
- **Easing** `getEase()` = « gsvOut », `cubic-bezier(0.16,1,0.3,1)` ; `power2.out` et `power3.out` tolérés pour de simples fondus.
- **Replay** `onReplay()` : toute animation d'entrée s'y abonne (bouton ↺).
- **Safety nets** : aucun texte ni CTA ne peut rester invisible (timer ~2 s qui force `progress(1)`).
- **Lenis** branché sur le ticker GSAP (qui cadence ScrollTrigger), désactivable, coupé en mouvement réduit.
- **Rendu serveur** (Next.js) : `window` lu à l'exécution, jamais à l'import ; côté serveur, états finaux. `MotionControls` côté client uniquement.
- **Bibliothèques** : GSAP (gratuit, y compris SplitText et CustomEase, mais sous licence propriétaire) et Lenis (MIT). GSAP est retenu comme standard du secteur, sans équivalent open source aussi complet pour SplitText et ScrollTrigger : justification à reprendre telle quelle en revue technique.

## Défauts maison

| Usage | Durée | Distance | Raison |
|---|---|---|---|
| Retour d'appui (`:active`) | 100–160 ms | `scale(0.97)`, sans déplacement | L'interface confirme le geste sans le retarder |
| Micro-interaction (survol, focus) | 150–250 ms | 2–4 px | Répétée souvent : à peine perceptible |
| Interaction standard (carte, bouton, menu) | 250–500 ms | 8–14 px | Assez pour suivre le changement d'état, pas assez pour attendre |
| Apparition de section, ligne de texte | 600–1100 ms selon intensité | 100 % de la ligne sous masque, 20–24 px pour un bloc | Une fois par section : peut porter du caractère |
| Stagger | 0,06–0,12 s × intensité | sans objet | Au-delà, la fin de la liste arrive trop tard |

N'animer que `transform` et `opacity` (le reste déclenche mise en page et peinture). Exceptions à justifier : `filter: blur()` léger à l'apparition (peu d'éléments, retiré en fin d'animation, coupé en mouvement réduit), variables CSS pour piloter un pseudo-élément. Pas de rebond ni de dépassement, sauf exception assumée.

## Anti-défauts

Décidés avec des clients ; à rediscuter seulement sur demande.

| Éviter | Faire à la place | Pourquoi |
|---|---|---|
| Curseur personnalisé | Le curseur système, éventuellement un état de survol sur l'élément | Accessibilité, performance, rarement lié au produit |
| Survol de bouton « soulèvement + ombre + luminosité » | Changement de `background-color` ou de `color`, flèche qui avance de 0,2 em | Trois effets pour un seul signal |
| Reflet ou dégradé animé sur les CTA | Un CTA franc, contrasté, sans effet | L'effet attire l'œil sans dire quoi faire |
| Liens « En savoir plus » décoratifs vers nulle part | Lien réel, ou pas de lien ; signaler tout `href` factice | Un lien mort est un bug, pas un décor |
| Texte en colonnes CSS | Une colonne de mesure correcte | Lecture en zigzag, coupures imprévisibles en responsive |
| Distance ou flou qui n'utilise pas `getMoveFactor()` | Passer par le socle | L'animation ignorerait le mouvement réduit et le slider |
| Effet bonus actif en mouvement réduit | Interrupteur propre, toujours coupé en mouvement réduit | Invariant |
| Animer une action déclenchée au clavier | Rien, ou un changement d'état instantané | Répétée, elle paraît lente et décollée du geste |

## Checklist avant de livrer

1. Lit `getIntensity()` au démarrage et, si c'est une entrée, s'abonne à `onReplay` ?
2. N'anime que `transform` et `opacity`, ou une exception justifiée ?
3. Correcte à 0 % (rien d'invisible, rien de figé à mi-course) et en mouvement réduit (un fondu au plus, aucun déplacement ni flou) ?
4. Safety net si elle masque du contenu ?
5. Ne casse ni le clavier, ni les lecteurs d'écran, ni le zoom (`references/a11y-perf.md`) ?
6. Sert le produit, ou fait juste joli ?
7. Composant d'interface : fréquence d'usage qui la justifie, origine au déclencheur, ni `ease-in` ni `scale(0)` ?
8. Ce qui bouge plus de 5 secondes a un bouton pause ?

## Livrer

En quelques lignes : ce qui bouge et pourquoi, ce qui a été vérifié et comment, ce qui n'a pas pu être vu en mouvement, les écarts assumés, et les points à traiter avant mise en ligne (`href` factices, licences de police, contrastes des textes atténués calculés selon `lba-design:principles` §4). Spec d'écran existante (`lba-design:handoff`) : sa colonne « Mouvement » reprend ces repères. `MOTION.md` du projet : le mettre à jour quand on ajoute une brique.

## Selon l'environnement

Projet local avec GSAP et Lenis (copie de `assets/`) ; navigateur de test facultatif. Sans navigateur : livrer en disant que le mouvement n'a pas été vu (`EXECUTION.md`).

## Références

- `references/composants.md` : avant d'animer un menu, une modale, une infobulle, un bouton.
- `references/recipes.md` : texte ligne par ligne, CTA après le texte, grille de cartes, section épinglée, média persistant, reflet et ombre, suivi souris, odomètre, vélocité, survol de carte produit, flou.
- `references/pitfalls.md` : **dès qu'un bug d'animation est signalé**.
- `references/a11y-perf.md` : mouvement réduit recette par recette, clavier, ARIA, contrastes atténués, coût du flou, éco-conception.
- `assets/core/` : socle TypeScript sans framework (`intensity.ts`, `ease.ts`, `replayBus.ts`, `smoothScroll.ts`, `lineReveal.ts`, `batchReveal.ts`, `odometerRoll.ts`, `velocity.ts`, `motion.css`) ; `assets/react/` : `useLineReveal.ts`, `useBatchReveal.ts`, `MotionControls.tsx`. Copier ce qui sert dans le projet (ex. `src/lib/`), adapter imports et conventions, ne pas réécrire ce qui existe déjà.
