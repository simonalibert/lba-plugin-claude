import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Lenis from "lenis";
import { isReducedMotion } from "./intensity";

gsap.registerPlugin(ScrollTrigger);

let lenis: Lenis | null = null;
const raf = (time: number): void => lenis?.raf(time * 1000);

/** Lenis driven by the GSAP ticker, which also drives ScrollTrigger. */
export const enableSmoothScroll = (): void => {
  if (lenis || isReducedMotion()) return;
  lenis = new Lenis();
  lenis.on("scroll", ScrollTrigger.update);
  gsap.ticker.add(raf);
  gsap.ticker.lagSmoothing(0);
};

export const disableSmoothScroll = (): void => {
  if (!lenis) return;
  gsap.ticker.remove(raf);
  lenis.destroy();
  lenis = null;
};

export const isSmoothScrollEnabled = (): boolean => lenis !== null;

export const scrollToY = (y: number): void => {
  if (lenis) lenis.scrollTo(y);
  else window.scrollTo({ top: y });
};
