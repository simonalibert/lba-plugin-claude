import { gsap } from "gsap";
import { SplitText } from "gsap/SplitText";
import { getEase } from "./ease";
import { REDUCED_FADE, getIntensity, getMoveFactor } from "./intensity";

gsap.registerPlugin(SplitText);

const SAFETY_MS = 2200;

type Options = {
  delay?: number;
  stagger?: number;
  /** Start blur in px (scaled by intensity); 0 = none. */
  blur?: number;
  /** Called once the reveal has fully played (or was skipped at intensity 0). Not called on cancel. */
  onDone?: () => void;
};

/**
 * Masked line-by-line reveal of `container` (opacity) and its `targets` (lines).
 * Split is reverted once done so screen readers and selection get a clean DOM.
 * Call `document.fonts.ready` before the first use. Returns a cancel function that shows the
 * text immediately and does NOT call `onDone` (a cancelled reveal must not start what follows it).
 */
export const lineReveal = (
  container: HTMLElement,
  targets: HTMLElement[],
  { delay = 0, stagger = 0.08, blur = 0, onDone }: Options = {},
): (() => void) => {
  const k = getIntensity();
  gsap.killTweensOf(container);
  if (k === 0) {
    gsap.set(container, { opacity: 1 });
    onDone?.();
    return () => {};
  }
  if (getMoveFactor() === 0) {
    // Reduced motion: no split, no rise, no blur; the whole block fades in.
    const fade = gsap.fromTo(container, { opacity: 0 }, { opacity: 1, duration: REDUCED_FADE, ease: "none", onComplete: () => onDone?.() });
    return () => {
      fade.kill();
      gsap.set(container, { opacity: 1 });
    };
  }

  const split = SplitText.create(targets, { type: "lines", mask: "lines", linesClass: "line" });
  const blurFrom = blur > 0 ? { filter: `blur(${blur * k}px)` } : {};
  let safety = 0;
  const finish = (): void => {
    window.clearTimeout(safety);
    split.revert();
    gsap.set(targets, { clearProps: "filter" });
    onDone?.();
  };
  const tl = gsap.timeline({ delay: delay * k, onComplete: finish });
  // 130 %, not 100 %: .line-mask is extended 0.3em downwards (motion.css), so at 100 % the
  // top of the glyphs would already peek into the mask at the start.
  tl.set(container, { opacity: 1 }).from(split.lines, {
    yPercent: 130,
    opacity: 0,
    ...blurFrom,
    duration: Math.max(0.3, 0.8 * k),
    stagger: stagger * k,
    ease: getEase(),
  });
  // Never leave text invisible, whatever happens to the timeline.
  safety = window.setTimeout(() => tl.progress(1), SAFETY_MS + delay * k * 1000);

  return () => {
    window.clearTimeout(safety);
    tl.kill();
    split.revert();
    gsap.set(targets, { clearProps: "filter" });
    gsap.set(container, { opacity: 1 });
  };
};
