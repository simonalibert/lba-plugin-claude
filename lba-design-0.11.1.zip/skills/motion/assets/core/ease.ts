import { gsap } from "gsap";
import { CustomEase } from "gsap/CustomEase";

gsap.registerPlugin(CustomEase);

// cubic-bezier(0.16, 1, 0.3, 1)
CustomEase.create("gsvOut", "M0,0 C0.16,1 0.3,1 1,1");

export const getEase = (): string => "gsvOut";
