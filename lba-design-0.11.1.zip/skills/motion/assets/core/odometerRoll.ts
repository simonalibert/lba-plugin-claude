import { gsap } from "gsap";
import { getMoveFactor } from "./intensity";

/**
 * Airport-board style digit roll: each character position gets its own
 * fixed-height "reel" (overflow hidden), and when its digit changes, the old
 * digit slides up and out while the new one slides up into place — one
 * continuous motion instead of the previous approach (a tweened numeric
 * proxy whose intermediate values were rounded into `textContent`), which
 * reads as a single abrupt jump-cut since a whole-number counter like this
 * only ever lands on one new integer per tick, not a range of steps to
 * visibly count through.
 *
 * Unchanged digits, and any newly-added leading digit (e.g. "9" → "10"),
 * are set directly with no roll — there's no "old" digit in that position
 * for them to roll from.
 */
export function rollOdometerTo(el: HTMLElement, newText: string, duration: number, ease = 'power2.out') {
  const oldText = el.dataset.value ?? '';
  el.dataset.value = newText;
  if (oldText === newText) return;
  if (getMoveFactor() === 0) {
    // Static or reduced motion: the digits roll vertically, so swap the text instead.
    el.textContent = newText;
    return;
  }

  const len = Math.max(oldText.length, newText.length);
  const oldChars = oldText.padStart(len, '\u0000').split('');
  const newChars = newText.padStart(len, '\u0000').split('');

  el.textContent = '';
  const reels: HTMLElement[] = [];
  for (let i = 0; i < len; i++) {
    const o = oldChars[i] === '\u0000' ? '' : (oldChars[i] ?? '');
    const n = newChars[i] === '\u0000' ? '' : (newChars[i] ?? '');
    const slot = document.createElement('span');
    slot.style.cssText = 'display:inline-block;overflow:hidden;height:1em;vertical-align:top;';
    const reel = document.createElement('span');
    reel.style.cssText = 'display:block;';
    if (!o || o === n) {
      reel.textContent = n;
    } else {
      const oldRow = document.createElement('span');
      oldRow.style.cssText = 'display:block;height:1em;';
      oldRow.textContent = o;
      const newRow = document.createElement('span');
      newRow.style.cssText = 'display:block;height:1em;';
      newRow.textContent = n;
      reel.append(oldRow, newRow);
      reels.push(reel);
    }
    slot.appendChild(reel);
    el.appendChild(slot);
  }

  if (reels.length) {
    gsap.fromTo(reels, { y: 0 }, {
      y: '-1em',
      duration,
      ease,
      onComplete: () => {
        reels.forEach((reel) => {
          const digit = reel.lastElementChild?.textContent ?? '';
          reel.style.transform = '';
          reel.textContent = digit;
        });
      },
    });
  }
}
