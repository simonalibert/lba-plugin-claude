import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { isReducedMotion } from "./intensity";

gsap.registerPlugin(ScrollTrigger);

// Scroll-velocity skew. Bonus effect with its own toggle: deliberately
// independent of intensity, but off when the OS asks for reduced motion.
const MAX_SKEW = 0.5; // deg
const VELOCITY_PER_DEG = 1500; // px/s

const targets = new Set<HTMLElement>();
const clamp = gsap.utils.clamp(-MAX_SKEW, MAX_SKEW);
const proxy = { skew: 0 };
let enabled = true; // user toggle; the OS preference is checked live below (SSR-safe)
let trigger: ScrollTrigger | null = null;

const apply = (): void => {
  targets.forEach((el) => gsap.set(el, { skewY: proxy.skew }));
};

const ensureTrigger = (): void => {
  if (trigger) return;
  trigger = ScrollTrigger.create({
    onUpdate: (self) => {
      if (!enabled || isReducedMotion()) return;
      const skew = clamp(self.getVelocity() / -VELOCITY_PER_DEG);
      if (Math.abs(skew) <= Math.abs(proxy.skew)) return;
      proxy.skew = skew;
      gsap.to(proxy, { skew: 0, duration: 0.8, ease: "power3.out", overwrite: true, onUpdate: apply });
    },
  });
};

export const registerVelocityTarget = (el: HTMLElement): (() => void) => {
  targets.add(el);
  ensureTrigger();
  return () => {
    targets.delete(el);
    gsap.set(el, { clearProps: "transform" });
  };
};

export const isVelocityEnabled = (): boolean => enabled && !isReducedMotion();

export const setVelocityEnabled = (value: boolean): void => {
  enabled = value;
  if (!value) {
    gsap.killTweensOf(proxy);
    proxy.skew = 0;
    apply();
  }
};
