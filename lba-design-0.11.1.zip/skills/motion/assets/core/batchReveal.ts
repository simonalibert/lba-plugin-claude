import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { REDUCED_FADE, getIntensity, getMoveFactor } from "./intensity";
import { onReplay } from "./replayBus";

gsap.registerPlugin(ScrollTrigger);

type Options = { startY?: number; duration?: number; stagger?: number; start?: string };

/** Fade + rise of every element matching `selector`, in batches, as they scroll into view. Returns a cleanup. */
export const batchReveal = (selector: string, opts: Options = {}): (() => void) => {
  const { startY = 20, duration = 0.6, stagger = 0.08, start = "top 85%" } = opts;
  let triggers: ScrollTrigger[] = [];

  const setup = (): void => {
    triggers.forEach((t) => t.kill());
    const els = gsap.utils.toArray<Element>(selector);
    if (!els.length) return void (triggers = []);
    gsap.set(els, { opacity: getIntensity() === 0 ? 1 : 0 });
    triggers = ScrollTrigger.batch(els, {
      start,
      onEnter: (batch) => {
        const k = getIntensity();
        if (k === 0) return void gsap.set(batch, { opacity: 1 });
        const m = getMoveFactor(); // 0 under reduced motion: fade only, all at once
        gsap.fromTo(
          batch,
          { opacity: 0, y: startY * m },
          { opacity: 1, y: 0, duration: m === 0 ? REDUCED_FADE : duration, stagger: stagger * m, ease: "power2.out", overwrite: true, clearProps: "transform" },
        );
      },
      onLeaveBack: (batch) => gsap.set(batch, { opacity: getIntensity() === 0 ? 1 : 0 }),
    });
  };

  setup();
  const offReplay = onReplay(setup);
  return () => {
    offReplay();
    triggers.forEach((t) => t.kill());
  };
};
