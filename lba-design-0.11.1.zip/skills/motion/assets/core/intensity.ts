// Global motion settings, read at animation start, never cached.
//
// Two independent axes:
// - intensity (0–1.5): demo multiplier driven by the "Animations" slider. 0 = nothing animates,
//   final states are set instantly.
// - reduced motion: follows `prefers-reduced-motion` (or a demo override). Movement is removed
//   (distances, blur, skew, parallax, smooth scroll) but short opacity fades remain, which
//   WCAG does not count as motion animation (Understanding 2.3.3; blur is no longer excluded).
type Listener = (value: number) => void;

const QUERY = "(prefers-reduced-motion: reduce)";
const isBrowser = (): boolean => typeof window !== "undefined" && typeof window.matchMedia === "function";

/** Fade duration used for every entrance when reduced motion is on (seconds). */
export const REDUCED_FADE = 0.25;

/** SSR-safe: false on the server, live value in the browser. */
export const prefersReducedMotion = (): boolean => isBrowser() && window.matchMedia(QUERY).matches;

let intensity: number | null = null; // resolved on first browser read, not at import (SSR)
let reducedOverride: boolean | null = null; // null = follow the system preference
const listeners = new Set<Listener>();

const notify = (): void => listeners.forEach((fn) => fn(getIntensity()));

let watching = false;
const watchSystemPreference = (): void => {
  if (watching || !isBrowser()) return;
  watching = true;
  // Follow the OS setting if it changes during the session.
  window.matchMedia(QUERY).addEventListener("change", notify);
};

export const getIntensity = (): number => {
  if (intensity === null) {
    if (!isBrowser()) return 0; // server render: final states, no motion
    intensity = 1;
    watchSystemPreference();
  }
  return intensity;
};

export const setIntensity = (value: number): void => {
  watchSystemPreference();
  intensity = Math.min(1.5, Math.max(0, value));
  notify();
};

/** Reduced motion: system preference unless a demo override is set. */
export const isReducedMotion = (): boolean => reducedOverride ?? prefersReducedMotion();

/** Demo override: true / false forces the mode, null follows the system again. */
export const setReducedMotion = (value: boolean | null): void => {
  watchSystemPreference();
  reducedOverride = value;
  notify();
};

/** Nothing animates at all: set final states instantly. */
export const isStatic = (): boolean => getIntensity() === 0;

/**
 * Multiplier for everything that moves or blurs: distances, stagger, blur, skew, tilt.
 * 0 under reduced motion, the intensity otherwise.
 */
export const getMoveFactor = (): number => (isReducedMotion() ? 0 : getIntensity());

export const onIntensityChange = (fn: Listener): (() => void) => {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
};

/**
 * Duration scaled by intensity, with a floor so motion never feels abrupt.
 * Static: 0. Reduced motion: a short fade (REDUCED_FADE), whatever the base.
 */
export const scaledDuration = (base: number, floor = 0.3): number => {
  const k = getIntensity();
  if (k === 0) return 0;
  if (isReducedMotion()) return REDUCED_FADE;
  return Math.max(floor, base * k);
};
