// Pixel alignment helpers: align two texts on their cap height, not on their boxes.
// Requires a `.baseline-probe` (zero-size inline-block) at the start of the element's first line.

const ctx = typeof document !== "undefined" ? document.createElement("canvas").getContext("2d") : null;

/** Viewport Y of the cap-height top of `el`'s first line. */
export const capTop = (el: HTMLElement): number => {
  const probe = el.querySelector<HTMLElement>(".baseline-probe");
  if (!probe || !ctx) return el.getBoundingClientRect().top;
  const cs = getComputedStyle(el);
  ctx.font = `${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
  return probe.getBoundingClientRect().bottom - ctx.measureText("H").actualBoundingBoxAscent;
};

/** Resolves once the element's webfont is really loaded (fonts.ready alone can resolve too early). */
export const fontsReadyFor = async (el: HTMLElement): Promise<void> => {
  const cs = getComputedStyle(el);
  await document.fonts.load(`${cs.fontWeight} 1em ${cs.fontFamily}`);
  await document.fonts.ready;
};
