import { ScrollTrigger } from "gsap/ScrollTrigger";

// Pub/sub for the "Rejouer l'animation" button: each section replays its own entrance,
// no global orchestrator owning every GSAP instance.
type Listener = () => void;

const listeners = new Set<Listener>();

export const onReplay = (fn: Listener): (() => void) => {
  listeners.add(fn);
  return () => listeners.delete(fn);
};

/** `scrollToTop`: for scroll-triggered pages, restart from the top so every reveal plays again. */
export const replayAll = ({ scrollToTop = false } = {}): void => {
  if (scrollToTop) window.scrollTo({ top: 0, behavior: "auto" });
  requestAnimationFrame(() => {
    listeners.forEach((fn) => fn());
    ScrollTrigger.refresh();
  });
};
