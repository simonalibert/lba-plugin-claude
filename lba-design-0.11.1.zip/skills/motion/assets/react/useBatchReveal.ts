import { useEffect, useRef } from "react";
import { batchReveal } from "../core/batchReveal";

type Options = Parameters<typeof batchReveal>[1];

/** Card grids: fade + rise in batches as they scroll into view (see core/batchReveal). */
export function useBatchReveal(selector: string, opts?: Options) {
  // Options read at setup, like the rest of the motion system; changing them doesn't rebuild.
  const optsRef = useRef(opts);
  useEffect(() => batchReveal(selector, optsRef.current), [selector]);
}
