import { useEffect, type RefObject } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { fontsReadyFor } from "../core/align";
import { getEase } from "../core/ease";
import { getIntensity, getMoveFactor, scaledDuration } from "../core/intensity";
import { lineReveal } from "../core/lineReveal";
import { onReplay } from "../core/replayBus";

gsap.registerPlugin(ScrollTrigger);

type Options = {
  /** ScrollTrigger start. */
  start?: string;
  delay?: number;
  stagger?: number;
  /** Optional CTA: hidden during the text reveal, rises in once the last line has landed. */
  ctaRef?: RefObject<HTMLElement | null>;
};

/**
 * Scroll-triggered line reveal of `ref` (a heading, or a container of <p>/<li>).
 * Replays each time the block scrolls back into view, and on replayAll().
 * Add the `reveal-lines` class (motion.css) on the split targets.
 */
export function useLineReveal(ref: RefObject<HTMLElement | null>, { start = "top 85%", delay = 0, stagger, ctaRef }: Options = {}) {
  useEffect(() => {
    const root = ref.current;
    const cta = ctaRef?.current ?? null;
    if (!root) return;
    const targets = (): HTMLElement[] => {
      const children = Array.from(root.querySelectorAll<HTMLElement>("p, li"));
      return children.length ? children : [root];
    };

    let cancel: () => void = () => {};
    let ctaTween: gsap.core.Tween | null = null;
    let ctaSafety = 0;
    let st: ScrollTrigger | null = null;
    let disposed = false;

    const hide = (): void => {
      cancel();
      ctaTween?.kill();
      window.clearTimeout(ctaSafety);
      const els = cta ? [root, cta] : [root];
      gsap.set(els, { opacity: getIntensity() === 0 ? 1 : 0 });
    };

    const reveal = (): void => {
      const k = getIntensity();
      cancel = lineReveal(root, targets(), {
        delay,
        stagger,
        onDone: () => {
          if (disposed || !cta) return;
          if (k === 0) return void gsap.set(cta, { opacity: 1 });
          const m = getMoveFactor(); // 0 under reduced motion: the CTA fades in without rising
          ctaTween = gsap.fromTo(
            cta,
            { opacity: 0, y: 12 * m },
            { opacity: 1, y: 0, duration: scaledDuration(0.5), delay: 0.15 * m, ease: getEase(), clearProps: "transform" },
          );
          ctaSafety = window.setTimeout(() => ctaTween?.progress(1), 2000);
        },
      });
    };

    // Keyboard: focus landing in the block (or on its CTA) before the reveal shows everything
    // at once, so nothing focusable is ever invisible.
    const showNow = (): void => {
      cancel();
      ctaTween?.progress(1);
      gsap.set(cta ? [root, cta] : [root], { opacity: 1 });
    };
    root.addEventListener("focusin", showNow);
    cta?.addEventListener("focus", showNow);

    hide();
    void fontsReadyFor(root).then(() => {
      if (disposed) return;
      st = ScrollTrigger.create({ trigger: root, start, onEnter: reveal, onLeaveBack: hide });
    });
    const offReplay = onReplay(() => {
      hide();
      if (st?.isActive || (st && st.progress > 0)) reveal();
    });

    return () => {
      disposed = true;
      root.removeEventListener("focusin", showNow);
      cta?.removeEventListener("focus", showNow);
      offReplay();
      st?.kill();
      cancel();
      ctaTween?.kill();
      window.clearTimeout(ctaSafety);
      gsap.set(cta ? [root, cta] : [root], { clearProps: "opacity,transform" });
    };
    // Options are read once at mount, like the rest of the motion system.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}
