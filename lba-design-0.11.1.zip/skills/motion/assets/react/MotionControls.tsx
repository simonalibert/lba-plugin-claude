// Demo control (slider, replay, toggles). Client-only: in Next.js, render it with
// "use client" and dynamic(..., { ssr: false }), the server has no motion preference.
import { useId, useState } from "react";
import { getIntensity, isReducedMotion, setIntensity, setReducedMotion } from "../core/intensity";
import { replayAll } from "../core/replayBus";
import { isVelocityEnabled, setVelocityEnabled } from "../core/velocity";
import { disableSmoothScroll, enableSmoothScroll, isSmoothScrollEnabled } from "../core/smoothScroll";

export function MotionControls() {
  const id = useId();
  const [value, setValue] = useState(() => Math.round(getIntensity() * 100));
  const [smooth, setSmooth] = useState(isSmoothScrollEnabled);
  const [velocity, setVelocity] = useState(isVelocityEnabled);
  const [reduced, setReduced] = useState(isReducedMotion);

  return (
    <aside className="motion" aria-label="Réglages des animations">
      <label htmlFor={`${id}-range`}>Animations</label>
      <input
        id={`${id}-range`}
        type="range"
        min={0}
        max={150}
        step={5}
        value={value}
        aria-valuetext={`${value} %`}
        onChange={(e) => {
          const v = Number(e.target.value);
          setValue(v);
          setIntensity(v / 100);
        }}
      />
      <output htmlFor={`${id}-range`}>{value} %</output>
      <button type="button" onClick={() => replayAll()} aria-label="Rejouer l'animation" title="Rejouer l'animation">
        ↺
      </button>
      <label className="motion-toggle">
        <input
          type="checkbox"
          checked={reduced}
          onChange={(e) => {
            // Demo override of prefers-reduced-motion: fades only, no movement.
            setReducedMotion(e.target.checked);
            if (e.target.checked) disableSmoothScroll();
            setReduced(isReducedMotion());
            setSmooth(isSmoothScrollEnabled());
            setVelocity(isVelocityEnabled());
            replayAll();
          }}
        />
        Mouvement réduit
      </label>
      <label className="motion-toggle">
        <input
          type="checkbox"
          checked={smooth}
          disabled={reduced}
          onChange={(e) => {
            if (e.target.checked) enableSmoothScroll();
            else disableSmoothScroll();
            setSmooth(isSmoothScrollEnabled());
          }}
        />
        Défilement fluide
      </label>
      <label className="motion-toggle">
        <input
          type="checkbox"
          checked={velocity}
          onChange={(e) => {
            setVelocityEnabled(e.target.checked);
            setVelocity(isVelocityEnabled());
          }}
        />
        Effet vélocité
      </label>
    </aside>
  );
}
