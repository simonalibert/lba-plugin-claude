# Composants d'interface : menus, modales, infobulles, boutons

Les recettes (`recipes.md`) visent surtout le défilement d'un site ; les composants qu'on ouvre et ferme à la demande obéissent à d'autres règles. Défauts maison, sauf la règle sur le mouvement réduit qui suit l'invariant (`lba-design:principles` §4).

**Faut-il animer ?** Décider selon la fréquence à laquelle la personne verra l'animation :

| Fréquence | Décision |
|---|---|
| Des dizaines de fois par session (survol de liste, navigation au clavier, raccourcis, ouverture d'une recherche) | Pas d'animation, ou presque rien |
| Occasionnelle (menu, modale, tiroir, notification) | Animation standard, courte |
| Rare ou première fois (accueil, confirmation de réussite) | Peut porter plus de caractère |

Une action déclenchée au clavier n'est jamais animée : répétée, elle paraît lente et décollée du geste.

**Courbe** : entrée ou sortie en décélération (`gsvOut` ou équivalent) ; déplacement d'un élément déjà à l'écran en accélération-décélération ; changement de couleur au survol en `ease` ; mouvement continu (barre de progression) en `linear`. Jamais d'accélération seule (`ease-in`) sur une interface : elle retarde le mouvement au moment exact où l'œil l'attend, et 200 ms en `ease-in` paraissent plus lentes que 200 ms en `ease-out`.

**Durées** : retour d'appui 100–160 ms, infobulle 125–200 ms, menu déroulant 150–250 ms, modale ou tiroir 200–500 ms (cohérent avec les repères du `SKILL.md`). La réponse du système est rapide ; ce qui demande une décision (maintenir pour supprimer) peut être lent.

**Physique** :
- Jamais d'apparition depuis `scale(0)` : partir de `scale(0.95)` avec `opacity: 0`.
- Un menu ou une infobulle s'ouvre depuis son déclencheur (`transform-origin` du côté du bouton), pas depuis son centre. Exception : la modale, centrée dans la fenêtre, garde l'origine au centre.
- Élément pressable : `scale(0.97)` à `:active` (0,95 à 0,98), transition de 160 ms.
- Ce qui peut être relancé vite (notifications qui s'empilent, bascules) passe par des transitions CSS, interrompables et réorientables en cours de route ; une `@keyframes` repart de zéro. `@starting-style` anime l'entrée sans JavaScript là où les navigateurs cibles le prennent en charge.
- Les effets de survol qui bougent sont réservés à `@media (hover: hover) and (pointer: fine)` : sur écran tactile, le tap déclenche un faux survol qui reste collé.

**Mettre au point** : ralentir l'animation (durée × 3 à 5, ou panneau Animations des outils de développement) pour voir les décalages entre propriétés, et la revoir le lendemain avant de la livrer.

**Mouvement réduit** : il ne reste qu'un fondu d'opacité court, sans échelle ni déplacement ni flou ; les distances passent par `getMoveFactor()`.

Adapté des principes d'Emil Kowalski (`emil-design-eng`, `review-animations`, licence MIT), voir `NOTICE`.
