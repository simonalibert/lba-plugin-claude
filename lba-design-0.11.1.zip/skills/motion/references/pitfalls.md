# Pièges connus

Bugs rencontrés en production de POC (Opinel, expertises LBA), avec cause et correctif. Quand un bug d'animation est signalé, chercher ici d'abord.

## Sommaire

1. Le bas des lettres est coupé pendant l'apparition, puis réapparaît d'un coup
2. Une ligne (souvent la dernière) se recale sèchement en fin d'animation
3. Alignement ou découpage faux au premier chargement
4. Mesures faussées pendant une animation de texte
5. Rien ne bouge / texte ou CTA invisible (onglet masqué, ticker en pause)
6. Styles inline effacés (React StrictMode)
7. Image qui « pop » sans animation (lazy-loading)
8. Puces / tirets visibles avant leur ligne
9. Transform GSAP qui écrase un hover CSS
10. Focus programmatique sans événement (tests)

---

## 1. Jambages coupés pendant l'apparition

**Symptôme** : pendant l'anim (et jusqu'à ~0,5 s après), le bas des « g, p, q » est tronqué, puis apparaît d'un coup.

**Cause** : SplitText `mask: "lines"` enveloppe chaque ligne dans un `div.line-mask` en `overflow: clip`, de la hauteur exacte de la ligne. Avec un interligne serré (≤ 1,2), les jambages dépassent la boîte. Le masque disparaît au `revert()`, à la fin de toute la timeline : le bas des lettres revient d'un coup.

**Correctif** : étendre la zone de clip vers le **bas uniquement**, sans changer la mise en page, et isoler les cibles du split dans leur propre contexte de formatage :

```css
.line-mask { padding-bottom: 0.3em; margin-bottom: -0.3em; }
.titre-anime, .paragraphe-anime, .liste-animee li { display: flow-root; }
```

La classe du masque est celle des lignes + `-mask` (`linesClass: "line"` → `.line-mask`).

Le masque étant plus haut que la ligne, faire partir les lignes de `yPercent: 130` (et non 100), sinon le haut des lettres dépasse dans la zone ajoutée dès le départ.

## 2. Ligne qui se recale en fin d'anim

**Symptôme** : à la fin, la dernière ligne (ou toutes celles après la première) remonte de quelques px.

**Causes et correctifs** :
- Extension du masque **en haut et en bas** : entre deux masques voisins, `margin-bottom` négatif et `margin-top` négatif **fusionnent** (on garde le plus négatif au lieu de les additionner) → chaque ligne descend d'autant. N'étendre que vers le bas.
- Cible du split sans `display: flow-root` : la marge négative du premier/dernier masque fusionne avec le parent → le titre entier se décale pendant le split (mesuré : 5 px à 33 px de corps).
- Police changée entre découpage et revert (voir §3).

**Vérifier** : mesurer `getBoundingClientRect()` des titres et des lignes avant le split et pendant (lignes avec `transform` neutralisé), écart attendu : 0.

## 3. Alignement ou découpage faux au premier chargement

**Cause** : `document.fonts.ready` peut se résoudre **avant même que la webfont ait commencé à charger** (rien ne l'a encore demandée). On découpe ou mesure alors avec la police de secours ; la vraie police arrive ensuite et décale tout (constaté : 50 px d'écart d'alignement).

**Correctif** :

```ts
const family = getComputedStyle(el).fontFamily;
await document.fonts.load(`600 1em ${family}`); // force le chargement de la graisse utilisée
await document.fonts.ready;
```

Et observer la taille des textes (`ResizeObserver`) pour remesurer en cas de swap tardif ou de zoom.

## 4. Mesures faussées pendant une animation de texte

**Cause** : pendant un reveal, les lignes sont transformées (`yPercent: 100`). Toute mesure basée sur `getBoundingClientRect()` d'un élément à l'intérieur (sonde de ligne de base, hauteur de titre) est fausse. Un `ScrollTrigger.refresh` (événement `load`, resize) peut tomber pile pendant l'intro.

**Correctif** : mesurer avant de lancer l'intro ; si un relayout est demandé pendant, le différer à la fin (`introRunning` / `pendingRelayout`).

## 5. Rien ne bouge, texte ou CTA invisible

**Cause** : onglet ou panneau masqué (`document.visibilityState === "hidden"`) → `requestAnimationFrame` et donc le ticker GSAP sont en pause : tweens figés à leur état de départ, Lenis immobile, `quickTo` inerte. Arrive aussi dans les navigateurs de test et les previews.

**Correctifs** :
- Safety net sur tout ce qui démarre masqué : `setTimeout(() => tl.progress(1), 2000)` (texte : 2,2 s ; CTA : 2 s après la fin du texte).
- En test : vérifier `document.visibilityState` avant de conclure qu'une animation est cassée. Pour tester les placements, passer l'intensité à 0 et couper le défilement fluide (les `gsap.set` restent synchrones).

## 6. Styles inline effacés (React StrictMode)

**Cause** : en dev, StrictMode monte → démonte → remonte les effets. Un cleanup `gsap.set(els, { clearProps: "all" })` efface **tout l'attribut style**, y compris les variables CSS inline posées par React (`style={{ "--x": … }}`), qui ne reviennent pas.

**Correctif** : nettoyer seulement ce que GSAP a posé : `clearProps: "transform,opacity,filter"`.

## 7. Image qui « pop » sans animation

**Cause** : `loading="lazy"` sur un média qui s'anime à l'apparition : l'animation se joue sur une image pas encore chargée, qui s'affiche ensuite d'un coup.

**Correctif** : `loading="eager"` (ou préchargement) pour les médias animés du premier écran ou d'une section épinglée ; `decoding="async"` reste utile.

## 8. Puces / tirets visibles avant leur ligne

**Cause** : une puce en `li::before` n'est pas dans les lignes découpées : elle reste affichée pendant que le texte est sous son masque.

**Correctif** : piloter le pseudo-élément par une variable CSS animée en même temps que la première ligne de son item :

```css
li::before { opacity: var(--bullet, 1); transform: translateY(calc((1 - var(--bullet, 1)) * 1.4em)); }
```

```ts
tl.fromTo(li, { "--bullet": 0 }, { "--bullet": 1, duration, ease }, startTimeOfItsFirstLine);
```

Retrouver l'index de la première ligne d'un item : `split.lines.findIndex((l) => li.contains(l))`, temps = `index × stagger × intensité`. Remettre `--bullet` en fin ou en annulation.

## 9. Transform GSAP qui écrase un hover CSS

**Cause** : après une anim d'entrée, GSAP laisse un `transform` inline (même neutre) sur l'élément : le `:hover { transform: … }` CSS ne s'applique plus.

**Correctif** : `clearProps: "transform"` (et `filter`) en `onComplete` de l'entrée.

## 10. Focus programmatique sans événement (tests)

`el.focus()` dans une page sans focus fenêtre change `document.activeElement` mais **ne déclenche pas** `focusin`. Pour tester un comportement au focus, dispatcher l'événement (`new FocusEvent("focusin", { bubbles: true })`) ou tester avec le défilement fluide coupé.

## Autres réflexes

- `mask: "lines"` + `filter: blur()` : le flou s'applique avant le masque ; pour une ombre floue en forme d'image détourée, mettre le `filter` sur un **parent** du calque masqué.
- `overwrite: "auto"` sur les tweens pilotés par l'état (positions, opacités) pour éviter les conflits lors de scrolls rapides.
- Réutiliser les mêmes dimensions (`width`/`height` sur `<img>`) pour éviter le layout shift (CLS).
