# Accessibilité et performance

Posture de conformité, seuils de contraste et de cibles : `lba-design:principles` §3 et §4. Ce fichier ne garde que ce qui est propre au mouvement.

## Réduction des animations

Deux réglages distincts dans le socle :

- **Mouvement réduit** (`prefers-reduced-motion: reduce`, ou `setReducedMotion(true)` en démo) : on retire le mouvement, pas le retour visuel. Coupés : translations, échelle, rotation, flou, parallaxe, inclinaison de vélocité, suivi souris, défilement fluide Lenis, défilement automatique (marquee, slider), roulement de l'odomètre. Gardés : fondus d'opacité courts (0,25 s, bloc entier, sans stagger), changements de couleur, états de survol et de focus. Le WCAG ne compte ni l'opacité ni la couleur comme du mouvement (Understanding 2.3.3, définition de « motion animation ») ; le flou y est inclus depuis un erratum, d'où sa suppression.
- **Intensité 0** (slider « Animations ») : rien ne s'anime, états finaux posés instantanément (`gsap.set`), aucun contenu masqué.

Recettes en mouvement réduit :

- Section épinglée : la piste saute au palier de l'étape active au lieu de glisser ; l'état actif change par fondu enchaîné des titres, textes et médias.
- Média persistant : pas de pose ni de swing, il reste en place ; le changement d'écran se fait en fondu.
- Hover carte produit : fondu packshot vers ambiance gardé, Ken Burns coupé.
- CTA après le texte : fondu sans montée ni flou.

Le slider et la case « Mouvement réduit » de `MotionControls` sont des outils de démo (montrer au client les deux versions) ; en production, on suit la préférence système, et éventuellement un réglage utilisateur.

## Contenu révélé au scroll

- Masquer avec `opacity` seulement, pas `visibility`/`display` : le contenu reste dans l'arbre d'accessibilité. Ajouter `pointer-events: none` + `user-select: none` sur ce qui est invisible.
- SplitText : revert après animation (sinon lecteurs d'écran et sélection voient des `div` par ligne).
- Section épinglée : un élément focusable dans un bloc pas encore affiché doit déclencher le scroll jusqu'à son étape au `focusin`.
- Liens répétés (« Découvrir » ×3) : nom accessible distinct via un `span.sr-only` (« Découvrir nos applications métier »).
- Décors (compteur décoratif, tirets en pseudo-élément, reflets, ombres) : `aria-hidden="true"` ou `content: "—" / ""`.
- Un seul `alt` pertinent pour des images empilées identiques ; les doublons en `alt=""`.

## Contraste

Cas propre au motion : un texte atténué par opacité ou couleur semi-transparente (état précédent d'une section épinglée, par exemple). Calculer la couleur résultante sur le fond, puis la comparer aux seuils de `lba-design:principles` §4 (script `contrast.py` de `lba-design:accessibility`). Exemple sur `#4400AA` : blanc 30 % ≈ 2:1, 45 % ≈ 3,1:1, 60 % ≈ 4,7:1. Un titre « atténué » reste du texte : il garde un contraste suffisant.

## Tailles et cibles

- Tailles de texte : repères de `lba-design:principles` §4, à ajuster selon la police ; ce qui ne bouge pas, c'est la lecture au zoom 200 %.
- Cibles : seuils de `lba-design:principles` §4.
- Typo fluide : `clamp(rem, vw, rem)`, jamais de `vw` pur (bloque le zoom texte) ; méthode complète dans `lba-design:ui-design`, `references/fondations.md`.

## Performance et éco-conception

- `transform` / `opacity` uniquement par défaut ; `will-change` seulement sur les éléments réellement animés en continu.
- `filter: blur()` animé : coûteux, réservé à peu d'éléments, retiré en fin d'anim. Un flou statique (ombre) est rasterisé une fois.
- Pas de bibliothèque 3D (Three.js…) pour un effet décoratif : 1–3 Mo, coût CPU/GPU, contraire à la sobriété.
- Médias : WebP/AVIF, `width`/`height` renseignés, `loading="eager"` uniquement pour ce qui s'anime au premier écran.
- Icônes : importer à l'unité (ex. `@phosphor-icons/react` en import nommé, tree-shaké).
- Polices : auto-hébergées en WOFF2, `font-display: swap`, une graisse si possible ; vérifier la licence web avant mise en ligne.
