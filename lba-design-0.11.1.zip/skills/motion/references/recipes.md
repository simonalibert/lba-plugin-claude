# Recettes

Patterns éprouvés, du plus courant au plus démonstratif. Tous s'appuient sur le socle (`assets/core/`) : intensité, mouvement réduit (`getMoveFactor()` pour toute distance, tout flou), `getEase()`, `onReplay`, safety nets. Comportement de chaque recette en mouvement réduit : `a11y-perf.md`.

## Sommaire

1. Texte ligne par ligne (masque)
2. CTA qui arrive après le texte
3. Grille de cartes (batch)
4. Section épinglée à étapes (titres qui défilent, alignés au pixel)
5. Média persistant entre étapes (poses, swing, changement d'écran)
6. Reflet et ombre sur une image détourée
7. Suivi souris (tilt)
8. Compteur façon tableau d'affichage (odomètre)
9. Effet vélocité (inclinaison au scroll)
10. Hover carte produit (fondu packshot → ambiance)
11. Flou à l'apparition

---

## 1. Texte ligne par ligne

`lineReveal(container, targets, { delay, stagger, blur, onDone })` (`assets/core/lineReveal.ts`) ou le hook `useLineReveal` (`assets/react/`). La fonction d'annulation renvoyée affiche le texte tout de suite et n'appelle **pas** `onDone` : rien de ce qui suit (CTA) ne démarre après une annulation.

- SplitText `type: "lines", mask: "lines"`, chaque ligne `yPercent: 130 → 0` (130 car le masque est étendu vers le bas) + `opacity: 0 → 1`, `gsvOut`, durée `max(0,3, 0,8 × k)`, stagger `0,08 × k`.
- Attendre la police (voir pitfalls §3), **revert après animation** (DOM propre pour lecteurs d'écran et sélection), safety net 2,2 s.
- Ajouter la règle `.line-mask` + `display: flow-root` sur les cibles (`assets/core/motion.css`), sinon jambages coupés et lignes qui se recalent.
- Pas de flou sur le texte courant (lisibilité) ; un flou léger (≤ 6 px × k) est acceptable sur un titre d'intro.
- Reveal au scroll : rejouer à chaque retour dans l'écran (`onEnter` / `onLeaveBack` qui reconstruit le split).

## 2. CTA après le texte

Le CTA reste caché pendant tout le reveal et ne démarre **qu'au `onDone` de la dernière ligne**, plus un court temps (0,15 s × k), jamais sur une durée estimée, qui tombe faux dès que le texte change de longueur.

```ts
gsap.set(cta, { opacity: 0 });
lineReveal(body, lines, {
  onDone: () => {
    gsap.timeline({ delay: 0.15 * k, onComplete: () => gsap.set([cta, icon], { clearProps: "filter,transform" }) })
      .fromTo(cta, { opacity: 0, y: 14 * k, filter: `blur(${6 * k}px)` }, { opacity: 1, y: 0, filter: "blur(0px)", duration: scaledDuration(0.7), ease })
      .fromTo(icon, { opacity: 0, x: -10 * k }, { opacity: 1, x: 0, duration: scaledDuration(0.5), ease }, "<0.25");
    ctaSafety = setTimeout(() => tl.progress(1), 2000);
  },
});
```

Clavier : un CTA invisible reste focusable → au `focus` (ou `focusin` du bloc), tout afficher immédiatement (`useLineReveal` le fait).

`clearProps` en fin d'anim pour que le hover CSS (flèche qui avance de 0,2 em) fonctionne (pitfalls §9). Hover : changement de couleur seulement.

## 3. Grille de cartes

`batchReveal(selector)` / `useBatchReveal` : `ScrollTrigger.batch`, fondu + montée `20 px × k`, stagger `0,08 × k`, `power2.out`, `clearProps: "transform"`. Une seule fois par sélecteur ; `onLeaveBack` remet à 0 pour rejouer.

## 4. Section épinglée à étapes

Cas type : une phrase fixe à gauche (« L'agence fait des : »), à droite des titres qui défilent ; au scroll, chaque titre se déplie à son tour (texte, média, CTA), les précédents s'atténuent.

**Structure**
- Conteneur haut (`height: calc(100svh + N × 75svh)`) + scène `position: sticky; top: 0; height: 100svh` (plus simple et plus robuste avec Lenis que `pin: true`).
- Un `ScrollTrigger` sur le conteneur (`start: "top top", end: "bottom bottom"`), `onUpdate` → `update(progress)`.
- Items en `position: absolute`, placés par `transform` ; aucune hauteur animée (layout).

**Hybride scroll / déclenché** (le plus robuste)
- *Continu* : la colonne suit le scroll ; découper la progression en segments (`SEGMENTS = [0.5, 1, 1, 0.6]` : entrée courte, une étape par item, tenue finale), avec un **palier de lecture** au début et à la fin de chaque segment (`hold(t)` = smoothstep entre 20 % et 80 %).
- *Déclenché* : l'état actif change à mi-segment (12 % pour le premier, pour réagir « dès qu'on scrolle ») et lance les tweens d'état : positions des items, opacité des titres (précédents à 0,75), reveal du texte de l'actif, fondu de sortie des autres (0,25 s).

**Alignement au pixel** (« le titre de droite au niveau du titre de gauche »)
- Mesurer le haut des capitales, pas la boîte : une sonde `span.baseline-probe` (`inline-block; width:0; height:0`) au début de la première ligne donne la ligne de base ; `capTop = probe.bottom − ctx.measureText("H").actualBoundingBoxAscent` (canvas avec la police calculée).
- Translation de la piste = `ancre − top(item actif) − capOffset(item)`. Vérifier en mesurant : écart attendu 0 px à chaque palier.
- Remesurer sur `ScrollTrigger` refresh et `ResizeObserver` (police, zoom), jamais pendant un split (pitfalls §4).

**Clavier** : un CTA d'un item non actif est focusable mais invisible → au `focusin`, scroller jusqu'au palier de cet item (`st.start + units/total × (st.end − st.start)`).

## 5. Média persistant entre étapes

Un seul média (ex. téléphone) pour toutes les étapes plutôt qu'un par item : il ne disparaît pas, il **voyage**.

- Placé en absolu dans la colonne, sa position Y suit le texte de l'item actif (interpolée comme la piste).
- Une pose par étape `{ x, rotation, rotationY }` × k, interpolée avec le même `hold(t)`, plus un **swing** qui culmine à mi-transition : `rotationY += sin(π t) × 14° × k`. Le changement d'écran (fondu entre images empilées, 0,45 s) a lieu à mi-segment, au pic du swing.
- `transformPerspective: 1200` ; l'item actif réserve la hauteur du média (`max(texte, offset + hauteur média)`) pour que les titres suivants passent dessous.
- Entrée au premier état (fondu + flou 14 px × k + scale 1,06 → 1), sortie si retour à l'état initial.
- Mobile : sous le texte, plus petit (`min(24svh, 12rem)`).
- Sans 3 visuels distincts, le changement d'écran est invisible : prévoir les visuels (ou coque + écran séparés pour un écran qui défile, une vraie transition d'écran, un zoom final plein écran).

## 6. Reflet et ombre sur une image détourée

Pour un média PNG/WebP **à fond transparent**, utiliser son canal alpha comme masque (`mask-image: url(...)`, `mask-size: contain`) :

- **Reflet** : calque masqué contenant une bande en dégradé (`linear-gradient(100deg, transparent, rgb(255 255 255 / .22), transparent)`, `mix-blend-mode: screen`) dont `xPercent` suit l'orientation (`mapRange(-20, 20, -140, 240, rotationY)`) et l'opacité l'inclinaison.
- **Ombre** : silhouette masquée sombre dans un **parent** porteur de `filter: blur(16px)` statique (le flou doit s'appliquer après le masque), décalée et étirée selon l'inclinaison (`x = 7 + rotY × 0,8`, `scaleX = 1 + |rotY|/120`, opacité ~0,3). Lumière supposée en haut à gauche.
- Si l'image a un fond plein, ces effets couvrent tout le rectangle : demander une version détourée.

## 7. Suivi souris

`gsap.quickTo(pointer, "x"/"y", { duration: 0.8, ease: "power3.out", onUpdate: render })`, position normalisée −1…1 sur la fenêtre, `rotationY += x × 7° × k`, `rotationX −= y × 4° × k`. Seulement si `(hover: hover) and (pointer: fine)` ; retour à 0 au `pointerleave` du document. Combiner avec la pose de scroll dans **une seule** fonction `render()` (pas deux sources qui écrivent `transform`).

## 8. Compteur odomètre

`rollOdometerTo(el, text, duration)` (`assets/core/odometerRoll.ts`) : chaque chiffre a sa « bobine » ; l'ancien sort par le haut, le nouveau entre. Pour plusieurs cellules, décaler leurs départs de façon **irrégulière** (pas un stagger constant). Flou de mouvement léger optionnel (keyframes `blur 0 → 2,5 px × k → 0`). Décoratif : `aria-hidden="true"` si l'information est déjà ailleurs.

## 9. Effet vélocité

`registerVelocityTarget(el)` (`assets/core/velocity.ts`) : `skewY` proportionnel à la vitesse de scroll, plafonné à **0,5°**, retour à plat en 0,8 s (`power3.out`). Effet bonus : interrupteur dédié, indépendant de l'intensité, coupé en mouvement réduit. Garder petit pour qu'un bloc pleine largeur incliné ne crée pas de scrollbar.

## 10. Hover carte produit (validé client Opinel)

Le texte ne bouge pas ; le packshot passe en fondu vers la photo d'ambiance avec un Ken Burns lent (`scale 1 + 0,06 × k` sur 2,2 s, `ease: "none"`), une ombre CSS discrète. Une seule timeline ; entrée plus rapide (0,4 s / max(k, 0,3)) que le retour (0,5 s). À 0 % : pas de swap. Le fondu va toujours au bout (jamais deux images mélangées à mi-opacité).

## 11. Flou à l'apparition

Exception assumée à « transform/opacity seulement » quand le client le demande : `filter: blur(Npx × k) → blur(0)`, sur peu d'éléments (média 14 px, CTA et titres d'intro 6 px), jamais sur du texte courant, `clearProps: "filter"` en fin d'anim. Le signaler comme écart au système dans le livrable.
