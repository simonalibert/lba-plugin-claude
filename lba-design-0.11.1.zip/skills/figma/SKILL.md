---
name: figma
description: "Méthode et pièges techniques pour écrire dans un fichier Figma existant via le MCP Figma (use_figma), quel que soit le projet client. Déclencher dès qu'une action d'écriture est demandée sur un fichier Figma : audit d'hygiène du fichier (styles détachés, tokens non liés, composants sans description), construction ou correction de composant, retouche de token, bug de mise en page (sizing, alignement, texte tronqué ou détaché de son style), écriture d'annotations. À charger en complément de figma:figma-use, pas à sa place. Porte la technique d'écriture, pas le contenu : ce que disent les annotations relève de `lba-design:handoff` ou `lba-design:accessibility`. Ne couvre pas l'audit d'accessibilité."
---

# Écrire dans un fichier Figma existant

**Préséance** : demande > état réel du fichier, revérifié à chaque session > conventions déjà en place dans le fichier (nommage, tokens, structure) > DESIGN.md du projet > méthode de ce skill. Les pièges du §3 sont les anti-défauts de ce skill : chacun dit quoi faire à la place.

Ce skill documente la méthode. Le contenu produit (tokens, composants, marque) vit dans le `DESIGN.md` du projet, pas ici.

## 1. Principes de méthode

- **Vérifier l'état réel avant d'agir.** Le fichier change entre deux sessions, parfois pendant la session elle-même si quelqu'un d'autre y travaille en parallèle. Ne jamais supposer qu'un ID, un nom de composant ou une valeur trouvée précédemment est toujours valide sans le revérifier.
- **Inspecter avant de créer.** Avant d'ajouter un token ou un composant, vérifier qu'un équivalent n'existe pas déjà (naming, valeurs, conventions déjà en place). Répliquer la convention trouvée plutôt que d'en imposer une nouvelle.
- **Valider par capture d'écran après toute modification visuelle**, pas seulement par lecture des propriétés. Les propriétés peuvent sembler correctes tout en produisant un rendu cassé (cf. §3, fonds blancs par défaut).
- **Travailler par petites étapes vérifiables** plutôt que d'enchaîner de grosses modifications non testées, en particulier sur la mise en page (sizing, alignement).

## 2. Routine d'audit (à relancer régulièrement, pas juste en fin de projet)

Sur la page de travail, vérifier dans cet ordre :

1. **Textes détachés de leur style** (`textStyleId === ""`) : regrouper par police pour distinguer un vrai problème (police censée être liée) d'un cas attendu (libellés techniques hors design system).
2. **Écart `leadingTrim` entre un texte et son style** : un texte peut avoir une valeur différente de son style sans être détaché ; les deux doivent être identiques.
3. **Composants/component sets sans description.**
4. **Variant properties à valeur unique** : souvent un reliquat de restructuration, parfois du travail en cours légitime : vérifier lequel avant de conclure.
5. **Spacing/couleur/radius non liés à un token** : ne pas corriger en aveugle, vérifier d'abord si la valeur est une exception légitime (radius pilule, décalage négatif pour un chevauchement, `itemSpacing` sur un layout en `SPACE_BETWEEN` où la valeur ne fait rien) avant de la considérer comme une erreur.
6. **Erreurs internes sur les component sets** (`componentPropertyDefinitions` qui lève une erreur) : signale souvent un variant au nom corrompu, à investiguer en listant les enfants un par un plutôt que de laisser l'erreur bloquer tout le composant.

Avant de corriger en masse une valeur qui semble être une erreur, vérifier si elle est **répétée de façon cohérente** ailleurs dans le fichier. Une valeur hors échelle utilisée une seule fois est probablement une erreur ; utilisée plusieurs fois sur le même type de composant, c'est probablement voulu (et mérite peut-être de devenir un vrai token plutôt que d'être forcée vers le plus proche existant).

## 3. Pièges techniques rencontrés (Plugin API Figma)

**`leadingTrim` et détachement de style**
Un texte doit avoir la même valeur de `leadingTrim` que son style pour rester rattaché. Corriger uniquement l'un des deux casse le lien. Piège plus subtil : même en corrigeant les deux dans le même script, l'**ordre** compte : corriger le style avant les instances crée une fenêtre où ils sont temporairement en désaccord, ce qui suffit à déclencher le détachement même si tout est corrigé une fraction de seconde après. Toujours corriger toutes les instances d'abord, le style partagé en dernier.

**Boucle de calcul Fill-dans-Hug**
Ne jamais mettre un enfant en `layoutSizingHorizontal`/`Vertical = FILL` sur un axe où son parent est en `HUG` sur ce même axe. Le parent essaie de se dimensionner sur son contenu (dont cet enfant), l'enfant essaie de se dimensionner sur son parent : Figma ne résout pas ça proprement, les dimensions partent dans des valeurs absurdes plutôt que de lever une erreur claire. Si un parent doit rester `Hug`, un enfant qui doit occuper tout l'espace disponible a besoin d'un mécanisme différent (ex. hauteur fixe partagée, ou ratio verrouillé, voir plus bas).

**Fonds blancs par défaut non voulus**
Un frame créé via l'auto-layout (`createAutoLayout`/`createFrame`) hérite d'un fond blanc opaque par défaut. S'il n'est pas explicitement vidé (`fills = []`) quand ce n'est pas voulu, il peut cacher silencieusement tout ce qui est dessous (texte, motif, couleur du parent), sans erreur, juste un rendu vide à l'écran. Systématique à vérifier par capture d'écran après toute création de frame.

**Chaîne de sizing du texte**
Pour qu'un texte suive la largeur de son parent (au lieu de rester tronqué ou figé), il faut les deux réglages en même temps : `layoutSizingHorizontal = "FILL"` et `textAutoResize = "HEIGHT"`. L'un sans l'autre ne suffit pas. Vérifier toute la chaîne de parents, pas seulement le nœud de texte : un seul niveau intermédiaire resté en `Hug` ou taille fixe bloque tout ce qui est en dessous.

**Ratio d'image conservé au redimensionnement**
Utiliser `node.lockAspectRatio()` puis `layoutSizingHorizontal = "FILL"`, pas une tentative manuelle de lier la hauteur à la largeur (qui retombe dans le piège Fill-dans-Hug si le parent n'est pas en taille fixe).

**Positionnement "absolu" dans un frame**
Un élément superposé (badge, tag) doit avoir `layoutPositioning = "ABSOLUTE"` **et** des `constraints` cohérentes avec l'intention (ex. `{horizontal: "MIN", vertical: "MAX"}` pour rester ancré en bas à gauche). Sans les bonnes constraints, la position tient tant que le parent garde sa taille d'origine et casse dès qu'il change.

**Détacher une instance**
Nécessaire pour ajouter des enfants à une instance (structure verrouillée tant qu'elle reste liée au composant). Casse le lien vers le composant source : à faire seulement pour un test ponctuel ou en dernier recours, jamais par défaut.

**Chargement de police**
Le runtime du plugin ne voit pas toujours les polices locales/tierces (Adobe Fonts) même actives dans Figma natif. Tester avec un `loadFontAsync` rapide avant un gros chantier de texte. Si la police existe mais n'est pas détectée, vérifier le dialogue Figma "Use your fonts with Figma agents" avant de conclure à un vrai blocage.

**Variant à valeur unique**
Ne peut pas être supprimé proprement via l'API (`deleteComponentProperty` refuse sur une property de type VARIANT). À signaler plutôt qu'à forcer un contournement risqué ; la suppression native dans l'UI Figma gère le relink des instances correctement.

**Annotations natives (Dev Mode)**
Éprouvées le 29/09/2026 sur un fichier client (écriture, relecture, retrait).

- Écriture : réaffecter le tableau entier, `node.annotations = [...existantes, nouvelle]`. Chaque entrée porte `label` **ou** `labelMarkdown` (gras, italique, code et mentions d'utilisateurs rendus), plus `categoryId` et éventuellement `properties` (valeurs du nœud épinglées sous l'annotation, par ex. `[{ type: "height" }]`).
- **Piège de relecture** : une annotation relue contient à la fois `label` et `labelMarkdown`, et l'API refuse de recevoir les deux (« Only one of label or labelMarkdown should be given »). Pour ajouter une annotation à un nœud déjà annoté, ou restaurer un état, normaliser d'abord chaque entrée existante : garder `labelMarkdown` s'il existe, sinon `label`. Sans cela, l'ajout échoue et la restauration aussi.
- **Catégories** : lister avec `figma.annotations.getAnnotationCategoriesAsync()` (préréglages Development, Interaction, Accessibility, Content, plus les catégories propres au fichier). Un `categoryId` inexistant est accepté **sans erreur** : toujours le vérifier contre la liste. Correspondance LBA : accessibilité → Accessibility ; comportement, responsive, états → Development ou Interaction selon l'usage du fichier ; contenu → Content.
- **Propriétés** : validées selon le type de nœud (`fontSize` refusé sur un FRAME). Réserver aux valeurs qui aident vraiment le dev.
- **Calques internes d'instance** (ID en `I…;…`) : annotables sans détacher l'instance.
- **Contrôle** : une annotation n'apparaît pas dans `screenshot()` ni `get_screenshot` (surcouche de Dev Mode). Vérifier par relecture de `node.annotations`, puis demander un contrôle visuel en Dev Mode.
- Ne jamais écraser ni reformuler les annotations de l'équipe : ajouter à la suite, et ne retirer que les siennes.

**Bibliothèques de la communauté** (Simple Design System et autres) : recherche avec `includeLibraryKeys`, import des variantes, modification des instances. Lire `references/bibliotheques-communautaires.md` avant de construire avec une bibliothèque externe.

## 4. Code Connect

Pas encore utilisable à l'agence (plan Figma et code existant requis). Conditions, historique du test et marche à suivre : `references/code-connect.md`, à lire avant toute demande de Code Connect.

## 5. Signaler plutôt qu'exécuter

- Demander un lien de nœud ou une capture si l'endroit exact n'est pas clair, plutôt que deviner.
- Signaler un décalage de contenu ou de structure (mauvaise page, mauvais public, décompte qui ne correspond pas) avant d'exécuter tel quel, sauf instruction explicite de continuer.
- Distinguer une exception légitime d'un bug par l'investigation (usage réel, rendu) avant toute correction en masse.
