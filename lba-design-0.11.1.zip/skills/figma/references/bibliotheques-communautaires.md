# Bibliothèques de la communauté (Simple Design System et autres)

Retour d'expérience du projet UCI (wireframes dans Figma avec Simple Design System, 2026). Vérifié sur ce fichier ; à revérifier sur une autre bibliothèque.

## Trouver les composants

- `search_design_system` ne renvoie des résultats complets que si on lui passe explicitement `includeLibraryKeys` avec la clé de la bibliothèque de la communauté. Sans elle, résultats incomplets ou vides.
- Les identifiants de nœuds des URL Figma se passent tels quels dans `nodeId`, sans transformation.

## Importer

- Ensemble de variantes : `figma.importComponentSetByKeyAsync(key)`. Composant simple : `figma.importComponentByKeyAsync(key)`.
- Choisir une variante par son nom, par exemple `set.children.find(c => c.name.includes("Platform=Mobile"))` ou `"Platform=Desktop"`. Ces motifs de nom sont stables dans Simple Design System.
- Tous les composants n'ont pas de variante de plateforme (la carte de Simple Design System n'en a pas) : c'est le comportement documenté de la bibliothèque, pas un bug.

## Modifier une instance

- Parcourir en profondeur une instance avec `findOne()` peut échouer. Préférer `children.find()` sur les enfants directs pour masquer une image, retirer des cartes en trop, etc.
- Les emplacements portent un nom stable : par exemple l'emplacement des cartes de « Card Grid Content List » s'appelle `"Cards"` (`instance.children.find(n => n.name === "Cards")`).
- Rappel du §3 du SKILL.md : chaque frame créé à la main hérite d'un fond blanc opaque ; vider `fills` sur chaque enfant créé, pas seulement sur le parent.
