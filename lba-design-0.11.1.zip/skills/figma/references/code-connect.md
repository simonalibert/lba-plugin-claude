# Code Connect

Code Connect relie un composant Figma à son vrai code source dans un dépôt (GitHub par exemple), pour que Dev Mode et les agents de code (Claude Code compris) affichent/utilisent le vrai composant plutôt que d'improviser une réinterprétation. Utile en agence multi-stack (Drupal, React, etc.) parce que l'approche recommandée depuis 2026, les **Template files**, est agnostique au framework : un même mécanisme pour connecter n'importe quel langage/framework à Figma, plus besoin d'un parser différent par stack.

**Deux conditions à réunir avant de pouvoir l'utiliser, aucune des deux n'est réglable depuis Claude :**
1. **Plan Figma Org ou Enterprise.** Testé le 14/08/2026 sur le compte LBA : `Code connect mapping is only available to Org and Enterprise plans`. À vérifier avec qui gère l'abonnement Figma avant de retenter.
2. **Du vrai code déjà écrit** pour le composant à connecter. Code Connect relie deux choses existantes, il n'en génère aucune : sans composant codé quelque part (React, Twig, autre), il n'y a rien à relier. Sur un projet encore en phase maquette (dev pas commencé), ce n'est pas encore le bon moment.

**Marche à suivre une fois les deux conditions réunies :**
- Le skill `figma:figma-code-connect` (déjà dans le catalogue LBA) génère les fichiers de mapping à partir d'un composant Figma pointé.
- Commencer petit : un seul composant bien stabilisé (pas toute la librairie d'un coup), voir ce que ça donne, puis étendre.
- Les outils concernés côté Claude : `get_code_connect_suggestions` (proposition de mapping), `add_code_connect_map` / `send_code_connect_mappings` (validation et sauvegarde). Toujours faire valider les suggestions par un humain avant de les enregistrer, ce n'est pas une étape à automatiser en aveugle.
