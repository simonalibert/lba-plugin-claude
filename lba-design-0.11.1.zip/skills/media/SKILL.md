---
name: media
description: "Tout ce qui concerne les visuels à produire pour un site, méthode La Bonne Agence, en deux parcours. Inventaire : besoins en photos, logos et pictogrammes d'un site en refonte ou en construction, avec ratios, dimensions retina, quantités par cible, nomenclature de fichiers et cahier des charges médias pour budgéter ou commander un shooting. Gabarit de cover : gabarit Figma d'une illustration ou d'une photo plein écran (cover, hero, bannière, slider) à commander à un illustrateur ou un photographe, avec zones de sécurité, recadrage responsive, formats à livrer et brief. Déclencher dès qu'il est question de « de quels visuels on a besoin », de combien de photos prévoir, de nomenclature ou de formats d'export d'images, de brief illustrateur ou photographe, de zones de sécurité d'un visuel web ou de « à quoi ressemblera l'image sur chaque écran ». Ne pas utiliser pour retoucher, recadrer ou générer des images : ce skill produit des spécifications, pas des images."
---

# Médias : inventaire et gabarits de cover

**Préséance** : invariants de `lba-design:principles` (ne rien inventer, statuts) > demande > état réel inspecté (Figma, site mesuré) > ratios tokenisés (DESIGN.md, variables) > règle d'affichage validée par le développeur > nomenclatures et formats (défauts maison).

Charger `lba-design:principles` avant de commencer.

## Choisir le parcours, puis le lire avant toute action

| Demande | Parcours | À lire en entier avant de commencer |
|---|---|---|
| Besoins en visuels de tout un site, chiffrage, nomenclature, cahier des charges médias | **A. Inventaire** | `references/inventaire.md` |
| Un visuel plein écran précis à commander : cover, hero, bannière, brief illustrateur ou photographe, zones de sécurité | **B. Gabarit de cover** | `references/gabarit-cover.md` (il renvoie à ses propres références `gabarit-*.md`, au script `scripts/calcul_zones.py` et aux exemples de `assets/`) |

Les deux se suivent souvent : l'inventaire repère les covers qui méritent un gabarit, et le gabarit fixe des ratios qui reviennent dans l'inventaire. Si la demande couvre les deux, commencer par l'inventaire et le dire.

Ne jamais répondre à partir de ce seul fichier : le tronc commun ci-dessous ne suffit pas à mener un parcours.

## Tronc commun : principe directeur

**Ne jamais halluciner un ratio, une quantité ou une couverture de cible.** Ce skill produit des chiffres qui engagent un budget de shooting ou de banque d'images côté client : l'erreur coûte cher. Chaque donnée du livrable porte un statut de provenance (`lba-design:principles` §2) : vérifié = mesuré dans un composant réel inspecté, pas un nom de composant supposé ; estimé = extrapolé depuis un wireframe ou une maquette d'avant-vente.

## Tronc commun : règles valables pour les deux parcours

- **Vérifier l'état réel du fichier Figma** (`get_metadata`, `get_screenshot`) avant toute affirmation sur un gabarit, un ratio ou un composant ; ne pas se fier à la mémoire d'une session précédente.
- **Reprendre les ratios déjà tokenisés** (DESIGN.md, variables Figma) ; un ratio nouveau est un trou à trancher, pas un choix à faire seul.
- **Séparer les assets tiers** (logos de partenaires, contenus fournis) des visuels à produire : délais et chaînes d'approvisionnement différents.
- **Aucune dimension en pixels** transmise au client ou à un prestataire avant validation par le développeur quand la règle d'affichage est encore en discussion.

## Tronc commun : selon le profil du projet

Le profil (`lba-design:principles` §11) se lit dans la fiche projet et change l'inventaire comme le gabarit :

- **Éco-conçu** : chaque image justifie son emplacement (une image décorative se supprime avant de se compresser) ; formats AVIF ou WebP, poids cible par emplacement dans le cahier des charges ; vidéo seulement si elle porte un contenu, sans lecture automatique.
- **Vitrine expressive** : séquences d'images, vidéos et visuels détourés (reflets, ombres de `lba-design:motion`) inventoriés à part, avec leur poids estimé et leurs contraintes de production (fond transparent, cadence, nombre d'images).
- **Conformité RGAA** : pour chaque vidéo, sous-titres et transcription à prévoir dans le chiffrage ; pour chaque image porteuse d'information, une alternative à rédiger, à compter dans la charge éditoriale.

## Tronc commun : habillage et forme

Un document généré (interne ou client) suit les modèles de documents de l'agence, jamais la charte du client traité. Toujours dater le document. Doc client : ton sobre, sans superlatifs.
