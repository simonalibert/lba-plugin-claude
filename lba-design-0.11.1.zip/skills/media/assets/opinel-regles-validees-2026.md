# Opinel, cover de page d'accueil : règles validées (Johann, 29/09/2026)

Exemple de référence d'une règle d'affichage conçue avec le gabarit puis validée par le développeur.

## Production mesurée avant le projet

- Cover : hauteur = 100vh − 170 px, minimum 560 px, `background-size: cover`, ancrage 50 % / 30 %.
- Header : 170 px (≥ 1024 px de large), 123 px en dessous ; la cover retire toujours 170 px.
- Images servies : desktop 1920 × 650 (`cms_hp_banner_1920`), mobile 768 × 1365 (`cms_hp_banner_768`, fichier distinct), bascule à 768 px de large inclus.
- Texte : titre + bouton ancrés en bas de la cover, par-dessus l'image.

## Règle validée

- Deux règles seulement, selon l'orientation de l'écran.
- **Paysage** (desktop, tablettes à l'horizontale) : l'image démarre en haut de la page, derrière le header opaque de 210 px, ancrée en haut et centrée. Hauteur = header + premier écran visible + 40 px + bloc texte + 67 px. Titre et description posés sur l'image, 40 px sous la ligne de flottaison. Master 3 : 2, livré en 3840 × 2560.
- **Portrait** (téléphones, tablettes à la verticale) : l'image démarre en haut de la page, derrière le header opaque de 123 px, et s'arrête à la ligne de flottaison. Titre et description dessous, sur un fond uni (40 px de marge). Master 9 : 16, livré en 1620 × 2880.
- Bascule entre les deux masters selon l'orientation (et non plus à 768 px).

## Zones obtenues (pixels du fichier livré)

- Paysage : masqué par le header 0 → 571 ; sujet 571 → 1598 de haut, 273 → 3567 de large ; visible sur grands écrans jusqu'à 1985 ; zone texte 1704 → 2412.
- Portrait : masqué par le header 0 → 518 ; sujet 518 → 2004 de haut, 82 → 1538 de large ; visible sur téléphones seulement jusqu'à 2880.

## Chemin parcouru (utile pour anticiper)

2 : 1 → 2,95 : 1 (format CMS) → 5 : 4 → 3 : 2 en paysage ; 9 : 16 → 3 : 8 → 9 : 16 → 2 : 5 → 9 : 16 en portrait. Chaque changement venait d'une règle d'affichage précisée en cours de route (texte sous la flottaison, image derrière le header, texte sous l'image en mobile). Poser ces trois questions dès l'étape 0 fait gagner la majorité des itérations.
