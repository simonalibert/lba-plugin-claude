#!/usr/bin/env python3
"""Compute per-format crops and safe zones for a full-width hero illustration.

Input: a JSON config (see references/gabarit-calculs.md). Output: JSON with, for each
format, the visible crop in master coordinates, plus the union/intersection
zones used to draw the safe-zone plan in Figma.

Usage:
    python calcul_zones.py config.json
    python calcul_zones.py --compromis R_MIN R_MAX   # losses per candidate master ratio
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass, asdict


@dataclass
class Format:
    screen_w: int
    screen_h: int
    viewport_w: int
    viewport_h: int
    label: str = ""
    text: dict | None = None      # per-format override of cfg["text"]
    header_h: float | None = None  # per-format override of cfg["header_h"]
    visible_h: float | None = None  # page height visible at load (defaults to viewport_h)


@dataclass
class Crop:
    viewport_w: int
    viewport_h: int
    cover_w: float
    cover_h: float
    ratio: float
    crop_left: float
    crop_top: float
    crop_w: float
    crop_h: float
    text_top: float
    text_bottom: float
    text_left: float
    text_right: float
    fold_in_cover: float | None  # visible cover height in master px, None if fully visible
    label: str


def cover_height(cfg: dict, vw: int, vh: int) -> float:
    """Cover height in CSS px according to the measured behavior."""
    b = cfg["behavior"]
    mode = b["mode"]
    if mode == "fixed_ratio":
        return vw / b["ratio"]
    if mode == "viewport":
        h = vh * b.get("vh_factor", 1.0) - b.get("offset", 0)
    elif mode == "fixed_height":
        h = b["height"]
    else:
        raise ValueError(f"unknown behavior mode: {mode}")
    if b.get("min_height") is not None:
        h = max(h, b["min_height"])
    if b.get("max_height") is not None:
        h = min(h, b["max_height"])
    return h


def compute(cfg: dict) -> dict:
    mw, mh = cfg["master"]["w"], cfg["master"]["h"]
    ax, ay = cfg["behavior"].get("anchor", [0.5, 0.5])
    crops: list[Crop] = []
    for f in (Format(**x) for x in cfg["formats"]):
        text = f.text or cfg["text"]  # CSS px, anchored to the cover
        header = f.header_h if f.header_h is not None else cfg.get("header_h", 0)
        vw, vh = f.viewport_w, f.viewport_h
        cw, ch = vw, cover_height(cfg, vw, vh)
        # background-size: cover
        s = max(cw / mw, ch / mh)
        k = 1 / s  # master px per CSS px
        crop_w, crop_h = cw * k, ch * k
        crop_left = (mw - crop_w) * ax
        crop_top = (mh - crop_h) * ay
        bottom = crop_top + crop_h
        tw = min(text["max_w"], vw - 2 * text["left"])
        visible_css = (f.visible_h if f.visible_h is not None else vh) - header
        fold = None if visible_css >= ch else crop_top + visible_css * k
        crops.append(Crop(
            vw, vh, cw, ch, cw / ch, crop_left, crop_top, crop_w, crop_h,
            text_top=bottom - text["bottom_offset_top"] * k,
            text_bottom=bottom - text["bottom_offset_bottom"] * k,
            text_left=crop_left + text["left"] * k,
            text_right=crop_left + (text["left"] + tw) * k,
            fold_in_cover=fold, label=f.label,
        ))
    inter_top = max(c.crop_top for c in crops)
    inter_bottom = min(c.crop_top + c.crop_h for c in crops)
    inter_left = max(c.crop_left for c in crops)
    inter_right = min(c.crop_left + c.crop_w for c in crops)
    text_top = min(c.text_top for c in crops)
    zones = {
        "union_top": min(c.crop_top for c in crops),
        "union_bottom": max(c.crop_top + c.crop_h for c in crops),
        "inter_top": inter_top,
        "inter_bottom": inter_bottom,
        "inter_left": inter_left,
        "inter_right": inter_right,
        "text_top": text_top,
        "text_bottom": max(c.text_bottom for c in crops),
        "text_left": min(c.text_left for c in crops),
        "text_right": max(c.text_right for c in crops),
        "free_top": inter_top,
        "free_bottom": min(text_top, inter_bottom),
        "min_ratio": min(c.ratio for c in crops),
        "max_ratio": max(c.ratio for c in crops),
    }
    pct = {k: round(v / mh * 100, 1) for k, v in zones.items()
           if k.endswith(("top", "bottom"))}
    if zones["free_bottom"] - zones["free_top"] < 0.2 * mh:
        warning = "Zone libre inférieure à 20 % de la hauteur : à signaler."
    else:
        warning = None
    return {"crops": [asdict(c) for c in crops], "zones": zones,
            "zones_pct": pct, "warning": warning}


CANDIDATES = {"5:4": 5 / 4, "4:3": 4 / 3, "3:2": 3 / 2, "16:9": 16 / 9, "2:1": 2.0,
              "9:16": 9 / 16, "3:5": 3 / 5, "1:2": 0.5, "2:3": 2 / 3, "4:5": 4 / 5}


def compromise(r_min: float, r_max: float) -> list[dict]:
    """Worst side loss (per side) and worst bottom loss for each candidate ratio,
    with background-size: cover and a top anchor."""
    rows = []
    for name, r in CANDIDATES.items():
        side = max(0.0, (1 - r_min / r) / 2)
        bottom = max(0.0, 1 - r / r_max)
        rows.append({"ratio": name, "value": round(r, 3),
                     "side_loss_pct": round(side * 100, 1),
                     "bottom_loss_pct": round(bottom * 100, 1),
                     "side_within_5pct_margin": side <= 0.05})
    return sorted(rows, key=lambda x: max(x["side_loss_pct"], x["bottom_loss_pct"]))


if __name__ == "__main__":
    if sys.argv[1] == "--compromis":
        print(json.dumps(compromise(float(sys.argv[2]), float(sys.argv[3])), indent=2))
        sys.exit(0)
    with open(sys.argv[1], encoding="utf-8") as fh:
        print(json.dumps(compute(json.load(fh)), indent=2, ensure_ascii=False))
