# Parcours B : gabarit d'une cover plein écran (desktop + mobile)

Parcours du skill `lba-design:media`. Tronc commun (principe directeur, statuts, habillage) : voir le SKILL.md.

Livrable : un gabarit Figma qui permet à un illustrateur de concevoir sans risque de coupe ni de chevauchement avec l'interface, et qui montre en direct le rendu de son image sur chaque écran courant. Né du projet Opinel (cover de page d'accueil, septembre 2026) : `assets/exemple-opinel-desktop.json` contient la configuration mesurée en production, et `assets/opinel-regles-validees-2026.md` la règle finalement validée avec le développeur (18 écrans, deux masters). Ce cas sert d'exemple, pas de norme : ses valeurs (bascule à 768 px, ancrage 50 % / 30 %, minimum 560 px) ne se reprennent jamais sans mesure sur le nouveau projet.

Ce qui fait la valeur du gabarit, c'est de partir du **comportement réel** de la cover plutôt que de la maquette : sur Opinel, la maquette suggérait un ratio fixe, alors que le site recadrait l'image (hauteur de fenêtre moins header, minimum 560 px, ancrage 50 % / 30 %). Toutes les zones en dépendaient.

Le gabarit sert aussi à **concevoir une nouvelle règle d'affichage** avec le client et le développeur (sur Opinel : image derrière le header, premier écran 100 % illustration, texte au défilement). Dans ce cas, tout format annoncé reste une proposition tant que le développeur n'a pas validé : ne jamais transmettre de dimensions en pixels au client ou à l'illustrateur avant (voir « Communication » plus bas).

Présenter viewports et hypothèses comme des estimations. Signaler les problèmes découverts (texte sous la ligne de flottaison, image servie trop petite) plutôt que de les contourner en silence.

## Étape 0 : cadrer

Récupérer dans la conversation ce qui est déjà donné, puis poser le reste avec l'outil de questions à choix de la surface (`ask_user_input_v0` en chat, `AskUserQuestion` dans Cowork ou Claude Code ; trois questions au maximum par appel), à défaut en texte, questions numérotées avec une valeur par défaut chacune :

- URL de la page en ligne concernée (si elle existe) ;
- lien Figma de la cover dans la maquette (nœud précis) ;
- pays cible des statistiques (par défaut : pays du client) ;
- périmètre : desktop, mobile ou les deux (par défaut : les deux) ;
- **emplacement du gabarit, à demander à chaque fois** : nouvelle page dans le fichier client, ou nouveau fichier dédié à partager avec l'illustrateur ;
- si la règle d'affichage peut évoluer : l'image passe-t-elle derrière le header ? le premier écran doit-il être 100 % illustration ? le texte est-il posé sur l'image ou dessous, sur fond uni (en paysage et en portrait) ? Ces trois réponses changent les ratios des masters (voir `assets/opinel-regles-validees-2026.md`).

## Étape 1 : formats

Rechercher les résolutions desktop et mobile les plus utilisées du pays, pour l'année en cours, avec source et date. Convertir chaque écran en viewport estimé. Détails, repères et hauteurs d'interface : `references/gabarit-calculs.md` §1 et §2.

## Étape 2 : comportement de la cover

1. Lire la maquette : `get_metadata` et `get_screenshot` sur la cover et sur le header (hauteur, opaque ou superposé, position et taille du bloc texte). Récupérer les nœuds de cadre précis, pas les groupes parents.
2. **Proposer la mesure sur le site en ligne et attendre l'accord explicite** avant d'ouvrir quoi que ce soit. Expliquer en une phrase ce qui sera fait : un onglet dédié, lecture seule des dimensions et styles calculés, onglet fermé ensuite.
3. Si accord et si Claude in Chrome est disponible : suivre `references/gabarit-mesure-site.md` (Claude in Chrome, pas Control Chrome). Mesurer en desktop et en mobile si le périmètre l'inclut.
4. Si refus, site inaccessible ou aucun outil de navigateur disponible : demander le comportement (outil de questions à choix, sinon en texte) (ratio fixe / hauteur de fenêtre moins header, recadrée / hauteur fixe / je ne sais pas). « Je ne sais pas » → hypothèse la plus prudente : hauteur de fenêtre moins header, recadrage centré, et le signaler.
5. **Vérifier l'image réellement servie à chaque palier** : dimensions réelles (`naturalWidth` / `naturalHeight`), poids, et **empreinte du fichier** (le chemin après le nom du préréglage). Deux préréglages différents peuvent servir deux fichiers différents : ne jamais conclure « même image partout » sur le seul nom du préréglage (erreur commise sur Opinel). Relever aussi la largeur de bascule entre image mobile et image desktop (768 px sur Opinel, en largeur et non selon l'orientation).
6. Noter les écarts maquette / production (hauteur de header, contenu du bloc texte) : retenir la valeur la plus contraignante et le dire.

## Étape 3 : calcul

Écrire la configuration JSON (format dans `references/gabarit-calculs.md` §6), choisir le ratio du master (§4), puis lancer :

```bash
python scripts/calcul_zones.py config.json
```

Le ratio du master se choisit par **compromis** entre rognage latéral et perte en bas (`references/gabarit-calculs.md` §4), pas seulement « inférieur au ratio le plus étroit ». Faire un calcul séparé pour le paysage et pour le portrait : ce sont deux masters distincts, l'illustrateur livre deux compositions. Si le script renvoie un avertissement (zone libre < 20 %), le signaler dans la restitution.

## Étape 4 : construction Figma

Lire `figma:figma-use` et `lba-design:figma` (et `figma:figma-create-new-file` si un nouveau fichier a été choisi), puis suivre `references/gabarit-construction-figma.md` :

1. page ou fichier, titres de sections ;
2. master(s) composant(s) avec placeholder quadrillé ;
3. plan de zones sur une instance du master ;
4. un écran par format (barre système en wireframe + header + cover recadrée + bloc texte + flottaison si besoin), par appels de 4 formats ;
5. repères pédagogiques : **aplat sombre sous la ligne de flottaison** (calque à part, masquable), texte réel en police de la maquette par-dessus ;
6. brief illustrateur (étape 5) ;
7. **audit de cohérence scripté** de tous les écrans, légendes et masters (`references/gabarit-construction-figma.md`, « Audit final »), à relancer après chaque changement de règle ;
8. capture de contrôle de la page entière et d'au moins un écran de chaque rangée ; corriger chevauchements et libellés illisibles avant de rendre la main.

Modèle système par défaut : macOS + Safari en desktop (défaut agence ; mentionner que Windows + Chrome serait un peu plus prudent), iOS Safari en mobile sauf si les formats retenus sont majoritairement Android.

## Étape 5 : brief illustrateur (dans le Figma)

Cadre à côté des masters, lisible par quelqu'un qui n'a pas suivi le projet : livrables (dimensions en pixels, sRGB, source HD, deux compositions pensées chacune pour son format), comment l'image s'affiche (quatre phrases), **un plan des zones par master** avec légende de couleurs et valeurs en pixels du fichier livré, règles de composition, mode de vérification. Rubriques minimales :

- **Format** : ratio du master, définition de livraison (minimum et recommandée), comportement de la cover en une phrase, exports web réalisés par l'agence.
- **Règles de composition** : zone libre pour le sujet (en % de la hauteur), zone texte (fond calme et sombre, aucun visage, texte ni détail clé), bandes variables (éléments secondaires), fond perdu (à peindre quand même), marges 5 %, aucun texte ni logo dans l'illustration.
- **Mode d'emploi** : remplacer le remplissage du calque « Illustration » du master, masquer les repères, tous les écrans se mettent à jour.
- **Hypothèses de calcul** : comportement mesuré (avec la date) ou supposé, header retenu, sources des formats, modèle de viewport.

## Étape 6 : restitution

Dans la réponse : lien direct vers la page ou le fichier, ce qui a été construit, les chiffres clés (zone libre, zone texte), puis les points à remonter parmi :

- texte qui passe sous la ligne de flottaison sur certains formats ;
- image servie par le CMS plus petite que la livraison demandée (Retina inutile tant que ce n'est pas corrigé ; arbitrage avec le poids de page, Core Web Vitals et éco-conception) ;
- écarts maquette / production ;
- zone libre trop réduite par le bloc texte ;
- lisibilité du texte blanc sur l'image, à vérifier une fois l'image livrée (voile ou dégradé côté intégration plus sûr qu'une simple consigne) ;
- hypothèses d'interface (Dock, barre de favoris, Windows) et intérêt de données Analytics du client sur la taille des fenêtres (dimension personnalisée nécessaire dans GA4).

## Communication client et développeur

- **Avant validation technique** : un mail client très simple, sans aucune dimension en pixels (principe d'affichage, deux versions, « formats confirmés après validation »).
- **Validation développeur en une seule fois** : dimensions actuelles servies par le CMS, nouveaux ratios, règle de hauteur, position de l'image par rapport au header, ancrage, règle de bascule mobile / desktop (préférer l'orientation à une largeur fixe), hauteurs de header par palier.
- **Après validation** : mail client avec les formats définitifs, puis brief illustrateur. Mettre à jour les descriptions des masters (« Validé par … le … »).

Si l'utilisateur dépose une image dans le master pendant la session, s'en servir pour commenter concrètement ce qui tombe dans la zone texte ou se fait couper.
