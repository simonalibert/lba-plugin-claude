# Mesurer le comportement de la cover sur le site en ligne

Objectif : obtenir les valeurs réelles plutôt que des hypothèses. C'est l'étape qui a le plus changé le résultat sur le projet Opinel : le Figma laissait croire à un ratio fixe, le site faisait en réalité `100vh − header` avec un minimum.

**Toujours proposer la mesure et attendre l'accord de l'utilisateur avant d'ouvrir un onglet.**

## Outil à utiliser

- **Claude in Chrome** (`mcp__claude-in-chrome__*`). C'est l'outil fiable.
- **Control Chrome** (`mcp__Control_Chrome__*`) : `get_current_tab` fonctionne, mais `execute_javascript` échoue en général (« Google Chrome is not running ») car Chrome bloque le JavaScript piloté par AppleScript. Ne pas insister ; au besoin, indiquer à l'utilisateur le réglage Chrome « Affichage > Options pour les développeurs > Autoriser JavaScript à partir des Apple Events ».

Séquence :

1. `tabs_context_mcp` avec `createIfEmpty: true` (l'onglet ouvert par l'utilisateur n'est pas dans le groupe MCP, c'est normal).
2. `navigate` vers l'URL de la page.
3. **Premier `javascript_tool` en appel isolé**, pas dans `browser_batch` : le premier accès à un domaine déclenche une demande de permission qui échoue dans un batch.
4. Mesures (scripts ci-dessous).
5. `tabs_close_mcp` à la fin. Ne jamais laisser l'onglet ouvert.

## Script 1 : repérer la cover et ses règles

À lancer dans la fenêtre à sa taille courante.

```js
await new Promise(r => setTimeout(r, 2500));
const vw = innerWidth, vh = innerHeight;
const out = { vw, vh, dpr: devicePixelRatio, cands: [] };
const hd = document.querySelector('header');
if (hd) { const r = hd.getBoundingClientRect(); out.header = { h: Math.round(r.height), pos: getComputedStyle(hd).position }; }
document.querySelectorAll('img,video,picture,div,section').forEach(el => {
  const r = el.getBoundingClientRect(), cs = getComputedStyle(el);
  const media = el.tagName === 'IMG' || el.tagName === 'VIDEO' || (cs.backgroundImage && cs.backgroundImage !== 'none');
  if (!media || r.width < vw * 0.9 || r.height < 150 || r.top > vh + 200) return;
  const p = el.parentElement, pc = getComputedStyle(p);
  out.cands.push({
    tag: el.tagName, cls: String(el.className || '').slice(0, 100),
    top: Math.round(r.top + scrollY), w: Math.round(r.width), h: Math.round(r.height),
    fit: cs.objectFit, pos: cs.objectPosition, bgSize: cs.backgroundSize, bgPos: cs.backgroundPosition,
    minH: cs.minHeight, maxH: cs.maxHeight, aspect: cs.aspectRatio,
    nat: el.naturalWidth ? el.naturalWidth + 'x' + el.naturalHeight : null,
    src: (el.currentSrc || cs.backgroundImage || '').slice(0, 160),
    parent: { cls: String(p.className || '').slice(0, 100), h: Math.round(p.getBoundingClientRect().height), minH: pc.minHeight, maxH: pc.maxHeight, aspect: pc.aspectRatio }
  });
});
JSON.stringify(out);
```

## Script 2 : textes superposés à la cover

Remplacer `SEL` par le sélecteur trouvé au script 1.

```js
const s = document.querySelector('SEL'), sr = s.getBoundingClientRect();
JSON.stringify([...s.querySelectorAll('*')]
  .filter(e => e.children.length === 0 && e.textContent.trim().length > 2 && e.getBoundingClientRect().width > 0)
  .map(e => { const r = e.getBoundingClientRect(), cs = getComputedStyle(e);
    return { tag: e.tagName, txt: e.textContent.trim().slice(0, 60), left: Math.round(r.left - sr.left),
      bottomGap: Math.round(sr.bottom - r.bottom), w: Math.round(r.width), h: Math.round(r.height),
      fs: cs.fontSize, ff: cs.fontFamily.slice(0, 40) }; }));
```

Attention : un `h1` de 1 px de large est un titre masqué pour le SEO, pas le texte visible. Se baser sur les éléments visibles.

## Script 3 : déduire la règle de hauteur

Les feuilles de style sur CDN sont souvent illisibles (`cssRules` bloqué par CORS). Il faut donc mesurer la cover à plusieurs tailles de fenêtre et en déduire la règle.

Méthode préférée : **iframe de même origine**, qui permet n'importe quelle taille, y compris mobile, sans redimensionner la fenêtre. Méthode validée sur Opinel (même résultat que la mesure directe à la taille de la fenêtre). Garder le contrôle : une première mesure à la taille courante, comparée au script 1.

```js
async function mesure(w, h, sel) {
  const f = document.createElement('iframe');
  f.style.cssText = `position:fixed;left:0;top:0;width:${w}px;height:${h}px;border:0;z-index:-1;opacity:0`;
  f.src = location.href; document.body.appendChild(f);
  await new Promise(r => f.onload = r); await new Promise(r => setTimeout(r, 2000));
  const d = f.contentDocument, s = d.querySelector(sel), cs = f.contentWindow.getComputedStyle(s);
  const hd = d.querySelector('header');
  const res = { w, h, cover: Math.round(s.getBoundingClientRect().height),
    header: hd ? Math.round(hd.getBoundingClientRect().height) : null,
    minH: cs.minHeight, maxH: cs.maxHeight, bgPos: cs.backgroundPosition, pos: cs.objectPosition };
  f.remove(); return res;
}
const r = [];
for (const [w, h] of [[1280, 600], [1440, 780], [1920, 960], [1920, 1300], [390, 700], [390, 844]]) r.push(await mesure(w, h, 'SEL'));
JSON.stringify(r);
```

Si l'iframe est refusée (`X-Frame-Options: DENY`, contenu vide), repli sur `resize_window` : le redimensionnement agit sur la taille extérieure de la fenêtre, lire `innerWidth`/`innerHeight` après chaque changement. Chrome desktop ne descend pas sous environ 500 px de large : pour le mobile, demander alors à l'utilisateur une capture en mode appareil des outils de développement.

Lecture des résultats :

- hauteur qui suit `vh − header` → mode `viewport` avec `offset` = header ;
- hauteur qui cesse de baisser en dessous d'un seuil → `min_height` ;
- hauteur proportionnelle à la largeur → `fixed_ratio` ;
- hauteur constante → `fixed_height` ;
- `min-height`/`max-height` calculés sont parfois directement lisibles sur l'élément : les utiliser s'ils sont renseignés.

Sur mobile, vérifier si la hauteur utilise `vh`, `svh`, `lvh` ou `dvh` : sur iOS, `100vh` vaut la hauteur barres rétractées, donc la cover est plus haute que la zone visible au chargement.

## À relever systématiquement

- Header : hauteur, `position` (fixe ou dans le flux), opaque ou superposé à l'image.
- Cover : règle de hauteur, min, max, `background-size` / `object-fit`, ancrage (`background-position` / `object-position`).
- Texte : position (gauche, écart au bas), hauteur, largeur, taille de police.
- **Image servie** : largeur réelle du fichier (`naturalWidth` ou nom du fichier de cache, ex. `cms_hp_banner_1920`). Si le CMS sert une version plus petite que la livraison demandée, le signaler.
- Écarts avec la maquette Figma (hauteur de header, contenu texte).

## Script 4 : image réellement servie

Pour chaque palier (via l'iframe), lire l'URL de l'image, puis ses dimensions et son poids. Comparer l'empreinte du fichier (segments après le nom du préréglage) : deux préréglages peuvent servir deux fichiers différents.

```js
const u = 'URL_DE_L_IMAGE';
const d = await new Promise(r => { const i = new Image(); i.onload = () => r([i.naturalWidth, i.naturalHeight]); i.onerror = () => r(null); i.src = u; });
const ko = Math.round((await (await fetch(u)).blob()).size / 1024);
JSON.stringify({ u, d, ko });
```

Balayer ensuite quelques largeurs autour des paliers probables (600, 768, 769, 800, 1024 px, en portrait et en paysage) pour trouver la règle de bascule entre image mobile et image desktop. `web_fetch` ne lit pas les images : passer par le navigateur.

## Modèles d'appareils par résolution

Pour nommer les modèles en face de chaque format : base ouverte de viewport-tester.com, clonable depuis la sandbox (`git clone https://github.com/bitcomplete/labs-viewports`, fichier `items.json`, champs `properties.viewport` et `labels.primary`). Marquer « estimation » les formats sans correspondance, ou qui désignent une famille d'appareils (PC Windows, tablettes Android).
