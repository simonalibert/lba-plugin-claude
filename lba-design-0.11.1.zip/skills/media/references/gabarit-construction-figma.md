# Construction du gabarit dans Figma

Prérequis : lire `figma:figma-use` et `lba-design:figma` avant tout `use_figma`, et passer `skillNames: "figma-use"`. Travailler par appels courts (4 formats maximum par appel), vérifier par capture après chaque étape.

## Structure de page

Une page (ou un fichier) nommée « Gabarit illustration [nom de la cover] » :

```
Titre de page
① Master (à éditer)          ② Zones de sécurité (lecture seule)          Cahier des charges
[composant master]           [instance + calque Overlays verrouillé]      [cadre auto-layout]
                             [barres de recadrage par format à droite]

③ Rendu par écran (instances du Master)
[Écran A] [Écran B] [Écran C] [Écran D]      ← rangée desktop
[Écran E] [Écran F] [Écran G] [Écran H]
④ Mobile (si demandé) : même principe, master mobile séparé
```

Espacements : 240 px entre écrans, au moins 400 px entre rangées, légende de chaque écran 56 px au-dessus du cadre. Quand un bloc s'élargit (master qui change de ratio, barres ajoutées à droite), décaler les blocs voisins : vérifier les chevauchements sur une capture de la page entière.

## Master (composant)

- `createComponent()`, taille = ratio choisi (ex. 1920 × 960), `clipsContent = true`.
- Enfant 1 : rectangle « Illustration (dépose ton image ici) », dégradé neutre en attendant, contraintes `SCALE` / `SCALE`.
- Enfant 2 : cadre « Repères placeholder (à masquer) » (grille 12 × 8 + cercle central), tous les enfants en `SCALE`.
- Description du composant : ratio, définition de livraison, mode d'emploi (remplacer le remplissage, mode Fill ; tout calque ajouté en contraintes Scale).

Les instances sont redimensionnées avec `instance.resize()` ; grâce aux contraintes `SCALE`, le contenu suit. Un remplissage image en mode `FILL` se recadre proprement.

## Gabarit par écran (code type)

Chaque écran = un cadre parent « Écran L × H » sans fond, qui contient la barre système et le gabarit. **Ne pas laisser la barre et le gabarit au premier niveau** : Figma affiche le nom de chaque cadre de premier niveau sur le canevas, et ces noms chevauchent les légendes et les barres.

```js
// Constantes issues de calcul_zones.py / mesure-site.md
const HEADER = 210, MINH = 560, MW = 1920, MH = 960, AX = 0.5, AY = 0.3, TOP_BAR = 117;
const blue = {r:0,g:0.208,b:0.404}, red = {r:0.85,g:0.15,b:0.15}, white = {r:1,g:1,b:1};

function buildGabarit(comp, w, vh) {
  const cH = Math.max(vh - HEADER, MINH), total = Math.max(vh, HEADER + cH);
  const fr = figma.createFrame(); fr.name = `Gabarit ${w}`; fr.resize(w, total); fr.clipsContent = true;
  fr.fills = [{type:'SOLID', color:{r:0.97,g:0.97,b:0.97}}];
  const hd = figma.createRectangle(); hd.name = `Header (${HEADER} px)`; hd.resize(w, HEADER);
  hd.fills = [{type:'SOLID', color: blue}]; fr.appendChild(hd);
  const cv = figma.createFrame(); cv.name = `Cover ${w} × ${cH}`; cv.resize(w, cH); cv.y = HEADER;
  cv.clipsContent = true; cv.fills = []; fr.appendChild(cv);
  const s = Math.max(w / MW, cH / MH), inst = comp.createInstance(); cv.appendChild(inst);
  inst.resize(MW * s, MH * s); inst.x = (w - MW * s) * AX; inst.y = (cH - MH * s) * AY;
  // blocs texte ancrés au bas de la cover : rectangles rouges pointillés, 18 % d'opacité
  // si HEADER + cH > vh : voile noir 45 % sous vh + ligne rouge 4 px à vh, AJOUTÉE EN DERNIER
  return fr;
}
```

Pour un comportement `fixed_ratio`, remplacer le calcul : `cH = w / ratio`, instance à `w × cH`, pas de décalage.

## Barres système en wireframe

Gris neutres, jamais de couleur : elles ne doivent pas concurrencer l'illustration. Libellé avec la hauteur retirée dans chaque barre.

- macOS + Safari (défaut desktop) : barre de menus 37 px gris 93 % + libellé ; barre Safari 80 px gris 97 % avec 3 pastilles grises 12 px et une barre d'adresse arrondie centrée (50 % de la largeur) ; mention « Dock masqué ». Placée au-dessus du gabarit dans le cadre parent.
- Windows + Chrome (variante) : bande d'onglets gris 87 % avec un onglet blanc, barre d'outils blanche avec barre d'adresse en pilule ; barre des tâches 48 px en bas, **posée à la ligne de flottaison**, avec des carrés gris centrés.
- iOS Safari : barre d'état en haut (heure, icônes en gris), barre d'adresse et d'onglets en bas, au niveau de la flottaison.
- Android Chrome : barre d'état et barre d'adresse en haut, barre de navigation en bas.

Pour élargir une barre clonée : les enfants ne s'étirent pas (contraintes par défaut `MIN`), redimensionner et repositionner chaque enfant à la main.

## Plan de zones (② Zones de sécurité)

Cadre de la taille du master, contenant une instance puis un cadre « Overlays (verrouillé) » :

- fond perdu : noir 55 % ;
- bandes variables : bleu marque 22 % ;
- zone toujours visible : contour vert 3 px ;
- zone libre pour le sujet : vert 14 % + libellé ;
- zone texte : rouge 16 %, contour pointillé + libellé ;
- marges 5 % : filets rouges verticaux ;
- à droite, hors du cadre : une barre bleue par format montrant la partie verticale visible, nom du format en dessous, légende.

Verrouiller le calque Overlays (`locked = true`), le déverrouiller avant toute retouche.

## Pièges rencontrés

- **Libellés illisibles sur image** : mettre un fond blanc 88 à 90 % derrière chaque libellé des overlays (rectangle inséré juste sous le texte, 8 px de marge, rayon 4).
- **Libellés de flottaison qui se chevauchent** : quand deux lignes sont à moins de 26 px, décaler le libellé dans une autre colonne (x − 390 px).
- **Ligne de flottaison masquée** par une barre des tâches ou un voile : la réinsérer au premier plan (`fr.appendChild(ligne)`).
- **Libellé de flottaison sur la zone texte** : le placer juste sous la ligne (y + 6), police 16.
- **Capture de contrôle** : `node.screenshot()` appelé plusieurs fois dans un même script ne renvoie parfois que la dernière image. Préférer `get_screenshot` sur le cadre parent « Écran … ».
- **`get_metadata` sans nodeId** peut lister moins de pages que le fichier n'en contient (décalage de synchronisation). Se fier à `figma.root.children` via `use_figma`.
- **Sélection de l'utilisateur** : `figma.currentPage.selection` via `use_figma` peut être vide ; `get_metadata` sur un nœud renvoie en tête la sélection réelle (« Currently selected nodes »). Utile quand l'utilisateur dit « base-toi sur celui-là ».
- **L'utilisateur peut remplacer l'image du master pendant la session** : c'est le but. S'en servir pour commenter le rendu (éléments qui tombent dans la zone texte ou sont coupés).
- **Changer le ratio du master** après coup : `comp.resize()` suffit (contraintes Scale), mais il faut ensuite reconstruire les gabarits (le recadrage dépend du ratio) et le plan de zones.

## Pièges supplémentaires (projet Opinel)

- **Caractères encodés dans les chaînes** : apostrophes et chevrons écrits dans le code peuvent être enregistrés en `&#39;` ou `&amp;gt;` (vu dans des descriptions de composants). Utiliser l'apostrophe typographique `\u2019`, éviter `>` et `&` dans les textes, et relire les descriptions après écriture.
- **`findAll` par nom supprime aussi les textes** : un calque texte porte par défaut son contenu comme nom. Filtrer sur le type autant que sur le nom avant de supprimer.
- **`setPluginData` n'est pas disponible** dans ce runtime : utiliser `setSharedPluginData` ou, plus simple, retrouver les nœuds par nom.
- **L'utilisateur réorganise le fichier** (sections, suppressions, déplacements) : retrouver les nœuds par nom et par structure plutôt que par identifiant mémorisé, et ne pas recréer en silence un élément qu'il a supprimé.
- **Cadre de sélection de l'instance** : avec un ancrage à 30 %, l'instance déborde au-dessus de la cover (masquée par le cadre). L'utilisateur peut croire que l'image commence au mauvais endroit : l'expliquer avec les positions mesurées.
- **Noms de cadres** : garder la résolution d'écran en tête et ajouter la taille réelle quand le cadre montre le défilement (« Écran 800 × 1280 · cadre 800 × 1600 (inclut le scroll) ») ; relancer le renommage après chaque changement de hauteur.
- **Légendes** : largeur fixe (celle de l'écran, 380 px minimum) et bas ancré au-dessus du cadre ; format unique « image L × H (r : 1), dont N sous le header ».
- **Sections** : après agrandissement des écrans, réajuster la hauteur des sections à leur contenu et les réempiler (300 px d'écart).

## Repères pédagogiques

- **Aplat sous la flottaison** : rectangle anthracite dans la cover, juste au-dessus de l'instance et sous le bloc texte, de la ligne de flottaison au bas de l'image. Il montre ce qui n'apparaît qu'au défilement ; le laisser masquable.
- **Fond uni sous l'image** (règle portrait) : cadre « Fond uni · titre + description (couleur à définir) » posé à la flottaison, texte à 40 px des bords.
- Header opaque au premier plan, libellé « l'image démarre dessous ».

## Audit final

Script qui parcourt tous les cadres « Écran … » et vérifie, pour chacun : position de la ligne de flottaison selon les barres système ; image en haut de page et header au-dessus ; bon master selon l'orientation ; instance à l'échelle, ancrée en haut et centrée ; écart de 40 px entre flottaison et texte ; marge basse ; aplat ou fond uni selon la règle ; section suivante et hauteur du cadre ; nom du cadre ; chiffres de la légende (viewport, image, ratio, hauteur de header) ; absence de calques masqués ; descriptions des masters propres. Ne rendre la main qu'avec zéro écart, puis recalculer les zones des plans à partir des écrans réels, pas des valeurs théoriques.
