# Parcours A : inventaire des médias d'un site

Parcours du skill `lba-design:media`. Tronc commun (principe directeur, statuts, habillage) : voir le SKILL.md.

## Méthode en 6 étapes

**1. Chercher l'existant avant de recompter.** Chercher dans les conversations passées et les fichiers fournis (et dans Google Drive seulement si la personne le propose ou l'accepte, jamais par défaut) si un inventaire médias a déjà été fait, même partiel. La recherche de conversations ne couvre que le projet Claude courant : si rien n'est trouvé, le dire comme une limite de la recherche, pas comme une absence avérée. Un travail antérieur se cite, se corrige et s'étend.

**2. Vérifier l'état réel du design system, pas la mémoire qu'on en a.** Si le projet a un fichier Figma, appeler `get_metadata` sur les pages de travail pour voir quelles frames sont réellement construites, avec quels composants, à quelles dimensions. Un gabarit "prévu" dans un cahier des charges mais absent du fichier de travail n'est pas un gabarit construit : le dire.

**3. Réutiliser les ratios déjà tokenisés, ne pas en inventer.** Si le design system documente déjà des ratios médias (souvent dans un fichier type DESIGN.md ou une collection de variables Figma "Ratios"), les reprendre tels quels. Ne calculer un nouveau ratio que pour un usage réellement non couvert, et le signaler comme un trou à trancher plutôt que de le résoudre soi-même par défaut.

**4. Construire l'inventaire gabarit par gabarit, pas type de média par type de média.** Pour chaque page/gabarit : lister composant → type de média → ratio → quantité → source recommandée (interne / banque / production sur mesure / fourni par un tiers) → statut (vérifié/estimé). Repérer les cas d'assets tiers (logos de marques, logos de chaînes, contenus fournis par un partenaire) : ils ont un délai d'obtention différent d'un shooting, à signaler séparément.

**5. Chercher les mutualisations avant de sommer.** Un carrousel d'actualités affiché sur 4 pages ne nécessite pas 4 jeux de photos si c'est le même flux. Une photo d'agence utilisée sur une page peut être réutilisée sur une autre. Sommer sans vérifier la mutualisation gonfle artificiellement le budget.

**6. Si le projet a plusieurs cibles/profils (B2C, B2B, collectivités...), donner un ordre de grandeur par cible, pas seulement un total.** Chiffrer précisément les cibles dont le design system est construit ; pour les cibles dont seule une maquette avant-vente ou un wireframe existe, extrapoler à partir du volume de pages connu et de la densité média observée sur les pages comparables déjà construites, en marquant clairement "estimé, fiabilité faible" plutôt que de présenter un chiffre au même niveau de confiance que les cibles vérifiées.

## Les deux nomenclatures

Toujours proposer deux conventions de nommage distinctes, jamais une seule qui essaie de servir les deux usages :

- **Nomenclature technique** (bibliothèque de production/masters) : porte le gabarit, le composant, le ratio. Sert à retrouver un fichier sans rouvrir l'outil de design. Exemple : `[gabarit]_[composant]_[ratio]_[variante].[ext]`
- **Nomenclature SEO** (fichier publié + attribut alt) : mots-clés métier et géographiques, minuscules, tirets, sans accents, **sans aucune information technique** (ni ratio, ni dimension, ni nom de composant : ça n'apporte rien à un moteur de recherche et alourdit le nom). Exemple : `[mots-clés]-[cible-ou-lieu]-[variante].[ext]`

Recommander une table de correspondance entre les deux plutôt que de dériver l'un de l'autre automatiquement.

## Deux livrables, pas un seul

**Doc interne (agence)** : détail complet gabarit par gabarit, statuts vérifié/estimé, écarts constatés entre la doc et l'état réel du fichier, points de vigilance techniques. C'est la source de vérité : exhaustif sur les données, mais concis dans la rédaction (tableaux plutôt que prose, pas de justification répétée).

**Doc client** : 3 informations et rien de plus. Combien (ordre de grandeur par cible), quel format (table ratio → dimensions à livrer), quoi trancher avant de lancer une commande ou un shooting (liste courte à puces). Pas de statuts internes, pas de références à l'outil de design, pas de justification méthodologique en plusieurs paragraphes. Une table + quatre puces valent mieux qu'une page de prose pour ce public. Si le client veut le détail, le doc interne existe déjà.

## Pièges à éviter

- Confondre "ratio documenté" et "ratio effectivement appliqué" : toujours vérifier qu'un composant réel respecte le ratio qu'on lui attribue (un hero à 1440×752 n'est pas un vrai 2:1, même si c'est ce qui est écrit dans la doc).
- Compter les assets tiers (logos fournis par des partenaires/diffuseurs) comme des photos à produire : ce sont deux chaînes d'approvisionnement différentes, à ne pas mélanger dans le même total ni le même planning.
- Donner un chiffrage plat, un seul total, sans dire quelle part est vérifiée et quelle part est extrapolée.
