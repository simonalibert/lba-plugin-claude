# Formats, viewports et calcul des zones

## 1. Choisir les formats

Source : StatCounter pour le pays du client (`gs.statcounter.com/screen-resolution-stats/desktop/<pays>` et `/mobile/<pays>`). Les pages StatCounter sont peu lisibles en fetch ; les articles qui reprennent les chiffres (ex. Leptidigital pour la France) sont plus exploitables. Toujours chercher les chiffres de l'année en cours et citer la source avec sa date. Si le client a des données Analytics, elles priment sur les statistiques nationales.

Retenir :

- desktop : les 6 premières résolutions du pays, + le format de la maquette Figma s'il n'y figure pas, + 2560 × 1440 pour les grands écrans ;
- mobile : les 5 ou 6 premières résolutions du pays (en CSS px, portrait).

Repères France, à revérifier à chaque projet (desktop : StatCounter via Leptidigital, janvier 2026 ; mobile et tablette : StatCounter, août 2026) :

- desktop : 1920 × 1080 (25,97 %), 1536 × 864 (10,52 %), 1366 × 768 (5,6 %), 1600 × 900 (5,5 %), 1280 × 720 (4,57 %), 1440 × 900 (4,42 %) ;
- mobile : 414 × 896 (15,12 %), 390 × 844 (10,6 %), 384 × 832 (7,52 %), 393 × 873 (7,29 %), 360 × 800 (6,11 %), 360 × 780 (5,85 %) ;
- tablette : 800 × 1280 (12,36 %), 1280 × 800 (10,94 %), 768 × 1024 (10,53 %), 810 × 1080 (4,27 %), 1334 × 800 (2,94 %), 800 × 1334 (2,59 %). Prévoir les deux orientations.

## 2. Écran → viewport

Les statistiques donnent la taille d'écran, pas la zone d'affichage de la page. Retirer l'interface système et navigateur. Ces valeurs sont des estimations à présenter comme telles.

Desktop (hauteur à retirer) :

- macOS + Safari : barre de menus 37 px + barre Safari 80 px = **117 px**, Dock masqué (modèle par défaut retenu avec Simon). Sur un écran externe sans encoche, la barre de menus fait environ 25 px.
- Windows + Chrome : barre des tâches 48 px + onglets et barre d'adresse 72 à 86 px = environ **130 px**. Plus prudent. Le mentionner comme variante (la flottaison serait 13 à 17 px plus haute).
- Barre de favoris affichée : environ 30 px de plus.

Mobile portrait (hauteur à retirer au chargement, barres déployées) :

- iOS Safari : barre d'état 47 à 59 px + barre d'onglets et d'adresse en bas environ 83 px = environ **140 px** ;
- Android Chrome : barre d'état 24 à 32 px + barre d'adresse 56 px + barre de navigation 16 à 48 px = environ **110 px**.

Choisir un modèle mobile par défaut selon la cible (iOS si la part iPhone est majoritaire dans les formats retenus) et le noter dans le cahier des charges.

## 3. Hauteur de cover selon le comportement mesuré

Modes pris en charge par `scripts/calcul_zones.py` :

- `fixed_ratio` : hauteur = largeur / ratio. Pas de recadrage, seule la ligne de flottaison varie.
- `viewport` : hauteur = `vh × vh_factor − offset`, bornée par `min_height` / `max_height`. Recadrage selon le ratio de chaque écran.
- `fixed_height` : hauteur constante, bornée idem. Recadrage selon la largeur.

Recadrage `cover` : l'image est mise à l'échelle `s = max(largeur_cover / largeur_master, hauteur_cover / hauteur_master)`, puis décalée selon l'ancrage `[ax, ay]` (ex. `[0.5, 0.3]` pour `background-position: 50% 30%`).

## 4. Ratio du master

Le ratio se choisit par **compromis** entre deux pertes, avec un ancrage en haut et `background-size: cover` :

- un master **plus panoramique** qu'une image affichée est mis à l'échelle en hauteur et **rogné sur les côtés** : perte par côté = (1 − r_écran / r_master) / 2 ;
- un master **moins panoramique** remplit la largeur et est **coupé en bas** : perte = 1 − r_master / r_écran.

Méthode : relever les ratios des images affichées (le plus étroit r_min, le plus large r_max), puis comparer quelques ratios simples (5 : 4, 4 : 3, 3 : 2, 16 : 9, 9 : 16, 3 : 5, 1 : 2…) avec `python scripts/calcul_zones.py --compromis r_min r_max`. Retenir celui qui minimise la plus grande des deux pertes, avec un rognage latéral proche de la marge de confort de 5 %. Exemple Opinel paysage : ratios 1,31 à 1,59 → 3 : 2 (6,4 % par côté au pire, 5,4 % en bas au pire), préféré au 5 : 4 (21 % perdus en bas) et au 16 : 9 (13 % par côté).

Si l'écart entre r_min et r_max est trop grand pour un seul master (par exemple téléphones à 0,39 et tablettes à 0,69), c'est le signe d'une règle d'affichage mal adaptée : en portrait, un texte long posé sur l'image étire les covers. Proposer de sortir le texte de l'image (fond uni dessous) plutôt que d'imposer un format étiré comme le 2 : 5.

En mode `fixed_ratio`, le master prend simplement le ratio de la cover. Vérifier aussi le format réellement servi par le CMS : un préréglage qui recadre à l'import (ex. 1920 × 650) impose son ratio tant que le développeur ne le change pas.

Définition de livraison : largeur de cover la plus grande × 2 (Retina), plafonnée à 3840 px en paysage ; en portrait, largeur × 3 pour les téléphones, × 2 pour les tablettes.

### Règles « premier écran 100 % illustration »

- **Texte sous la flottaison, sur l'image** : hauteur de l'image = premier écran visible sous le header + 40 px + bloc texte + marge basse (67 px desktop, 60 px tablette).
- **Image derrière le header** : ajouter la hauteur du header à celle de l'image ; le haut du master est masqué sur la hauteur header / échelle (fond perdu).
- **Texte sous l'image, sur fond uni** : hauteur de l'image = du haut de la page jusqu'à la ligne de flottaison ; le texte n'impose plus rien à l'image.

## 5. Zones

Toutes en coordonnées du master, calculées par le script :

- **fond perdu** : hors de l'union des recadrages. Jamais visible sur les formats testés, mais à peindre (fenêtres plus hautes ou plus larges) ;
- **bandes variables** : dans l'union mais hors de l'intersection. Visibles selon le format, éléments secondaires ;
- **zone toujours visible** : intersection des recadrages ;
- **zone texte** : union des emprises du bloc texte, qui reste ancré au bas de chaque recadrage (et non au bas du master) ;
- **zone libre pour le sujet** : de l'intersection haute jusqu'au haut de la zone texte ;
- **marges latérales** : 5 % de chaque côté, par confort, même sans recadrage latéral.

Si la zone libre fait moins de 20 % de la hauteur, le script lève un avertissement : le signaler, c'est souvent le signe qu'il faut discuter du bloc texte (taille, position, présence du chapô) plutôt que de contraindre l'illustration.

Si la cover dépasse le viewport (minimum de hauteur atteint, ou ratio fixe haut), calculer aussi la ligne de flottaison (`fold_in_cover` dans le script) et vérifier si le texte passe dessous.

## 6. Format du fichier de configuration

```json
{
  "master": {"w": 1920, "h": 960},
  "header_h": 210,
  "behavior": {"mode": "viewport", "offset": 210, "min_height": 560, "anchor": [0.5, 0.3]},
  "text": {"left": 56, "max_w": 1187, "bottom_offset_top": 251, "bottom_offset_bottom": 67},
  "formats": [{"screen_w": 1920, "screen_h": 1080, "viewport_w": 1920, "viewport_h": 963, "label": "25,97 % (FR)"}]
}
```

`text.bottom_offset_top` / `bottom_offset_bottom` : distances en CSS px entre le bas de la cover et le haut / le bas du bloc texte. `max_w` : largeur maximale du bloc ; le script la limite à `viewport − 2 × left`.

Exemple complet : `assets/exemple-opinel-desktop.json`.
