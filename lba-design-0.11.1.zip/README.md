# lba-design

Méthode design de La Bonne Agence pour les profils UX, UI, DA et dev front, en douze skills, dans l'ordre d'un projet. Les noms des skills sont en anglais, leur contenu en français.

| Étape | Skill | Rôle |
|---|---|---|
| Socle | `principles` | Règles communes, écrites une seule fois : statuts, conformité, seuils, typographie, données |
| Comprendre | `research` | Préparer entretiens, ateliers, tri de cartes, tests, questionnaires |
| | `synthesis` | Analyser le matériau, diagnostic de refonte, implications pour l'arborescence |
| Concevoir | `wireframe` | Arborescence, zoning, wireframes mobile first, contrat de structure |
| | `ui-design` | Du brief à la haute fidélité livrée : cadrage, direction et pistes, typographie et couleur, écrans, passe qualité (HTML, Claude Design ou Figma) |
| | `motion` | Interactions et animations web (GSAP, Lenis) : socle, recettes, pièges connus |
| | `microcopy` | Textes d'interface en français |
| | `accessibility` | Pré-évaluer l'accessibilité d'une maquette (RGAA 4.1, WCAG) |
| Livrer | `handoff` | DESIGN.md, spec d'écran, annotations, tokens DTCG |
| | `media` | Inventaire des visuels d'un site, et gabarit d'une cover à commander |
| Boucle | `feedback` | Retour d'usage du plugin en fin de session : dire « retour LBA » (ou `/retour` dans Cowork et Claude Code) |
| Outils | `figma` | Écrire dans un fichier Figma existant sans le casser |

**Prérequis** : connecteur Figma (et plugin Figma pour `figma:figma-use`) pour `accessibility`, `figma`, `handoff`, `media` ; Claude in Chrome recommandé pour le gabarit de cover ; Python 3 et Playwright pour le script de contrôle de `ui-design` ; GSAP et Lenis dans le projet pour `motion`.

**Cohabitation** : ne pas activer en parallèle le plugin « Design » d'Anthropic, dont plusieurs skills recouvrent ceux-ci (audit a11y, handoff, rédaction, recherche) et se déclencheraient sur les mêmes demandes.

**Architecture.** Chaque skill suit le même gabarit d'écriture (`principles` §9) : une ligne de préséance (quelle source l'emporte), un renvoi aux invariants de `principles` plutôt qu'une copie, un déroulé qui dit quelle référence lire à chaque étape, ses règles propres, des défauts maison accompagnés de leur raison, et des anti-défauts qui disent quoi faire à la place. Le `SKILL.md` reste court ; les méthodes longues vivent dans `references/`.

**Préséance générale** : invariants > demande > décisions validées > design system ou charte du client > standards LBA > défauts maison (`principles` §10). Profils de projet (standard, vitrine expressive, conformité RGAA, éco-conçu, combinables), déclarés dans la fiche projet : `principles` §11. Dépendances à Claude et disponibilité par surface : `EXECUTION.md`. Évaluations et protocole de test : `EVALS.md`.

Décisions de conception et leur raison : `DECISIONS.md`, à lire avant toute modification.

Licence et attributions : voir `NOTICE`.
