---
description: 'ui-design-vocabulaire-aerer'
tags: ['ui-design', 'comportement']
max_turns: 12
timeout_seconds: 600
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

Sur la maquette de la page d'accueil de la coopérative, la section « Nos producteurs » est trop tassée. Tu peux l'aérer ? Donne-moi le CSS modifié.

```css
:root { --space-2: 8px; --space-3: 16px; --space-4: 24px; --space-5: 32px; --space-6: 48px; --space-7: 64px; --space-8: 96px;
        --text-body: 18px; --text-h2: 32px; --brand: #2f5d3a; --text: #1a1a1a; }
.producteurs { padding: var(--space-5) 0; background: #f4f1ea; }
.producteurs h2 { font-size: var(--text-h2); margin-bottom: var(--space-2); color: var(--brand); }
.producteurs .grille { display: grid; grid-template-columns: repeat(3, 1fr); gap: var(--space-3); }
.producteurs .carte { padding: var(--space-3); }
.producteurs .carte p { font-size: var(--text-body); line-height: 1.4; }
```
