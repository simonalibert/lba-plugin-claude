---
type: 'tool_used'
tool: 'Read'
input_match: 'vocabulaire\.md'
---
