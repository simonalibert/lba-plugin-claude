---
type: 'regex'
pattern: 'var\(--space-[5-8]\)'
flags: 'i'
---
