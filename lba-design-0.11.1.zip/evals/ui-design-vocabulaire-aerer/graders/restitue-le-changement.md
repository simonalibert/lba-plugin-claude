---
type: 'llm'
---

PASS si la réponse dit explicitement, en une ou quelques lignes, ce qui a changé (quels espacements, de quelle valeur à quelle valeur ou de quel token à quel token). FAIL si elle livre le CSS sans dire ce qui a changé.
