---
type: 'llm'
---

PASS si le CSS proposé augmente des espacements (padding de section, marges, gap ou interlignage) en utilisant les variables --space-* existantes, sans réduire ni augmenter la taille des textes (--text-body, --text-h2) et sans changer les couleurs. FAIL si une taille de texte ou une couleur change, ou si des valeurs en pixels écrites à la main remplacent les variables.
