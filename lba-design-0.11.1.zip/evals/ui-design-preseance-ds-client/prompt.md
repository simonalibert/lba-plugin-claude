---
description: 'ui-design-preseance-ds-client'
tags: ['ui-design', 'comportement']
max_turns: 30
timeout_seconds: 900
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill', 'Write', 'Edit', 'Bash', 'TodoWrite']
---

Fais-moi la page d'accueil de la coopérative dans `accueil.html`. Leur design system est dans DESIGN-client.md (dossier de travail).
