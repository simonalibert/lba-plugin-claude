#!/usr/bin/env bash
# Recreates this case's input files in the run's empty workspace (needs --scaffold).
set -euo pipefail
cat > 'DESIGN-client.md' <<'LBA_FIXTURE_EOF'
# DESIGN.md : Coopérative des Menuisiers du Vercors

**Mise à jour du 02/10/2026** : boutons et typographie validés par la direction de la coopérative.

## 3. Fondations techniques

- **Profil du projet** : standard
- **Breakpoints** : desktop 1440, mobile 390 ; version mobile dessinée : oui

## 4. Tokens

### 4.2 Couleurs
| Token | Valeur | Usage |
|---|---|---|
| `color.brand.green` | `#2F5D3A` | Fond des boutons principaux, titres |
| `color.text.primary` | `#1C1C1C` | Texte courant |
| `color.surface.base` | `#F7F4EE` | Fond de page |

### 4.3 Typographie
- Police unique : Source Serif 4 (licence SIL Open Font License), titres et texte courant.
- Libellés de boutons et de navigation : **bas de casse, pas de capitales**, 17 px, graisse 600.

## 5. Composants existants

| Composant | Règle validée |
|---|---|
| Bouton principal | Hauteur **40 px**, rayon 2 px, fond `color.brand.green`, texte blanc, pas de flèche |
| Bouton secondaire | Contour 1 px vert, même hauteur |

## 7. Do / Don't

**Don't** : capitales dans les libellés (« ça crie », retour du conseil d'administration du 18/09).
LBA_FIXTURE_EOF
