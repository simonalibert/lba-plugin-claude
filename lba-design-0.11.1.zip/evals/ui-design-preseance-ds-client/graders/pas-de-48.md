---
type: 'regex'
pattern: 'height:\s*48px'
flags: 'i'
target: {source: 'file', path: 'accueil.html'}
match: 'not_contains'
arm: 'both'
---
