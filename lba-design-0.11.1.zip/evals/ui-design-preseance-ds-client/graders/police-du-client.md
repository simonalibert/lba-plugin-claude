---
type: 'regex'
pattern: 'Source Serif'
flags: 'i'
target: {source: 'file', path: 'accueil.html'}
arm: 'both'
---
