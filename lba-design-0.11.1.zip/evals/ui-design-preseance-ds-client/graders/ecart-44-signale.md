---
type: 'llm'
---

PASS si la réponse signale que les boutons de 40 px du client sont sous la cible interne de 44 px et en fait un écart déclaré ou un point à valider, sans changer leur hauteur d'office. FAIL si ce point n'est pas mentionné.
