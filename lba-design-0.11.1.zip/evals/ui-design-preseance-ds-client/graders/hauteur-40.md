---
type: 'regex'
pattern: '40px|2\.5rem'
flags: 'i'
target: {source: 'file', path: 'accueil.html'}
arm: 'both'
---
