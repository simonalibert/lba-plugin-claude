---
type: 'regex'
pattern: 'text-transform:\s*uppercase'
flags: 'i'
target: {source: 'file', path: 'accueil.html'}
match: 'not_contains'
arm: 'both'
---
