---
type: 'regex'
pattern: 'estim[ée]|v[ée]rifi[ée]'
flags: 'i'
---
