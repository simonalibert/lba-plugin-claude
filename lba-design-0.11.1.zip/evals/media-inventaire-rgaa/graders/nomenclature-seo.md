---
type: 'regex'
pattern: 'SEO'
flags: 'i'
---
