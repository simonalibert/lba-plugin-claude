---
type: 'regex'
pattern: 'sous-titr'
flags: 'i'
---
