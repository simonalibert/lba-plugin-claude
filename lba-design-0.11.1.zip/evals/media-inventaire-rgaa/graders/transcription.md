---
type: 'regex'
pattern: 'transcription'
flags: 'i'
---
