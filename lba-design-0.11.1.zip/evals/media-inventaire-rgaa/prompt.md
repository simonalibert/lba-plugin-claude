---
description: 'media-inventaire-rgaa'
tags: ['media', 'comportement']
max_turns: 15
timeout_seconds: 600
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

Fais l'inventaire des médias pour le futur site du département : une quarantaine de pages, dont quatre vidéos de présentation des services. Profil conformité RGAA.
