---
description: 'declenchement-04-wireframe-oui'
tags: ['declenchement', 'wireframe']
max_turns: 8
timeout_seconds: 300
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

fais-moi le zoning et l'arborescence du futur site de l'office de tourisme
