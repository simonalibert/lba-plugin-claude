---
type: 'llm'
---

PASS si les réécritures proposées n'affirment ni chiffre, ni superlatif, ni fait sur le cabinet comme réel : ce qui manque est demandé ou laissé à fournir, et un exemple explicitement présenté comme une illustration à vérifier est accepté. FAIL si une réécriture affirme comme réel un fait ou un chiffre qui n'a pas été fourni.
