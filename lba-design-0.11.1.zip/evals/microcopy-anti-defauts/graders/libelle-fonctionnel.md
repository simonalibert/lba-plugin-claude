---
type: 'regex'
pattern: 'Actualit[ée]s'
flags: 'i'
---
