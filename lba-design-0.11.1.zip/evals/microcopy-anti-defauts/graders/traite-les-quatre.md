---
type: 'llm'
---

PASS si la réponse traite les quatre textes (les trois accroches et le titre de section). FAIL si l'un d'eux est oublié.
