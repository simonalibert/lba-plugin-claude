---
description: 'microcopy-anti-defauts'
tags: ['microcopy', 'comportement']
max_turns: 10
timeout_seconds: 600
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

Relis les accroches de notre page d'accueil : « Découvrez l'excellence au cœur de nos solutions », « Simple. Rapide. Efficace. », « Plus qu'un cabinet, un partenaire », et le titre de la section actualités : « Carnet de terrain ».
