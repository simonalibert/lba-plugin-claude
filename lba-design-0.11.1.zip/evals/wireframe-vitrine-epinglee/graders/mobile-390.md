---
type: 'regex'
pattern: '390'
flags: 'i'
target: {source: 'file', path: 'wireframe-accueil.html'}
arm: 'both'
---
