---
type: 'llm'
---

PASS si la section épinglée est annotée avec un équivalent statique (ce qui s'affiche sans défilement animé ou en réduction des animations). FAIL sinon.
