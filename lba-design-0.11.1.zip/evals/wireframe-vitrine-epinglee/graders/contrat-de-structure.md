---
type: 'regex'
pattern: 'fig[ée]|ajustable'
flags: 'i'
---
