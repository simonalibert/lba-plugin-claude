---
type: 'regex'
pattern: '#d9d9d9|--lofi'
flags: 'i'
target: {source: 'file', path: 'wireframe-accueil.html'}
arm: 'both'
---
