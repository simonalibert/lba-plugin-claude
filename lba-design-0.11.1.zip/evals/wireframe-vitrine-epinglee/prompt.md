---
description: 'wireframe-vitrine-epinglee'
tags: ['wireframe', 'comportement']
max_turns: 35
timeout_seconds: 1200
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill', 'Write', 'Edit', 'Bash', 'TodoWrite']
---

Wireframe de la page d'accueil d'un site vitrine pour une coutellerie (profil vitrine expressive), dans `wireframe-accueil.html`. On veut une section épinglée où le couteau reste à l'écran pendant que trois étapes de fabrication défilent. La haute fidélité ne sera dessinée qu'en desktop.
