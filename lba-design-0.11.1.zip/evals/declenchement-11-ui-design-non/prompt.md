---
description: 'declenchement-11-ui-design-non'
tags: ['declenchement', 'ui-design']
max_turns: 8
timeout_seconds: 300
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

fais une présentation de 10 slides pour le comité de pilotage
