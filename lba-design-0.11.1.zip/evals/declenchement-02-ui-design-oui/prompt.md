---
description: 'declenchement-02-ui-design-oui'
tags: ['declenchement', 'ui-design']
max_turns: 8
timeout_seconds: 300
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

la home qu'on a faite fait trop template, tu peux la rendre plus singulière ?
