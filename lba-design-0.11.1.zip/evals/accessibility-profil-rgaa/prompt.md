---
description: 'accessibility-profil-rgaa'
tags: ['accessibility', 'comportement']
max_turns: 20
timeout_seconds: 900
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

Pré-évalue l'accessibilité de cette page d'accueil (capture-accueil.png, dans le dossier de travail). C'est pour une communauté de communes ; la fiche projet est en profil conformité RGAA.
