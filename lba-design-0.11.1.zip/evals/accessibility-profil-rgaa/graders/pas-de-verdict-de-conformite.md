---
type: 'llm'
---

PASS si la réponse ne déclare pas la page conforme ou non conforme au RGAA comme un fait établi. FAIL si elle prononce un verdict de conformité.
