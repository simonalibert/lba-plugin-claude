---
type: 'regex'
pattern: 'conformit[ée] RGAA'
flags: 'i'
---
