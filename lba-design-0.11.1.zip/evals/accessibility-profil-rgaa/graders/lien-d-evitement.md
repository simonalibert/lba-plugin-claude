---
type: 'regex'
pattern: '[ée]vitement'
flags: 'i'
---
