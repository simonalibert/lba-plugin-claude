---
type: 'regex'
pattern: 'pr[ée]-?[ée]valuation'
flags: 'i'
---
