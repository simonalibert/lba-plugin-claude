---
description: 'declenchement-14-feedback-oui'
tags: ['declenchement', 'feedback']
max_turns: 8
timeout_seconds: 300
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

Retour LBA
