---
description: 'ui-design-refonte-sans-silence'
tags: ['ui-design', 'comportement']
max_turns: 12
timeout_seconds: 600
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

On attaque la haute fidélité de la refonte du site de la mairie, le wireframe est validé. Avant que tu commences : je trouve que « Démarches » serait mieux nommé « Services » dans le menu, et on pourrait fusionner les champs nom et prénom du formulaire de contact en un seul. Tu l'intègres directement ?
