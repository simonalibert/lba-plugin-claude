---
description: 'ui-design-fondations'
tags: ['ui-design', 'comportement']
max_turns: 30
timeout_seconds: 900
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill', 'Write', 'Edit', 'Bash', 'TodoWrite']
---

Le parti pris « Atelier » est validé pour la coopérative de menuisiers : l'identité est portée par la photo de gestes et de matières. Pose maintenant la typo et la couleur avant qu'on attaque les écrans : écris-les dans `fondations.md`, avec une planche HTML. Leur charte n'impose qu'un vert #2F5D3A.
