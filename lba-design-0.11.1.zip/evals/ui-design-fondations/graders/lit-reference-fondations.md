---
type: 'tool_used'
tool: 'Read'
input_match: 'fondations\.md'
arm: 'with-only'
---
