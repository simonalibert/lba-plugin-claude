---
type: 'regex'
pattern: '#2F5D3A'
flags: 'i'
target: {source: 'file', path: 'fondations.md'}
arm: 'both'
---
