---
type: 'regex'
pattern: 'clamp\('
flags: 'i'
target: {source: 'file', path: 'fondations.md'}
arm: 'both'
---
