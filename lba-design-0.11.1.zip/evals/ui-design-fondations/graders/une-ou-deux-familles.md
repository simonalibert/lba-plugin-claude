---
type: 'llm'
focus: {source: 'file', path: 'fondations.md'}
---

PASS si le document retient une ou deux familles de polices pour le site. FAIL s'il en retient trois ou plus.
