---
type: 'regex'
pattern: '\d+[.,]\d+\s?:\s?1'
flags: 'i'
target: {source: 'file', path: 'fondations.md'}
arm: 'both'
---
