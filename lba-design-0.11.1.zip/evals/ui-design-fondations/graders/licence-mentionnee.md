---
type: 'regex'
pattern: 'licence|license|OFL'
flags: 'i'
target: {source: 'file', path: 'fondations.md'}
arm: 'both'
---
