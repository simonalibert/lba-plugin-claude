---
type: 'llm'
focus: {source: 'file', path: 'fondations.md'}
---

PASS si le document n'ajoute pas de mode sombre, ou le présente seulement comme une option à décider. FAIL s'il impose un mode sombre.
