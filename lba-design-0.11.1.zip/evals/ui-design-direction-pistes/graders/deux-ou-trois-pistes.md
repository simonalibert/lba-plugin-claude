---
type: 'llm'
focus: {source: 'file', path: 'pistes.md'}
---

PASS si le fichier présente deux ou trois pistes, pas une seule et pas plus de trois. FAIL sinon.
