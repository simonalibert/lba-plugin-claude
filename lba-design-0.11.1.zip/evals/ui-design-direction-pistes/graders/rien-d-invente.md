---
type: 'llm'
focus: {source: 'file', path: 'pistes.md'}
---

PASS si aucun nom d'artiste, aucune date de festival et aucun chiffre n'est présenté comme réel (les contenus manquants sont marqués « À fournir » ou présentés comme génériques). FAIL si des artistes, des dates ou des chiffres sont présentés comme réels.
