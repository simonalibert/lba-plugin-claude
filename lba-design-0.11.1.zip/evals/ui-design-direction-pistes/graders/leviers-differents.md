---
type: 'llm'
focus: {source: 'file', path: 'pistes.md'}
---

PASS si les pistes se distinguent par leur levier principal (typographie, image, couleur, composition, matière ou mouvement) ou par une direction opposée du même levier, et pas seulement par la couleur d'accent. FAIL si elles ne diffèrent que par la couleur ou des détails.
