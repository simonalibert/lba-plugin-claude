---
type: 'tool_used'
tool: 'Read'
input_match: 'direction\.md'
arm: 'with-only'
---
