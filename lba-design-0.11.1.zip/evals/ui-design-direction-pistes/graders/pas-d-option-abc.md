---
type: 'regex'
pattern: 'Option\s+[ABC]\b'
flags: 'i'
target: {source: 'file', path: 'pistes.md'}
match: 'not_contains'
arm: 'both'
---
