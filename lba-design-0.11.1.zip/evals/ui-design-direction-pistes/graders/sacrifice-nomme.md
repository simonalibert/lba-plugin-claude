---
type: 'regex'
pattern: 'renonce|sacrifi'
flags: 'i'
target: {source: 'file', path: 'pistes.md'}
arm: 'both'
---
