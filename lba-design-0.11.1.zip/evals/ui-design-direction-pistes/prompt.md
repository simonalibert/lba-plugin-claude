---
description: 'ui-design-direction-pistes'
tags: ['ui-design', 'comportement']
max_turns: 40
timeout_seconds: 1200
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill', 'Write', 'Edit', 'Bash', 'TodoWrite']
---

Nouveau client : un festival de musique de chambre en Haute-Savoie veut refaire son site. On hésite complètement sur la direction graphique. Propose-nous des pistes : écris-les dans `pistes.md` (une section par piste) et fais une planche HTML par piste.
