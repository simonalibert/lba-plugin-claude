#!/usr/bin/env bash
# Recreates this case's input files in the run's empty workspace (needs --scaffold).
set -euo pipefail
cat > 'page-tailles.html' <<'LBA_FIXTURE_EOF'
<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>s</title></head><body><main><p style="font-size:12px">Mentions minuscules ici</p><p style="font-size:15px">Un paragraphe de texte courant assez long pour dépasser les quatre-vingts caractères de la règle de détection.</p><p style="font-size:14px">Court libellé</p><p style="font-size:17px">Texte normal de bonne taille pour la lecture courante sans aucun problème particulier ici.</p></main></body></html>
LBA_FIXTURE_EOF
cat > 'fiche-vitrine-eco.md' <<'LBA_FIXTURE_EOF'
# Fiche projet : <Client / Nom du site>

## Sources
- Wireframe : <lien claude.ai ou Figma> (statut : validé client le JJ/MM | à challenger)
- Design system : <nom exact du design system client>
- Site actuel : <URL>
- Figma : <lien fichier / page>
- Contenus : <lien doc ou dossier>
- Médias : <dossier photos, logos, pictos> (banque d'images autorisée : oui/non)
- Fonts : <noms, fichiers, licence web oui/non>

## Contrat de structure
- Figé : <ex. ordre des sections, libellés du menu, CTA du hero>
- Ajustable : <ex. nombre d'actualités, proportions>
- Libre : traitement visuel

## Cadre
- Publics prioritaires et action principale : …
- Intention (3 à 5 mots) : …  Références (avec l'axe retenu pour chacune) : …  Contre-références : …
- Mode des pages clés : <ex. accueil : persuader ; recherche : faire agir ; fiches : faire lire>
- Ce que seul le client possède : …
- Parti pris retenu : <nom> : levier principal …, appui …, sacrifice … (validé le JJ/MM par …)
- Contraintes : accessibilité (référentiel visé), CMS / techno cible, navigateurs, hébergement
- Confidentialité : contenus non publics autorisés dans les maquettes partagées ? oui/non

## Profil et livrables
- Profil (`lba-design:principles` §11) : [ ] standard  [x] vitrine expressive  [ ] conformité RGAA  [x] éco-conçu
- Version mobile dessinée : non (si non : comportement mobile décrit dans la spec)
- Repères de taille ajustés à la police (sinon, repères de `principles` §4) : texte courant 17 px ; libellés 13 px

Cocher en remplaçant `[ ]` par `[x]` : `scripts/qa.py --fiche` lit cette section pour appliquer le profil.
- Arbitrages entre profils, s'il y en a deux : …

## Défauts maison écartés
- <ex. boutons 56px ; pas de capitales condensées ; rayon 0 ; CTA à 13 px car la police a une grande hauteur d'x, vérifié au zoom 200 %>

## Versions
- v1 (JJ/MM) : …

## Décisions
<journal au format de references/livraison.md>

## À fournir par le client
- …
LBA_FIXTURE_EOF
