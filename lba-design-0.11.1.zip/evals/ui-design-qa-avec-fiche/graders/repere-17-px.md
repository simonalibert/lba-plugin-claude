---
type: 'regex'
pattern: '17\s?px'
flags: 'i'
---
