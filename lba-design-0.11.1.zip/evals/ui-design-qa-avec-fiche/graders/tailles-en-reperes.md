---
type: 'llm'
---

PASS si la réponse présente les tailles de texte trop petites comme des repères à juger selon la police (ou des points à valider), et non comme des non-conformités ou des erreurs bloquantes. FAIL sinon.
