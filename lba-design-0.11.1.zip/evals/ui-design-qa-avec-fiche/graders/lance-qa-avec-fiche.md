---
type: 'tool_used'
tool: 'Bash'
input_match: 'qa\.py.*--fiche'
arm: 'with-only'
---
