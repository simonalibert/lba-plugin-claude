---
type: 'tool_used'
tool: 'Bash'
input_match: 'qa\.py.*--quiet'
arm: 'with-only'
---
