---
type: 'regex'
pattern: '13\s?px'
flags: 'i'
---
