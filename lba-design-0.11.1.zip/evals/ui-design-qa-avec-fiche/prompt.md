---
description: 'ui-design-qa-avec-fiche'
tags: ['ui-design', 'comportement', 'bash']
max_turns: 30
timeout_seconds: 900
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill', 'Write', 'Edit', 'Bash', 'TodoWrite']
---

Fais la passe qualité de la page page-tailles.html avant qu'on la livre. La fiche projet est fiche-vitrine-eco.md. Les deux fichiers sont dans le dossier de travail.
