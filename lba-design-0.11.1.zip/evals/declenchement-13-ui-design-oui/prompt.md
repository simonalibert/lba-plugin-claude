---
description: 'declenchement-13-ui-design-oui'
tags: ['declenchement', 'ui-design']
max_turns: 8
timeout_seconds: 300
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

sur la maquette du tableau de bord qu'on est en train de faire, je me demande si on ne devrait pas modifier l'affichage des KPIs, tu peux essayer une version en liste ?
