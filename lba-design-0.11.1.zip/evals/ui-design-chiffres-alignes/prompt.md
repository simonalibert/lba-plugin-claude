---
description: 'ui-design-chiffres-alignes'
tags: ['ui-design', 'comportement']
max_turns: 12
timeout_seconds: 600
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

Sur la maquette, les compteurs des tuiles KPI (« 12 », « 3 », « 148 ») sont en Fraunces et les chiffres ne s'alignent pas d'une tuile à l'autre. Donne-moi le CSS à appliquer aux compteurs pour corriger ça, et dis-moi ce que je dois vérifier dans la police.
