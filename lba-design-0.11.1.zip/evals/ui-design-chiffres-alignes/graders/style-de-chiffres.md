---
type: 'llm'
---

PASS si la réponse explique qu'il faut vérifier si la police utilise par défaut des chiffres elzéviriens (de hauteur variable) et pas seulement leur chasse, ou qu'elle mentionne l'option lining-nums pour cette raison. FAIL si elle se contente de tabular-nums.
