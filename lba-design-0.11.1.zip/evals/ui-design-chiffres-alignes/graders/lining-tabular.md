---
type: 'regex'
pattern: 'lining-nums\s+tabular-nums|tabular-nums\s+lining-nums'
flags: 'i'
---
