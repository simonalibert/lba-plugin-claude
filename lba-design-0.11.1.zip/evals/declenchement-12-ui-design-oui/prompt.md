---
description: 'declenchement-12-ui-design-oui'
tags: ['declenchement', 'ui-design']
max_turns: 8
timeout_seconds: 300
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

on doit maquetter un prototype interactif d'app mobile pour des techniciens de maintenance, trois écrans, tu peux t'en charger dans Claude Design ?
