---
description: 'declenchement-08-accessibility-oui'
tags: ['declenchement', 'accessibility']
max_turns: 8
timeout_seconds: 300
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

est-ce que cette maquette est accessible au sens du RGAA ?
