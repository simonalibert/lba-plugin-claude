---
description: 'declenchement-15-feedback-oui'
tags: ['declenchement', 'feedback']
max_turns: 8
timeout_seconds: 300
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

avant de fermer, fais un retour d'usage du plugin sur cette conversation
