---
type: 'regex'
pattern: 'pause'
flags: 'i'
---
