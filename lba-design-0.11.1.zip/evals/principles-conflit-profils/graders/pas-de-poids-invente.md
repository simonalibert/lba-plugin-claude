---
type: 'llm'
---

PASS si la réponse n'affirme aucun poids de vidéo comme un fait (un budget ou un ordre de grandeur présenté comme cible est accepté). FAIL sinon.
