---
type: 'llm'
---

PASS si la réponse propose au moins deux options concrètes pour la vidéo. FAIL si elle n'en propose qu'une ou aucune.
