---
type: 'regex'
pattern: 'fiche projet|arbitr'
flags: 'i'
---
