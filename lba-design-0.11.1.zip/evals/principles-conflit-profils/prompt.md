---
description: 'principles-conflit-profils'
tags: ['principles', 'comportement']
max_turns: 10
timeout_seconds: 600
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

Le client veut un site éco-conçu, mais on est aussi en vitrine expressive et il tient à une vidéo de fond en boucle dans le hero. On fait comment ?
