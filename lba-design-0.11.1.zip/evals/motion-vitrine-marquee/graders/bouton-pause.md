---
type: 'regex'
pattern: 'pause'
flags: 'i'
target: {source: 'file', path: 'marquee.html'}
arm: 'both'
---
