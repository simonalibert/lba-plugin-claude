---
type: 'regex'
pattern: 'aria-hidden'
flags: 'i'
target: {source: 'file', path: 'marquee.html'}
arm: 'both'
---
