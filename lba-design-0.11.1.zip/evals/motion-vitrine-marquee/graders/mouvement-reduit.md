---
type: 'regex'
pattern: 'prefers-reduced-motion'
flags: 'i'
target: {source: 'file', path: 'marquee.html'}
arm: 'both'
---
