---
description: 'motion-vitrine-marquee'
tags: ['motion', 'comportement']
max_turns: 25
timeout_seconds: 900
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill', 'Write', 'Edit', 'Bash', 'TodoWrite']
---

Site vitrine pour une marque de skate, on est en profil vitrine expressive : je veux un bandeau de texte qui défile en boucle sous le hero, bien visible. Livre-le dans `marquee.html`.
