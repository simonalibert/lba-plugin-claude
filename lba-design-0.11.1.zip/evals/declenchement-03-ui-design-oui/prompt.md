---
description: 'declenchement-03-ui-design-oui'
tags: ['declenchement', 'ui-design']
max_turns: 8
timeout_seconds: 300
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

fais une passe qualité sur ma maquette html avant que je l'envoie au client
