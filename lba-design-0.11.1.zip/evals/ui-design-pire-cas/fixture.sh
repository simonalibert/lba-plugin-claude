#!/usr/bin/env bash
# Recreates this case's input files in the run's empty workspace (needs --scaffold).
set -euo pipefail
cat > 'page-actus.html' <<'LBA_FIXTURE_EOF'
<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Actualités</title>
<style>
body{font:18px/1.5 system-ui;margin:0;color:#1a1a1a}main{max-width:1200px;margin:0 auto;padding:64px 24px}
h1{font-size:48px;text-wrap:balance}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:32px}
.card img{width:100%;aspect-ratio:3/2;object-fit:cover;background:#ddd}.card h2{font-size:22px;margin:16px 0 8px}
.meta{font-size:14px;color:#595959}.count{font-size:14px}
@media (max-width:768px){.grid{grid-template-columns:1fr}}
</style></head><body><main>
<h1>Actualités</h1><p class="count"><span id="n">3</span> articles</p>
<div class="grid" id="list"></div></main>
<script>
const data=[
 {t:"Ouverture des inscriptions",d:"12 septembre 2026",a:"Service communication",img:"https://picsum.photos/seed/a/600/400"},
 {t:"Nouveau partenariat",d:"5 septembre 2026",a:"Direction",img:"https://picsum.photos/seed/b/600/400"},
 {t:"Retour sur la journée portes ouvertes",d:"28 août 2026",a:"Vie étudiante",img:"https://picsum.photos/seed/c/600/400"}];
document.getElementById('list').innerHTML=data.map(x=>`<article class="card"><img src="${x.img}" alt=""><h2>${x.t}</h2><p class="meta">${x.d} · ${x.a}</p></article>`).join('');
document.getElementById('n').textContent=data.length;
</script></body></html>
LBA_FIXTURE_EOF
