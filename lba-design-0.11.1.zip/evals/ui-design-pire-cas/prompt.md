---
description: 'ui-design-pire-cas'
tags: ['ui-design', 'comportement']
max_turns: 30
timeout_seconds: 900
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill', 'Write', 'Edit', 'Bash', 'TodoWrite']
---

Voici la page d'actualités qu'on va livrer (page-actus.html, dans le dossier de travail). Les contenus seront saisis par le client dans son CMS. Vérifie qu'elle tient avant qu'on l'envoie : fais une version de travail dans `page-actus-test.html` et dis-moi ce qui casse.
