---
type: 'regex'
pattern: 'image absente|sans image|image manquante|pas d.image'
flags: 'i'
---
