---
type: 'regex'
pattern: 'a{8,}|x{8,}|lorem'
flags: 'i'
target: {source: 'file', path: 'page-actus-test.html'}
match: 'not_contains'
arm: 'both'
---
