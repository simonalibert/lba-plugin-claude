---
type: 'llm'
---

PASS si la réponse liste les casses constatées et propose une correction pour chacune (ou la renvoie à une décision à valider). FAIL si elle liste des casses sans aucune correction.
