---
type: 'regex'
pattern: 'pire|worst|d[ée]mo'
flags: 'i'
target: {source: 'file', path: 'page-actus-test.html'}
arm: 'both'
---
