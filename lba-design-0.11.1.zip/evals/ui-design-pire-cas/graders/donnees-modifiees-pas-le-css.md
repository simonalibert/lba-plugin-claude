---
type: 'regex'
pattern: 'const\s+data|data\s*=\s*\['
flags: 'i'
target: {source: 'file', path: 'page-actus-test.html'}
arm: 'both'
---
