---
type: 'tool_used'
tool: 'Read'
input_match: 'qa\.md'
arm: 'with-only'
---
