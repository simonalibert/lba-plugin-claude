---
type: 'regex'
pattern: '0 article|aucun article|liste vide|z[ée]ro article|état vide'
flags: 'i'
---
