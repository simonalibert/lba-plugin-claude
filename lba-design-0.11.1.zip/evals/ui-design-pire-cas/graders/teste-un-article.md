---
type: 'regex'
pattern: '1 article\b|un seul article|accord'
flags: 'i'
---
