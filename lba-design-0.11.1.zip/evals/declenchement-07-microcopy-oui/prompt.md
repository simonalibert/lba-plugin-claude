---
description: 'declenchement-07-microcopy-oui'
tags: ['declenchement', 'microcopy']
max_turns: 8
timeout_seconds: 300
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

quel libellé mettre sur le bouton d'envoi du formulaire de candidature ?
