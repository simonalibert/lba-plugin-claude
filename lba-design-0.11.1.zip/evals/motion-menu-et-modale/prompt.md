---
description: 'motion-menu-et-modale'
tags: ['motion', 'comportement']
max_turns: 30
timeout_seconds: 900
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill', 'Write', 'Edit', 'Bash', 'TodoWrite']
---

Écris l'animation d'ouverture d'un menu déroulant et d'une modale de confirmation pour notre site (React, GSAP déjà installé). Livre le code dans `menu-modale.tsx`.
