---
type: 'regex'
pattern: 'transform-?origin|transformOrigin'
flags: 'i'
target: {source: 'file', path: 'menu-modale.tsx'}
arm: 'both'
---
