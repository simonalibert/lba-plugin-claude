---
type: 'regex'
pattern: 'scale\s*[:(]\s*0\s*[,)}]'
flags: 'i'
target: {source: 'file', path: 'menu-modale.tsx'}
match: 'not_contains'
arm: 'both'
---
