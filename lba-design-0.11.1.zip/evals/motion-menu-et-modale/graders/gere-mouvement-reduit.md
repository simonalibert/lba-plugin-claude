---
type: 'regex'
pattern: 'prefers-reduced-motion|isReducedMotion|getMoveFactor|useReducedMotion'
flags: 'i'
target: {source: 'file', path: 'menu-modale.tsx'}
arm: 'both'
---
