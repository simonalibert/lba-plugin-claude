---
type: 'regex'
pattern: '[\"''](ease-in|power\d\.in|expo\.in|sine\.in)[\"'']'
flags: 'i'
target: {source: 'file', path: 'menu-modale.tsx'}
match: 'not_contains'
arm: 'both'
---
