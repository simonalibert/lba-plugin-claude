---
type: 'llm'
focus: {source: 'file', path: 'menu-modale.tsx'}
---

PASS si, en réduction des animations, le code garde un fondu d'opacité et supprime l'échelle et le déplacement. FAIL s'il coupe tout sans fondu, ou s'il garde l'échelle ou le déplacement.
