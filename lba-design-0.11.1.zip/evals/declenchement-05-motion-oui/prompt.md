---
description: 'declenchement-05-motion-oui'
tags: ['declenchement', 'motion']
max_turns: 8
timeout_seconds: 300
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

anime l'ouverture du menu déroulant et de la modale du site
