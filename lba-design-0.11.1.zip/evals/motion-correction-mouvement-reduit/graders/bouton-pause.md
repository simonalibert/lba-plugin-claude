---
type: 'regex'
pattern: 'pause'
flags: 'i'
target: {source: 'file', path: 'carousel-corrige.ts'}
arm: 'both'
---
