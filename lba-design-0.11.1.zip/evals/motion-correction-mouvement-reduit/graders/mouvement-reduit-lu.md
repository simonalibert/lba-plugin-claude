---
type: 'regex'
pattern: 'isReducedMotion|getMoveFactor|prefers-reduced-motion'
flags: 'i'
target: {source: 'file', path: 'carousel-corrige.ts'}
arm: 'both'
---
