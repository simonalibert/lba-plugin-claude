---
type: 'llm'
focus: {source: 'file', path: 'carousel-corrige.ts'}
---

PASS si, en réduction des animations, le défilement automatique s'arrête, la translation, la montée et le flou sont supprimés, et un fondu d'opacité court reste pour le changement de slide. FAIL si l'une de ces trois conditions manque.
