#!/usr/bin/env bash
# Recreates this case's input files in the run's empty workspace (needs --scaffold).
set -euo pipefail
cat > 'carousel.ts' <<'LBA_FIXTURE_EOF'
import { gsap } from "gsap";
import { getIntensity } from "./lib/intensity";

// Hero carousel: slides move horizontally every 6 s.
export function startCarousel(track: HTMLElement, slides: HTMLElement[]) {
  let i = 0;
  const k = getIntensity();
  setInterval(() => {
    i = (i + 1) % slides.length;
    gsap.to(track, { x: -i * track.clientWidth, duration: 0.9 * k, ease: "power2.inOut" });
    gsap.fromTo(slides[i], { opacity: 0, y: 40 * k, filter: "blur(8px)" }, { opacity: 1, y: 0, filter: "blur(0px)", duration: 0.8 });
  }, 6000);
}
LBA_FIXTURE_EOF
