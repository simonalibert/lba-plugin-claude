---
description: 'motion-correction-mouvement-reduit'
tags: ['motion', 'comportement']
max_turns: 25
timeout_seconds: 900
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill', 'Write', 'Edit', 'Bash', 'TodoWrite']
---

Le carrousel du hero (carousel.ts, dans le dossier de travail) bouge encore quand l'utilisateur a activé la réduction des animations. Corrige-le dans `carousel-corrige.ts`.
