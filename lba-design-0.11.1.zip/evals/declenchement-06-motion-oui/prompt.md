---
description: 'declenchement-06-motion-oui'
tags: ['declenchement', 'motion']
max_turns: 8
timeout_seconds: 300
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

le carrousel bouge encore quand la réduction des animations est activée
