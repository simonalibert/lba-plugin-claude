---
description: 'declenchement-16-feedback-non'
tags: ['declenchement', 'feedback']
max_turns: 8
timeout_seconds: 300
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

compile les retours du client sur la maquette de la page d'accueil, il en a envoyé par mail et en commentaire Figma
