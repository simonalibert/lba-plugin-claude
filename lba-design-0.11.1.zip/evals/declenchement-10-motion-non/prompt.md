---
description: 'declenchement-10-motion-non'
tags: ['declenchement', 'motion']
max_turns: 8
timeout_seconds: 300
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

monte une vidéo de 30 secondes pour Instagram avec des transitions
