---
type: 'regex'
pattern: 'mouvement r[ée]duit'
flags: 'i'
---
