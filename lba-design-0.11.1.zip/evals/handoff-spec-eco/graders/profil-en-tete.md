---
type: 'regex'
pattern: '[ée]co-?con[çc]u'
flags: 'i'
---
