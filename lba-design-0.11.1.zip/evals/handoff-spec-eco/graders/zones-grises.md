---
type: 'regex'
pattern: 'zones? grises?'
flags: 'i'
---
