---
type: 'llm'
---

PASS si les poids d'images inconnus sont laissés en zone grise ou à fournir, sans valeur précise inventée pour une image donnée. FAIL si la spec attribue des poids précis à des images dont le poids n'était pas connu.
