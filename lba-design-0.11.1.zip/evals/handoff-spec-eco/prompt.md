---
description: 'handoff-spec-eco'
tags: ['handoff', 'comportement']
max_turns: 15
timeout_seconds: 600
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

Rédige la spec d'écran de la page actualités validée pour le dev. Le projet est en profil éco-conçu. Je n'ai pas encore les poids de toutes les images.
