#!/usr/bin/env bash
# Recreates this case's input files in the run's empty workspace (needs --scaffold).
set -euo pipefail
cat > 'page-tics.html' <<'LBA_FIXTURE_EOF'
<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Test tics</title>
<style>
body{font-family:system-ui;margin:0;padding:32px}
h1{background:linear-gradient(90deg,#60f,#0cf);-webkit-background-clip:text;background-clip:text;color:transparent;text-wrap:balance}
.note{border-left:4px solid #e33;padding:16px}
.quote{border-left:3px solid #ccc;padding:16px}
.card{box-shadow:4px 4px 0 #000;padding:16px;margin:16px 0}
.soft{box-shadow:0 4px 16px rgb(0 0 0/.1);padding:16px}
a.btn{display:inline-block;padding:16px;transition:all .3s ease-in;min-height:44px}
.drop{transition:transform .2s cubic-bezier(.42,0,1,1)}
.ok{transition:transform .2s cubic-bezier(.23,1,.32,1)}
td.t{font-variant-numeric:tabular-nums}
</style></head><body><main>
<h1>Plongez au cœur de l'innovation</h1>
<span class="num">01 / Expertises</span>
<p class="meta">Grenoble · 2026 · Studio · Design</p>
<div class="note">Alerte importante</div>
<div class="quote">Citation neutre</div>
<div class="card">Carte néo-brutaliste</div>
<div class="soft">Carte douce</div>
<ul><li><a href="#x">🚀</a> Lancer</li></ul>
<a class="btn" href="#y">Voir</a><div class="drop">Menu</div><div class="ok">Ok</div>
<table><tr><td>1 284</td><td class="t">12</td><td>Texte</td></tr></table>
</main></body></html>
LBA_FIXTURE_EOF
