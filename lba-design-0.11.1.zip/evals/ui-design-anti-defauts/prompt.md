---
description: 'ui-design-anti-defauts'
tags: ['ui-design', 'comportement']
max_turns: 25
timeout_seconds: 900
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill', 'Write', 'Edit', 'Bash', 'TodoWrite']
---

Relis cette page avant que je la montre en interne (page-tics.html, dans le dossier de travail) et dis-moi ce qui fait « généré par IA », avec ce que tu ferais à la place.
