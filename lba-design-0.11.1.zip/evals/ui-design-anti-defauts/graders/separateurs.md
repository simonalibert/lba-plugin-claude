---
type: 'regex'
pattern: '·|s[ée]parateur'
flags: 'i'
---
