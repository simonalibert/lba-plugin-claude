---
type: 'regex'
pattern: 'ease-in'
flags: 'i'
---
