---
type: 'regex'
pattern: 'filet|border-left|bordure gauche'
flags: 'i'
---
