---
type: 'llm'
---

PASS si, pour la plupart des points relevés, la réponse dit quoi faire à la place. FAIL si elle se contente de lister des défauts.
