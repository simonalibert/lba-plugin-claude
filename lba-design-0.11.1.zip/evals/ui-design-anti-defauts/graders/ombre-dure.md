---
type: 'regex'
pattern: 'ombre'
flags: 'i'
---
