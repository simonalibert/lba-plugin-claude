---
type: 'regex'
pattern: 'emoji|🚀'
flags: 'i'
---
