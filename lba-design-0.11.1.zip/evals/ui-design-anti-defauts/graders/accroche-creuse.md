---
type: 'regex'
pattern: 'Plongez|au c(œ|oe)ur'
flags: 'i'
---
