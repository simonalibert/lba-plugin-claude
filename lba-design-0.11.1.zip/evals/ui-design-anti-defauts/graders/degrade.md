---
type: 'regex'
pattern: 'd[ée]grad'
flags: 'i'
---
