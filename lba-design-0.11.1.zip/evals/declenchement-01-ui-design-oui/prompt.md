---
description: 'declenchement-01-ui-design-oui'
tags: ['declenchement', 'ui-design']
max_turns: 8
timeout_seconds: 300
allowed_tools: ['Read', 'Glob', 'Grep', 'Skill']
---

on hésite sur la direction graphique du nouveau site du conservatoire, tu peux nous proposer deux ou trois pistes ?
