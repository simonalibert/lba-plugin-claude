# Décisions de conception du plugin

Pourquoi le plugin est construit comme il l'est. À lire avant de le modifier, quelle que soit la session ou le compte : la plupart de ces choix ont été débattus, et les défaire sans le savoir réintroduit des problèmes déjà réglés. Une décision se révise ici, datée, jamais en silence. Le détail de chaque version est dans `CHANGELOG.md`.

## Périmètre et organisation

| Décision | Pourquoi | Depuis |
|---|---|---|
| **Un seul plugin, pour les profils UX, UI et DA** (et le dev front pour `motion`), pas un plugin par métier | Plusieurs plugins par métier (socle, design, dev, CDP) étaient ingérables à maintenir ; l'UX et l'UI sont trop liées pour être séparées sans recréer des silos | 0.1.0 |
| **Spécialiser les skills sans recréer des silos de connaissances** | Un corpus commun (`principles`, fiche projet, DESIGN.md) et des points d'entrée précis ; les skills se passent le relais | 0.2.0 |
| **Ne pas installer le plugin « Design » d'Anthropic en parallèle** ; quatre de ses skills sont repris et adaptés (Apache 2.0, voir `NOTICE`) | Ses skills recouvrent les nôtres et se déclencheraient sur les mêmes demandes | 0.1.0 |
| **Ne créer un skill que quand un besoin revient sur de vrais projets** | Le risque principal du plugin est l'over-engineering ; un skill écrit sans usage réel est générique et décourage | 0.4.0 |
| **Pas de skill `brief` pour l'instant** | Un brief touche aussi la gestion de projet, le fonctionnel vendu et la technique ; le périmètre se tranche en tour de table. Piste retenue : un brief vu par le design, qui repère sans traiter le reste et ne fixe jamais le périmètre contractuel | 0.4.0 (en attente) |
| **Le brandbook sera un skill à part**, non fusionnable | Il produit un document à la charte du client, alors que les documents de l'agence portent la sienne : ne pas mélanger les deux chartes | en attente du skill d'origine (Valeo) |
| **Pistes non construites** : recette des intégrations dans le navigateur (design-qa), différences entre deux états d'un fichier Figma, compilation des retours client | À construire avec la tech ou sur un besoin avéré | 0.4.0 |

## Architecture

| Décision | Pourquoi | Depuis |
|---|---|---|
| **`principles` est la source unique des règles communes** ; les skills y renvoient au lieu de recopier | Une règle recopiée finit par diverger | 0.2.0 |
| **Renvois entre skills par leur nom** (`lba-design:<skill>`), pas par chemin de fichier | À l'installation, les dossiers sont renommés `lba-design:<skill>` : un chemin `../autre-skill/` ne pointe plus nulle part | 0.2.0 |
| **Noms des skills en anglais, en un mot ; contenu en français** | Une règle simple sans exception à défendre, cohérente avec le vocabulaire de l'agence ; `handoff`, `microcopy` sont les mots employés au quotidien | 0.4.0 |
| **Pas de skill d'habillage des documents de l'agence dans le plugin** (`lba-docs` retiré) | Un skill dédié sera écrit plus tard, une fois connues les évolutions annoncées côté Claude sur le traitement des documents Google ; d'ici là, les documents de l'agence suivent ses modèles. Ce futur skill ne s'appellera pas « google-workspace », déjà le nom d'un skill d'exemple d'Anthropic | 0.10.3 (en attente) |
| **`media` regroupe l'inventaire et le gabarit de cover**, avec un aiguillage vers deux parcours | Même sujet à deux échelles ; l'aiguillage évite de charger le protocole du gabarit pour une simple question de quantités | 0.3.0 |
| **`wireframe` est séparé de `ui-design`** ; le contrat de structure est la frontière entre les deux | Métier, moment et personnes différents ; charger les règles de DA pour un wireframe pousse vers du « joli » trop tôt | 0.8.0 |
| **Rendu lofi imposé** (sept gris, une couleur réservée aux annotations, police par défaut : Inter dans Figma, Arial dans le navigateur) | Un wireframe qui ressemble à une maquette fait valider un style avant la structure. Inter dans Figma pour la fiabilité (toujours chargée) ; la couleur d'annotation est arbitraire | 0.8.1 |
| **Une maquette dans Figma : `ui-design` pilote, les skills Figma portent la technique** | Garder la méthode LBA quel que soit l'outil | 0.8.0 |
| **Outil de wireframe par défaut : Figma + Simple Design System** si le connecteur est disponible | Pratique de l'agence (projet UCI), en alternative à Axure | 0.10.2 |
| **Les écrans d'app mobile et les prototypes interactifs passent par `ui-design`**, avec une check-list dédiée (`app-mobile.md`) et une question « Support » quand la demande est ambiguë, pas par un parcours complet | L'agence fait surtout du web ; l'option est proposée, et la check-list s'enrichira si les projets d'app se multiplient (retour d'usage du 16/10/2026) | 0.11.0 |
| **Une conversation résumée se reprend en rechargeant le skill et la fiche projet** ; la fiche porte la méthode en tête, et les instructions du projet Claude peuvent la rappeler | Le résumé automatique peut faire disparaître les instructions des skills ; les fichiers et les instructions du projet survivent | 0.11.0 |
| **Un skill `feedback` déclenché par « retour LBA »** (ou `/retour`), plutôt qu'un prompt à copier | La boucle d'amélioration doit coûter dix secondes à la fin d'une session ; un tableau au format fixe se colle tel quel sur la page partagée des retours, qui le découpe en points | 0.11.1 |
| **Jamais « retour » seul comme déclencheur** | En agence, « retour » veut d'abord dire le retour d'un client sur une maquette : le skill se déclencherait à tort | 0.11.1 |
| **Savoir et exécution distingués dans `EXECUTION.md`, sans déplacer de fichiers** | Préparer un éventuel usage avec d'autres outils d'IA sans réorganiser avant d'en avoir besoin | 0.6.0 |
| **GSAP accepté malgré sa licence propriétaire** | Standard du secteur, gratuit, sans équivalent open source aussi complet ; justification inscrite dans `motion` | 0.5.0 |

## Règles de fond

| Décision | Pourquoi | Depuis |
|---|---|---|
| **Ne rien inventer ; vérifié, estimé, à trancher ; zones grises nommées** | Une valeur inventée dans un livrable devient une contrainte de production ; c'est ce qui distingue le plugin des skills publics | 0.1.0 |
| **Jamais de conformité déclarée** (RGAA, RGPD, RGESN), seulement des pré-évaluations | Posture de l'agence ; le cadre juridique se fait confirmer par un référent | 0.1.0 |
| **Préséance** : invariants, puis demande, puis décisions validées, puis charte ou design system du client, puis standards LBA, puis défauts maison | Arbitrer sans ambiguïté entre le client, l'agence et la demande du moment ; une demande rouvre une décision validée et le changement se consigne | 0.10.0 |
| **Un défaut maison n'est pas une vérité du design** | Chez un client, sa charte et ses décisions passent avant les habitudes de l'agence | 0.6.0 |
| **Le DESIGN.md est déclenché par le designer**, à la validation de la direction puis à chaque décision structurante ; il ne remplace pas le Figma pour le détail ; il passe le test de l'agent vierge avant livraison | Un skill ne se déclenche jamais seul ; un document non revérifié devient une photo périmée | 0.7.0 |
| **Questions de cadrage : seulement ce qui manque, en une fois, sans jamais bloquer** ; d'abord la structure (zoning, existant ou rien), puis logo et médias, puis les pistes ; profil prioritaire pour un client public ; sortie « sans questions » ; **Google Drive en option, jamais fouillé par défaut** | Ni deviner tout, ni harceler ; la structure conditionne tout le reste ; le profil RGAA change la posture du livrable ; le Drive contient des fichiers que la personne n'a pas choisi de partager | 0.10.5 |

## Gouvernance

| Décision | Pourquoi | Depuis |
|---|---|---|
| **Une version unique, publiée pour l'organisation** ; mise à jour de cette version, sans réimport local | Un réimport local crée un doublon dont les skills entrent en concurrence | 0.6.1 |
| **Les ajouts des collègues passent par le mainteneur, puis par le GitLab de l'agence** ; pas de plugin parallèle | Éviter des skills concurrents sur les mêmes demandes | 0.6.1 |
| **Pas de changement de structure pendant une phase de tests** | Des retours ne valent que sur une cible stable | 0.3.0 |
| **Élaguer selon les évaluations** : une nouveauté qui n'améliore rien par rapport au plugin désactivé est retirée | Chaque ajout coûte du contexte à chaque tâche ; ce sont les chiffres qui tranchent, pas le goût | 0.10.0 |

## Questions ouvertes

- Qui est responsable du DESIGN.md sur un projet, et comment les devs y contribuent (merge request relue par le designer ?).
- Le périmètre d'un skill `brief`.
- Alléger `principles`, lu avant chaque tâche : sortir ce qui ne sert qu'à écrire un skill (§9).
- Unifier le vocabulaire : « invariant » et « défaut maison » dans `principles`, encore « principe » et « convention LBA » dans les skills.
- Le futur skill d'habillage des documents de l'agence, après les évolutions annoncées sur les documents Google.
- La formulation de la licence MIT dans `NOTICE` pour des idées réécrites, à faire confirmer.
