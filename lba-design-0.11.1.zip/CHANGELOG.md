# Changelog

## 0.11.1 (19/10/2026)

- **Nouveau skill `feedback`** : retour d'usage du plugin en fin de session, en un tableau anonymisé au format lu par la page partagée des retours (colonnes fixes, ligne « Surface », lien vers la page). Couvre skills chargés, déclenchements manqués ou à tort, corrections, habitudes, classement selon `principles` §10, réussites ; signale une conversation résumée ou une lecture partielle. Déclencheur : « retour LBA » ou « retour plugin », jamais « retour » seul (retours client).
- **Commande `/retour`** (`commands/retour.md`) pour les surfaces qui prennent en charge les commandes de plugin.
- Évaluations : trois cas de déclenchement, dont un négatif (retours d'un client sur une maquette).

## 0.11.0 (16/10/2026)

Premier retour d'usage d'un autre designer de l'équipe (prototype d'app mobile terrain, Claude Design dans Cowork).

- **`ui-design`** : description réécrite plus courte (924 caractères au lieu de 985), avec les écrans d'app mobile, les prototypes interactifs et l'itération sur un écran ou un composant ; nouvelle check-list `references/app-mobile.md` ; question « Support » (site, app, les deux) seulement si la demande est ambiguë ; section « Conversation longue ou résumée » (recharger le skill et relire la fiche) ; mise à jour de la fiche projet à chaque itération validée sans attendre qu'on la demande ; étape en cours et suivante en fin de livraison ; `contrast.py` cité dans la passe qualité quand `qa.py` ne tourne pas ; deux anti-défauts (information en double dans un composant, composant remplacé laissé dans le système) ; sans charte, couleurs et polices de l'existant du client en hypothèse.
- **`fondations.md`** : `lining-nums tabular-nums` pour les chiffres alignés.
- **Fiche projet** : la méthode en tête (à recharger après un résumé) ; langue de l'interface et termes des documents source.
- **`wireframe`** : seulement les écrans demandés, les autres proposés sans être dessinés ; langue des utilisateurs finaux et termes des documents source.
- **`microcopy`** : termes des documents source, langue des utilisateurs finaux.
- **`EXECUTION.md`** : Cowork vérifié pour les skills et Claude Design via Artifact. **`DECISIONS.md`** : app mobile, conversations résumées.
- Évaluations : deux cas de déclenchement (prototype d'app, itération sur un composant) et un cas de comportement (chiffres alignés).

## 0.10.5 (10/10/2026)

- **Questions de cadrage de `ui-design`** : nouvelle première question sur la structure (zoning ou wireframe, site ou capture existante, ou rien), avec la suite à donner à chaque réponse (contrat de structure, structure extraite de l'existant sans copie visuelle, ou passage par `wireframe`). La question sur l'existant devient « Logo, médias » (je joins, chercher dans Google Drive, charte seulement, rien). Les références ne sont plus une question : elles se demandent dans la phrase de relance. Client public : le profil remplace les pistes.
- **Google Drive en option, jamais par défaut** (`ui-design`, `wireframe`, `media`) : recherche seulement si l'option est cochée ou acceptée, liste de ce qui a été trouvé, confirmation avant usage ; connecteur absent : le dire et proposer de le connecter.
- `EVALS.md` : trois tests manuels ajoutés (option Drive cochée ou non, existant fourni par URL). `DECISIONS.md` mis à jour.

## 0.10.4 (10/10/2026)

- **`ui-design` : vocabulaire d'itération** (`references/vocabulaire.md`). Douze verbes à sens fixe (hiérarchiser, aérer, densifier, resserrer, calmer, affirmer, contraster, rythmer, simplifier, réchauffer ou refroidir, faire respirer les images, polir), chacun avec l'effet recherché, ses leviers dans l'ordre et ce qu'il ne touche pas ; règles (un verbe par passe, toujours par les tokens, aucun impératif levé, restitution de ce qui a changé) ; cas des demandes vagues ou contradictoires. Idée reprise d'Impeccable (`NOTICE`). Branché à l'étape 6, dans les références et dans la description (demandes d'itération).

## 0.10.3 (10/10/2026)

- **`lba-docs` retiré** (habillage des documents de l'agence). Renvois remplacés dans `principles` §8, `accessibility`, `handoff`, `media` et `synthesis` : les documents remis au client suivent les modèles de documents de l'agence, jamais la charte du client traité. `README`, `EXECUTION.md`, `DECISIONS.md` et la description du plugin mis à jour : 11 skills.

## 0.10.2 (10/10/2026)

- **`DECISIONS.md`** à la racine : les décisions de conception du plugin et leur raison (périmètre, architecture, règles de fond, gouvernance, questions ouvertes), pour que toute session, quel que soit le compte, parte du même contexte.
- `wireframe` : outil par défaut Figma + Simple Design System si le connecteur est disponible (pratique de l'agence), sinon Claude Design ou HTML ; sortie « sans questions ».
- `ui-design`, `references/questions.md` : exceptions. Client public probable : le profil passe avant les références, ou s'inscrit d'office en hypothèse « Conformité RGAA » ; demande d'avancer sans questions : défauts appliqués et listés.

## 0.10.1 (10/10/2026)

- **Fenêtre de questions au cadrage.** `ui-design` : nouvelle référence `references/questions.md` (existant du client, références aimées ou rejetées, nombre de pistes, et profil dans Claude Code), posées en une fois avec l'outil de questions de la surface, seulement si la réponse manque, puis demande de joindre ce qui a été coché. `wireframe` : outil (Claude Design, Figma + Simple Design System si le connecteur est là, HTML), périmètre, contenus. Sans réponse, valeurs par défaut en hypothèses.
- `EXECUTION.md` : `AskUserQuestion` vérifié dans Claude Code (1 à 4 questions, 2 à 4 options, choix multiple, réponse libre ajoutée, pas de dépôt de fichier).
- `EVALS.md` : tests manuels de la fenêtre de questions, que `claude plugin eval` ne peut pas couvrir (outil retiré en mode non interactif, constaté).

## 0.10.0 (10/10/2026)

Refonte d'architecture, sans changement de fond des règles : tout ce qui existait en 0.9.0 est conservé, réorganisé.

- **Gabarit d'écriture commun** (`principles` §9) : description qui sert au déclenchement, préséance, renvoi aux invariants, profil, déroulé avec la référence à lire à chaque étape, règles du domaine, défauts maison avec leur raison, anti-défauts avec ce qu'on fait à la place, environnement, références.
- **Préséance générale et trois niveaux** (`principles` §10) : invariants > demande > décisions validées > design system ou charte du client > standards LBA > défauts maison. « Principe » devient invariant, « convention LBA » devient défaut maison ; les décisions projet sont une source, plus un niveau. Numérotation de `principles` inchangée (aucun renvoi cassé).
- **`ui-design` refondu** (126 lignes) : préséance, profil, déroulé en huit étapes avec ses références, impératifs, défauts maison en tableau avec leur raison, anti-défauts en tableau (ancienne liste d'anti-patterns et tics de génération fusionnés). Références réorganisées : `qa.md` (script, budgets, jugement avant lecture, pire cas, éléments oubliés, classement vérifié / non vérifié / hors périmètre), `livraison.md` (versions, journal de décisions, rapport, livrables), `fondations.md` (absorbe `tokens.md`). Supprimés : `defauts-agence.md`, `pire-cas.md`, `tokens.md`. Description réécrite pour le déclenchement.
- **`motion`** (89 lignes) : préséance, profil, défauts avec leur raison, anti-défauts avec leur remplacement, checklist complétée (bouton pause) ; règles des composants d'interface déplacées dans `references/composants.md`. Description complétée (carrousels, bandeaux défilants, boucles) après un échec de déclenchement trouvé par les évaluations.
- **`wireframe`, `microcopy`** : préséance, défauts motivés, anti-défauts en tableau. **`accessibility`, `handoff`, `research`, `synthesis`** : préséance et anti-défauts. **`media`, `figma`** : préséance. `lba-docs` inchangé (c'est une charte).
- **Renvoi périmé corrigé** : `synthesis` renvoyait le contrat de structure à `ui-design` au lieu de `wireframe`.
- **Évaluations au format natif de Claude Code** (`evals/`, `claude plugin eval`) à la place du format skill-creator : 16 cas de comportement et 11 de déclenchement, fichiers d'entrée recréés par `fixture.sh`, vérifications par expressions régulières et questions simples au juge, comparaison automatique avec et sans plugin. Les 11 cas de déclenchement passent (11 sur 11). Protocole de test dans `EVALS.md`.
- `claude plugin validate --strict` : passé.

## 0.9.0 (10/10/2026)

Idées reprises de trois skills publics (Emil Kowalski, Impeccable, Taste Skill), réécrites en français et filtrées selon les règles de l'agence. Rien n'est installé ni exécuté depuis ces projets.

- **`ui-design` : construire une direction** (`references/direction.md`, standard LBA pour les étapes) : mode de chaque page (persuader, faire agir, faire lire, faire vivre), inventaire de ce que seul le client possède, lecture des références axe par axe, parti pris en une phrase avec un levier principal et un sacrifice nommé, planche de direction par piste (hero 1440 et 390, une section de contenu courant, composants clés), critères de choix ordonnés, pas de fusion de pistes, consignation dans la fiche projet et le DESIGN.md. Fiche projet et modèle de livraison complétés.
- **`ui-design` : test du pire cas** (`references/pire-cas.md`), standard LBA pour les pages à contenus éditables : valeurs plausibles ou mesurées, bascule « Démonstration / Pire cas » réservée à la version de travail, catalogue adapté au français (mots longs, noms composés, accords, espaces insécables), restitution dans la QA et dans la spec d'écran.
- **`ui-design` : tics de génération et surfaces du navigateur** (`references/defauts-agence.md`), convention LBA : motifs produits par défaut par les outils de génération (cartes identiques, surtitres, numérotation, texte en dégradé, filet latéral, ombre dure, fausse interface en `div`…) à justifier ou réécrire ; `::selection`, `caret-color`, soulignement, chiffres tabulaires réglés depuis les tokens.
- **`ui-design` : passe qualité** : juger les captures avant de lire le rapport du script (éviter l'ancrage), passes bornées (une inspection, une série de corrections, une confirmation au plus).
- **`ui-design` : cadrage et directions** : lecture du brief en une phrase en tête des hypothèses ; directions nommées par leur parti pris, jamais « Option A, B, C ».
- **`ui-design` : refonte**, liste de ce qui ne change jamais en silence (adresses, navigation, champs de formulaire, logo, textes légaux, acquis d'accessibilité).
- **`qa.py`** : nouvelle section « Tics de génération » (texte en dégradé, filet latéral coloré, ombre dure, numérotation, séparateurs « · », emoji-icônes, `transition: all`, `ease-in`, chiffres de tableau sans `tabular-nums`, `::selection` absent), en signaux, pas en erreurs. Option `--quiet` pour écrire le rapport sans l'afficher. Testé sur une page témoin.
- **`motion` : composants d'interface** (menus, modales, infobulles, boutons) : décider selon la fréquence d'usage, pas d'animation au clavier, courbes par cas et jamais `ease-in`, jamais `scale(0)`, origine au déclencheur sauf modale, appui à `scale(0.97)`, transitions interrompables, survol réservé aux pointeurs fins. Point 7 ajouté à la checklist.
- **Mouvement réduit : nouvelle lecture LBA** (`principles` §4, `motion`, `ui-design` imp. 14). `prefers-reduced-motion` ne coupe plus tout : déplacements, échelle, flou, parallaxe, défilement fluide et automatique sont coupés ; les fondus d'opacité courts (0,25 s) et les changements de couleur sont gardés, conformément à la définition de « motion animation » du WCAG (Understanding 2.3.3, flou inclus depuis un erratum). Socle : `isReducedMotion()`, `setReducedMotion()` (forçage en démo), `getMoveFactor()`, `isStatic()`, `REDUCED_FADE` ; `lineReveal`, `batchReveal`, `useLineReveal`, `odometerRoll`, Lenis et vélocité adaptés ; case « Mouvement réduit » dans `MotionControls` pour montrer les deux versions au client. Intensité 1 par défaut, 0 réservé au « rien ne bouge ». Comportement de chaque recette décrit dans `a11y-perf.md`. Vérifié : compilation TypeScript stricte, et test en navigateur avec et sans préférence système.
- **`qa.py`, contrôle du mouvement réduit** : ne signale plus les fondus ni les couleurs, seulement les transitions et images clés qui déplacent ou floutent ; `transition: all` et images clés illisibles passent en « à vérifier ».
- **`microcopy` : tics de rédaction** (verbes creux, superlatifs, cadence aphoristique, étiquettes poétiques, ponctuation de rythme, faux contenus réalistes).
- **`ui-design` : fondations** (`references/fondations.md`) : choix des familles sur l'usage réel en français, licence vérifiée, une ou deux familles ; échelle par rapport de progression, deux échelles desktop et mobile, typographie fluide en `clamp` ; palette construite en OKLCH, proportions avant valeurs, neutres teintés, états dérivés, chaque paire de contraste calculée ; pas de mode sombre par défaut, décision projet avec ses conséquences ; planche de fondations avant les écrans.
- **Profils de projet** (`principles` §11) : standard, vitrine expressive, conformité RGAA, éco-conçu, combinables, déclarés dans la fiche projet. Chaque profil déplace des conventions et des standards (motion, polices, budget de page, niveau d'audit, référentiel cité), jamais les principes. `motion`, `ui-design` §7 et la fiche projet y renvoient.
- **Version mobile dessinée : décision projet** (`principles` §5, imp. 16) : le HTML livré fonctionne à toutes les largeurs, mais dessiner le 390 se décide dans la fiche projet ; s'il est dessiné, 390 et 1440 se conçoivent ensemble (hero, navigation, conversion d'abord en 390) ; sinon, le comportement mobile est décrit pour le dev.
- **Éléments souvent oubliés** (`ui-design/references/livraison.md`) : lien d'évitement, page courante, 404, confirmation de formulaire, consentement aux cookies, pied de page légal, recherche sans résultat, sous-titres, métadonnées et image de partage, impression.
- **Éco-conception** : RGESN 2024 ajouté à la posture de conformité (`principles` §3, vérifié sur la présentation officielle de l'Arcep) ; budget de page imposé seulement en profil éco-conçu (1,5 Mo accueil, 1 Mo contenu, à calibrer), poids toujours mesuré ailleurs ; `qa.py --eco`. Animations en boucle et carrousels possibles en vitrine expressive avec bouton pause (WCAG 2.2.2).
- **Contradictions corrigées** :
  - tailles de texte : le seuil « à confirmer » de `motion` devient dans `principles` §4 un repère ajustable selon la police (16 px texte courant, 14 px libellés et CTA), la seule règle fixe étant la lecture au zoom 200 % ; `qa.py` le signale, seuils réglables (`--min-text`, `--min-body`) ;
  - longueur de ligne : 80 caractères dans la checklist d'accessibilité, 75 partout ailleurs, alignée sur 75 ;
  - switch de 31 px de haut contre la cible de 44 px : la zone cliquable englobe le libellé ;
  - retour d'appui (100–160 ms) ajouté aux repères chiffrés de `motion`, qui commençaient à 150 ms ;
  - point de bascule du rendu lofi à 1024 px, hors des largeurs de contrôle : passé à 924 ;
  - bande de chiffres clés du hero et tic du « gros chiffre » : articulés (une fois, chiffres sourcés).
- **Profils branchés dans tous les skills concernés** : `accessibility` (pré-évaluation à chaque version en conformité RGAA, replis des effets en vitrine, profil dans l'en-tête du rapport), `wireframe` (390 et 1440 toujours ; ce que chaque profil impose à la structure), `handoff` (profil en tête de spec et dans le DESIGN.md, contenu propre à chaque profil), `media` (sobriété, séquences et vidéos, sous-titres et alternatives selon le profil).
- **`qa.py --fiche`** : lit la section « Profil et livrables » de la fiche projet (cases cochées, repères de taille ajustés), applique le profil éco-conçu, affiche le profil en tête du rapport avec ses rappels (pré-évaluation en RGAA, animations JavaScript à vérifier en vitrine). Les options manuelles gardent la priorité. Testé sur une fiche vitrine expressive + éco-conçu.
- **Évaluations** (`EVALS.md`, `skills/*/evals/`) : 15 cas de comportement et 17 cas de déclenchement au format du skill-creator, avec leurs fichiers d'entrée, couvrant les nouveautés de cette version. Écrits, pas encore exécutés.
- `NOTICE` : attributions Emil Kowalski (MIT), Impeccable (Apache 2.0), Taste Skill (MIT).

## 0.8.1 (08/10/2026)

- `wireframe` : rendu basse fidélité imposé (`references/rendu-lofi.md`) : palette de sept gris avec contrastes calculés, une seule couleur réservée aux annotations, police par défaut de l'outil (Inter dans Figma, Arial dans le navigateur), deux graisses, quatre tailles, conventions pour images, boutons, champs et annotations, liste de ce qui est interdit, variables CSS prêtes à l'emploi et marche à suivre dans Figma.

## 0.8.0 (08/10/2026)

- **Nouveau skill `wireframe`** : arborescence (hypothèse si pas de recherche), zoning, wireframes mobile first, contenus réels ou génériques du design system (jamais de faux contenu réaliste), page complète en un seul passage, contrat de structure en sortie, au même format que celui lu par `ui-design`. Conventions issues du projet UCI.
- **`ui-design` dans Figma** : `ui-design` pilote, les skills Figma portent la technique. Nouvelle référence `references/figma.md` : traduction des impératifs (`leadingTrim`, variables, variantes d'état, annotations pour ce qui ne se voit pas) et contrôle qualité sans `qa.py`. Description : Figma ajouté, wireframes exclus au profit de `wireframe`.
- **`figma` : bibliothèques de la communauté** (`references/bibliotheques-communautaires.md`) : `includeLibraryKeys`, import des variantes, modification des instances, retour d'expérience UCI.

## 0.7.0 (08/10/2026)

- **`ui-design` : section « Selon l'environnement »**. Hors claude.ai (Claude Code, Cowork), HTML autonome dans le dossier projet, wireframe lu depuis un fichier, un export ou Figma, `qa.py` sur le poste ou livraison sans QA scriptée signalée ; jamais de publication simulée.
- **`handoff` : test de l'agent vierge** avant de livrer un DESIGN.md. Une session sans contexte du projet construit un écran non dessiné ; chaque décision inventée devient une règle ou une zone grise.
- **Modèle de DESIGN.md : section « Marque, voix et lexique »** (ton, formulations approuvées, tableau Dire / Ne pas dire / Pourquoi / Source). `synthesis` l'alimente, `microcopy` la lit.
- **Déclencheurs** : `handoff` exclut l'implémentation en code et la construction de bibliothèque Figma ; `figma` précise qu'il porte la technique d'écriture des annotations, pas leur contenu ; `accessibility` mentionne WCAG 2.2 en bonne pratique. Cas de déclenchement ajoutés aux évaluations.

## 0.6.1 (07/10/2026)

- Description du plugin mise à jour (elle datait de la 0.2.0 et citait des skills fusionnés ou renommés) : 11 skills, noms actuels, ajout du motion.

## 0.6.0 (30/09/2026)

- **Niveaux de règle** (`principles` §10) : principe, standard LBA, convention LBA, décision projet, avec ce qui permet de s'en écarter et l'ordre de priorité. `ui-design`, `microcopy` et `motion` classent leurs règles avec ce vocabulaire. Aucune règle modifiée, seulement classée.
- **`EXECUTION.md`** à la racine : ce qui dépend de Claude dans chaque skill (outils, connecteurs, surfaces), les replis prévus, et la disponibilité par surface avec statut vérifié / estimé / à vérifier. Prépare le test dans Claude Code et une séparation future entre le savoir de l'agence et son exécution. Aucun fichier déplacé.

## 0.5.0 (30/09/2026)

- **Nouveau skill `motion`** (issu de `lba-motion`, expérimentations Claude Code sur Opinel et le POC expertises) : socle d'animation (intensité, courbe, rejouer, filets de sécurité), recettes, pièges connus, accessibilité et performance.
- Corrections à l'intégration : socle compatible rendu serveur (Next.js), intensité qui suit la préférence système en cours de session, effet vélocité qui vérifie la préférence en direct ; l'annulation de `lineReveal` n'appelle plus `onDone` ; seuils d'accessibilité renvoyés à `principles` ; règle des 16 px marquée « à confirmer » ; justification de la licence GSAP ; alignement avec `ui-design` sur le décoratif. Typage vérifié avec `tsc --strict`.
- `ui-design` et la spec d'écran de `handoff` renvoient à `motion` pour les animations.

## 0.4.0 (29/09/2026)

- **Noms des skills en anglais**, contenu inchangé et toujours en français : `principes` devient `principles`, `recherche` devient `research`, `synthese` devient `synthesis`, `maquette` devient `ui-design`, `redaction` devient `microcopy`, `accessibilite` devient `accessibility`, `medias` devient `media`, `charte` devient `lba-docs`. `handoff` et `figma` inchangés. Tous les renvois `lba-design:<skill>` et les chemins des scripts mis à jour.
- `lba-docs` : description élargie aux documents internes et aux Google Docs (nom distinct du skill d'exemple `google-workspace` pour éviter la concurrence au déclenchement).

## 0.3.0 (29/09/2026)

Dernier changement de structure avant les retours des utilisateurs.

- **Renommage** : un mot par skill, en français, sauf `handoff` gardé tel quel. `recherche-utilisateur` devient `recherche`, `synthese-recherche` devient `synthese`, `webdesign` devient `maquette`, `redaction-interface` devient `redaction`, `figma-collab` devient `figma`. Tous les renvois `lba-design:<skill>` mis à jour.
- **Fusion** : `gabarit-illustration` rejoint `medias`, qui devient un aiguillage vers deux parcours : `references/inventaire.md` (tout le site) et `references/gabarit-cover.md` (un visuel plein écran). Contenu du gabarit déplacé sans réécriture ; ses références sont renommées `gabarit-*.md`, le script et les exemples sont dans `medias/scripts` et `medias/assets`.
- 10 skills au total.

## 0.2.0 (29/09/2026)

- **Nouveau skill** `principes` : source unique des règles communes (ne rien inventer, statuts de vérification et niveaux de preuve, posture de conformité, seuils d'accessibilité, largeurs de contrôle, typographie française, données personnelles, forme des livrables). Les autres skills y renvoient au lieu de recopier ces règles.

- **Dédoublonnage** : seuils de contraste et de cibles (`webdesign`, `accessibilite`), typographie française (`webdesign`, `redaction-interface`), statuts vérifié / estimé / à trancher (`medias`, `handoff`, `synthese-recherche`), posture de conformité, largeurs de contrôle et données personnelles renvoient désormais à `principes`.

- Chaque skill métier charge `principes` en premier.

## 0.1.0 (29/09/2026)

Premier empaquetage en plugin des skills design de l'agence, pour les profils UX et UI.

**Structure**
- Sept skills `lba-design-*` regroupés dans le plugin `lba-design`, renommés sans préfixe (le plugin fournit l'espace de noms : `lba-design:webdesign`, etc.). `lba-design-figma-a11y` devient `accessibilite`.
- `lba-design-figma-doc` supprimé, absorbé par le nouveau skill `handoff` (DESIGN.md + spec d'écran + annotations Figma).
- Nouveau skill `redaction-interface`, adapté de `ux-copy` (Anthropic, Apache 2.0).
- Nouveaux skills `recherche-utilisateur` et `synthese-recherche`, adaptés de `user-research` et `research-synthesis` (Anthropic, Apache 2.0) : cadrage par les décisions de conception, méthodes de refonte (tri de cartes, test d'arborescence), analyse par profil, niveaux de preuve, consentement et pseudonymisation, diagnostic de refonte.

**Corrections**
- Renvois vers un skill inexistant (`lba-design-figma-annot`, 3 occurrences) : redirigés vers `handoff`, qui couvre désormais les annotations d'écran.
- Renvoi vers un nom obsolète (`lba-inventaire-medias` dans le modèle de DESIGN.md) : redirigé vers `medias`.
- Tous les renvois entre skills mis à jour au format `lba-design:<skill>`.
- Tirets longs supprimés (`figma-collab`, modèle de DESIGN.md).
- `gabarit-illustration` : ne dépend plus d'un outil propre au chat (questions à choix selon la surface, repli en texte ; repli si Claude in Chrome est indisponible). Le cas Opinel est explicitement présenté comme exemple, pas comme norme.
- `webdesign` : format DTCG et contenu du handoff déplacés dans `handoff/references/tokens-dtcg.md` (une seule source) ; renvois vers `handoff` et `redaction-interface`.

- Annotations natives Dev Mode testées (29/09/2026) : méthode, pièges et correspondance des catégories consignés dans `figma-collab` §3 ; `accessibilite` et `handoff` y renvoient.

**Reste ouvert**
- `medias/assets/` contient des données du projet Opinel : à anonymiser avant toute diffusion hors de l'agence.
