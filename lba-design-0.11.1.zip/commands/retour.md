---
description: Retour d'usage du plugin lba-design sur la session en cours, en un tableau anonymisé à coller sur la page des retours de l'équipe.
---

Fais le retour d'usage du plugin lba-design sur cette conversation, avec le skill `lba-design:feedback` : base-toi uniquement sur ce qui s'est passé ici, anonymise tout, et rends le tableau au format prévu, suivi de la ligne « Surface » et du lien vers la page des retours.
