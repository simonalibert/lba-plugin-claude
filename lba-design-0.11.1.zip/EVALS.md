# Évaluations

La suite est au format natif de Claude Code (`claude plugin eval`), dans `evals/` : un dossier par cas, avec `prompt.md` (la demande, telle qu'un membre de l'équipe la taperait), `graders/` (les vérifications) et, pour les cas qui partent d'un fichier, `case.yaml` et `fixture.sh`, qui recrée ce fichier dans le dossier de travail de chaque essai. Chaque cas tourne avec le plugin et sans (« baseline ») : la différence, `Δ`, mesure ce que le plugin apporte réellement.

## Contenu

| Cas | Skill | Ce qui est vérifié |
|---|---|---|
| `ui-design-direction-pistes` | ui-design | `direction.md` lu, 2 ou 3 pistes nommées par leur parti pris, sacrifice nommé, leviers différents, rien d'inventé |
| `ui-design-qa-avec-fiche` | ui-design | `qa.py --fiche --quiet` lancé, repères de la fiche (13 et 17 px) appliqués, tailles présentées comme des repères |
| `ui-design-pire-cas` | ui-design | données modifiées et non le CSS, bascule démo / pire cas, 0 et 1 article, image absente, valeurs plausibles |
| `ui-design-refonte-sans-silence` | ui-design | changements proposés et non appliqués, conséquence citée |
| `ui-design-fondations` | ui-design | `fondations.md` lu, vert du client repris, `clamp()`, contrastes chiffrés, licence, une ou deux familles, pas de mode sombre imposé |
| `ui-design-chiffres-alignes` | ui-design | `lining-nums tabular-nums`, vérification du style de chiffres de la police |
| `ui-design-vocabulaire-aerer` | ui-design | `vocabulaire.md` lu, espacements augmentés par les tokens, textes et couleurs inchangés, changement restitué |
| `ui-design-anti-defauts` | ui-design | huit anti-défauts relevés, remplacement proposé |
| `ui-design-preseance-ds-client` | ui-design | le design system du client l'emporte (pas de capitales, police et hauteur du client), écart de 40 px signalé |
| `motion-menu-et-modale` | motion | `composants.md` lu, origine au déclencheur, ni `scale(0)` ni `ease-in`, fondu gardé en mouvement réduit |
| `motion-correction-mouvement-reduit` | motion | bouton pause, mouvement réduit lu, défilement arrêté, fondu gardé |
| `motion-vitrine-marquee` | motion | bandeau réalisé avec pause, mouvement réduit, doublons masqués |
| `microcopy-anti-defauts` | microcopy | quatre textes traités, « Actualités », rien d'inventé |
| `accessibility-profil-rgaa` | accessibility | pré-évaluation, profil affiché, lien d'évitement, pas de verdict de conformité |
| `wireframe-vitrine-epinglee` | wireframe | `rendu-lofi.md` lu, 390 présent, palette lofi, contrat de structure, équivalent statique |
| `handoff-spec-eco` | handoff | profil, zones grises, mouvement réduit, aucun poids inventé |
| `media-inventaire-rgaa` | media | sous-titres, transcription, nomenclature SEO, statuts |
| `principles-conflit-profils` | principles | bouton pause, arbitrage par la fiche, deux options, aucun poids inventé |
| `declenchement-01` à `-11` | tous | le bon skill se déclenche (8 cas) ou ne se déclenche pas (3 cas) |

Les vérifications objectives sont des expressions régulières sur la réponse ou sur un fichier livré sous un nom imposé : gratuites et stables. Le juge (un second modèle) ne répond qu'à des questions simples, une condition à la fois. Les vérifications « tel fichier de référence a été lu » ne comptent que pour le bras avec plugin.

## Déjà vérifié (10/10/2026, Claude Code 2.1.296)

- `claude plugin validate . --strict` : validation passée.
- Les 11 cas de déclenchement, une passe chacun, sans baseline : 11 sur 11 (1,15 $).
- `ui-design-anti-defauts` : 1,00 ; `motion-vitrine-marquee` : 1,00 après correction de la description de `motion`, qui ne se déclenchait pas sur « bandeau qui défile en boucle » (premier défaut trouvé par la suite).
- `microcopy-anti-defauts` : 0,75, puis consigne du juge précisée (un exemple présenté comme illustration n'est pas une invention).
- Les cas de comportement n'ont pas encore tourné avec baseline ni en trois passes.

## Protocole pour lundi

Sur ton Mac, dans un terminal.

**1. Prérequis**

```bash
claude --version          # 2.1.269 au minimum ; sinon : claude update
git --version             # 2.31 au minimum
python3 -m pip install playwright && python3 -m playwright install chromium   # pour qa.py (facultatif)
```

**2. Dézipper les deux versions côte à côte**

```bash
mkdir -p ~/lba-evals && cd ~/lba-evals
unzip ~/Downloads/lba-design-0.8.1.zip  -d v0.8.1
unzip ~/Downloads/lba-design-0.10.1.zip -d v0.10.1
cp -R v0.10.1/evals v0.8.1/evals          # même suite pour comparer
```

**3. Valider, puis déclenchement (quelques minutes, 1 à 2 $)**

```bash
cd ~/lba-evals/v0.10.1
claude plugin validate .
claude plugin eval . --tag declenchement --runs 1 --ablation none
```

La première fois, Claude Code demande si tu fais confiance au dossier : réponds oui.

**4. Comportement de `ui-design`, avec baseline**

```bash
claude plugin eval . --tag ui-design --runs 1 --scaffold \
  --allow-tools Write Edit "Bash(python3 *)" \
  --judge-model sonnet --max-cost-usd 25
```

`--scaffold` recrée les fichiers d'entrée des cas (scripts écrits par nous, sans risque) ; `Bash(python3 *)` laisse tourner `qa.py`, dans le bac à sable de macOS. Une passe d'abord : si les scores sont lisibles, relancer les cas intéressants avec `--runs 3`.

**5. Le reste**

```bash
claude plugin eval . --tag comportement --runs 1 --scaffold \
  --allow-tools Write Edit "Bash(python3 *)" --judge-model sonnet --max-cost-usd 40
```

**6. Comparer avec la 0.8.1**

```bash
cd ~/lba-evals/v0.8.1
claude plugin eval . --tag comportement --runs 1 --scaffold \
  --allow-tools Write Edit "Bash(python3 *)" --judge-model sonnet --max-cost-usd 40
```

Les cas qui testent des nouveautés de la 0.10.0 (profils, `qa.py --fiche`, direction) échoueront en 0.8.1 par construction : c'est attendu. La comparaison utile porte sur les cas que la 0.8.1 couvrait déjà (refonte, anti-défauts, microcopy, accessibilité, motion) : la 0.10.0 ne doit pas y faire moins bien.

## Tests manuels : la fenêtre de questions

`claude plugin eval` tourne sans personne pour répondre et retire l'outil de questions de la session : l'agent se rabat alors sur des hypothèses, comme la règle « ne jamais bloquer » le lui demande (constaté le 10/10/2026). La fenêtre de questions se teste donc à la main, dans une conversation normale, sur claude.ai puis dans Claude Code.

| Demande à taper | Attendu |
|---|---|
| « Fais-moi le webdesign de la page d'accueil d'un cabinet d'architectes à Annecy. » | Fenêtre avec la structure (zoning, existant ou rien), le logo et les médias (dont l'option Google Drive), le nombre de pistes ; dans Claude Code, une quatrième question sur le profil ; puis une phrase qui demande de joindre ce qui a été coché |
| « Fais-moi une seule direction de webdesign pour la page d'accueil d'un cabinet d'architectes à Annecy. Ils n'ont rien : ni logo, ni charte, ni photos, et aucune référence. » | Aucune fenêtre : tout est dit |
| « J'ai besoin du wireframe de la page d'accueil du futur site de l'office de tourisme du Vercors. » | Fenêtre avec l'outil (Claude Design, Figma + Simple Design System si le connecteur Figma est là, HTML), le périmètre, les contenus |
| La même demande, en précisant « dans Figma, juste la page d'accueil, contenus génériques » | Aucune fenêtre |
| Webdesign du cabinet d'architectes, cocher « Chercher dans Google Drive » | Recherche dans le Drive seulement après la réponse ; liste des fichiers trouvés, confirmation demandée avant usage ; si le connecteur manque, le dire et proposer de le connecter |
| Webdesign du cabinet d'architectes, sans cocher l'option Drive | Aucune recherche dans le Drive |
| Webdesign du cabinet d'architectes, cocher « Un site ou une capture existante » puis coller une URL | Structure extraite et présentée comme point de départ, ce qui change distingué de ce qui reste ; pas de copie visuelle |

## Lire les résultats

Chaque passage écrit `evals/results/<date>/report.html` : l'ouvrir dans le navigateur. Le plafond `--max-cost-usd` arrête la suite proprement s'il est atteint ; ajuste-le à ton budget. Dans le rapport :

- **`Δ` proche de 0** : le plugin n'apporte rien sur ce cas (Claude fait aussi bien sans), ou il ne s'est pas déclenché. Regarder l'indicateur `skill-declenche`.
- **`lit-…` en échec** : le skill s'est déclenché mais n'a pas lu sa référence ; le renvoi dans le déroulé du `SKILL.md` n'est pas assez clair.
- **Un juge qui vote PASS FAIL PASS** : consigne ambiguë ; la préciser plutôt que de toucher au skill.
- **Un échec isolé sur une seule passe** : relancer avec `--runs 3` avant de conclure.

Ne pas versionner `evals/results/` (déjà dans `evals/.gitignore`).
