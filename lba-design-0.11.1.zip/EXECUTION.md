# Savoir et exécution

Ce plugin mélange deux choses : le **savoir de l'agence** (méthode, règles, pièges, seuils), valable quel que soit l'outil, et l'**exécution par Claude** (noms d'outils, connecteurs, surfaces). Ce fichier recense la seconde, skill par skill, sans rien déplacer. Il sert à tester le plugin hors de claude.ai, et prépare une séparation future si l'agence utilise un jour plusieurs outils d'IA.

Statuts selon `skills/principles/SKILL.md` §2 : **vérifié** (constaté), **estimé** (connu sans l'avoir testé ici), **à vérifier**. État au 10/10/2026. Les comportements se testent avec la suite d'évaluation (`EVALS.md`).

## Dépendances par skill

| Skill | Savoir propre (portable) | Dépendances d'exécution | Repli prévu si l'outil manque |
|---|---|---|---|
| `principles` | Tout le contenu | Aucune | Sans objet |
| `research` | Méthodes, guide, consentement | Aucune | Sans objet |
| `synthesis` | Méthode, niveaux de preuve, format | Lecture des fichiers joints ; script `verifier_citations.py` (évaluations) | Sans objet |
| `ui-design` | Impératifs, défauts, traduction Figma | Outil Artifact (lire et publier un artefact claude.ai), projets Claude Design, connecteur Figma, Python + Playwright (`qa.py`), skill externe `simple-design-system-starter` | Prévu (section « Selon l'environnement ») : HTML autonome dans le dossier projet, `qa.py` sur le poste ou livraison sans QA scriptée signalée |
| `wireframe` | Arborescence, structure, contrat de structure | Connecteur Figma, `use_figma` + skills `figma:figma-use` et `figma:figma-generate-design` ; outil Artifact ou Claude Design en option | Prévu : HTML basse fidélité ; extraction du contrat depuis un wireframe existant |
| `motion` | Socle, recettes, pièges | Projet local avec GSAP et Lenis (copie de `assets/`), navigateur de test facultatif | Prévu : livrer sans test en mouvement, en le disant |
| `microcopy` | Tout le contenu | Connecteur Figma facultatif | Sans objet |
| `accessibility` | Posture, classement, checklist | Connecteur Figma (lecture), `use_figma` + skill `figma:figma-use` (annotations), Python (`contrast.py`) | Prévu : annotations en texte à coller |
| `handoff` | Règles, modèles DESIGN.md et spec | Connecteur Figma, `use_figma` (annotations) | Prévu : annotations en texte à coller |
| `media` | Inventaire, gabarit, calculs | Connecteur Figma, Claude in Chrome (mesure du site), outil de questions de la surface, Python (`calcul_zones.py`) | Prévu : questions en texte ; demander le comportement si pas de navigateur |
| `feedback` | Grille du retour, anonymisation, format du tableau | Aucune ; la commande `/retour` dépend de la prise en charge des commandes de plugin par la surface (à vérifier sur claude.ai) | Prévu : la phrase « retour LBA » suffit partout |
| `figma` | Pièges de l'API Plugin | `use_figma` + skill `figma:figma-use` | Aucun : sans écriture Figma, le skill n'a pas d'objet |

## Disponibilité par surface

| Dépendance | claude.ai (chat) | Cowork | Claude Code |
|---|---|---|---|
| Skills du plugin | vérifié | vérifié (16/10/2026) ; attention aux conversations résumées automatiquement, qui peuvent perdre les instructions chargées | vérifié le 10/10/2026 (Claude Code 2.1.296, `--plugin-dir` et `claude plugin eval` : chargement et déclenchement des skills) ; synchronisation des plugins du compte à vérifier |
| Outil Artifact | vérifié | vérifié (Claude Design via Artifact, retour d'usage du 16/10/2026) | estimé : absent |
| Outil de questions à choix | vérifié (`ask_user_input_v0`, trois questions au plus) | à vérifier | vérifié : `AskUserQuestion`, 1 à 4 questions de 2 à 4 options, choix multiple, réponse libre « Autre » ajoutée d'office ; pas de dépôt de fichier |
| Bash dans `claude plugin eval` | sans objet | sans objet | exige le bac à sable du système : présent sous macOS, `bubblewrap` et `socat` à installer sous Linux |
| Claude Docs | vérifié | à vérifier | estimé : absent |
| Connecteur Figma (`use_figma`) | vérifié | à vérifier | estimé : à configurer comme serveur MCP |
| Claude in Chrome | vérifié | à vérifier | à vérifier |
| Python, Playwright | vérifié (environnement d'exécution, réseau restreint) | à vérifier | estimé : selon le poste |
| Accès à une préprod client | estimé : impossible depuis l'environnement d'exécution | à vérifier | estimé : possible depuis le poste |

## À faire

- Tester le plugin dans Claude Code et dans Cowork, et passer les « à vérifier » en « vérifié » ou en limite connue.
- Plus tard, si plusieurs outils d'IA coexistent : sortir la colonne « savoir propre » en un corpus indépendant, dont ce plugin ne serait qu'une implémentation.
